package com.roi.api.calculate;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("myresource")
public class MyResource {

	public String driverName = "com.mysql.jdbc.Driver";
	public static String connectionUrl = "jdbc:mysql://localhost:3306/";
	public static String dbName = "roicaldb";
	public static String userId = "root";
	public static String password = "qwerty12345";
	public static ArrayList<Integer> TestDatalist = new ArrayList<Integer>();
	public static int nl = 0;
	public static int nh = 0;
	public static int nm = 0;
	public static int as = 0;
	public static boolean boo = true;
	public static boolean test = true;
	public static double nt;
	public static String tl = null;
	public static String tm = null;
	public static String th = null;
	public static String category = null;
	public static String projectName = null;
	public static String starttime = null;
	public static String date = null;
	public static String exetime = null;
	public static String seconds = null;
	public static String projectName1 = null;
	public static String starttime1 = null;
	public static String date1 = null;
	public static String exetime1 = null;
	public static String seconds1 = null;
	public static String complex = null;
	public static String testCycle = null;
	public static String testCycle1 = null;
	public static int cycle = 0;
	public static String gh11 = null;
	public static String user = null;
	public static String user1 = null;
	public static String debug = null;
	public static String debug1 = null;

	private static DecimalFormat df2 = new DecimalFormat(".##");

	@POST
	@Path("/roiexeupdate")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response ROICALapi(InputStream incomingData) throws SQLException {
		StringBuilder ROICAL = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				ROICAL.append(line);
			}
		} catch (Exception e) {
			System.out.println("Error while Parsing: - ");
		}
		System.out.println("Data Received: " + ROICAL.toString());
		String time_values = ROICAL.toString();
		time_values = time_values.replaceAll("[{}]", "");
		System.out.println(time_values);
		String[] kvPairs = time_values.split(",");
		System.out.println("kv" + kvPairs[1]);
		ArrayList<String> apiValues = new ArrayList<String>();
		ArrayList<String> apiValues_sub = new ArrayList<String>();
		apiValues.clear();
		apiValues_sub.clear();
		for (String kvPair : kvPairs) {
			String[] kv = kvPair.split(":", 2);

			String key = kv[0];
			
			apiValues_sub.add(key);
			String value = kv[1];
			apiValues.add(value);
			if (key.equals("specialkey")) {
				// Do something with value if the key is "specialvalue"...
			}

		}
		int i = 0;
		int l = apiValues_sub.size();
		System.out.println(apiValues_sub);
		// System.out.println("l===="+l);
		if (l != 5) { // && l<3) {

			String successMsg = "{\"Error message\":\"Invalid Request\"}";
			return Response.status(200).entity(successMsg).build();

		}

		else {

			while (i < l) {

				if (apiValues_sub.get(i).trim().equals("\"Date\"") == true) {
					MyResource.date = apiValues.get(i);
					MyResource.date1 = apiValues_sub.get(i);
				}

				if (apiValues_sub.get(i).trim().equals("\"Project\"") == true) {
					MyResource.projectName = apiValues.get(i);
					MyResource.projectName1 = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"Complexity\"") == true) {
					MyResource.category = apiValues.get(i);
					MyResource.complex = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"ExecutionTime\"") == true) {
					MyResource.exetime = apiValues.get(i);
					MyResource.exetime1 = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"User\"") == true) {
					MyResource.user = apiValues.get(i);
					MyResource.user1 = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"debug\"") == true) {
					MyResource.debug = apiValues.get(i);
					MyResource.debug1 = apiValues_sub.get(i);
				}

				i = i + 1;

			}
		}

		if ((MyResource.debug.trim().equalsIgnoreCase("\"true\""))){
			String msg = "{\"Message\" : \"Scripts are running on Debug mode. Please change the value to [False]? if you are executing the scripts for regression cycle\"}";
			return Response.status(200).entity(msg).build();
		}
		
		
		System.out.println("sub======" + apiValues_sub);

		String k = "startTime";
		System.out.println(k);
		System.out.println(apiValues_sub);
		i = 0;
		while (i < l) {
			if (MyResource.projectName1 == null) {
				String successMsg = "{\"Error message\":\"Invalid Request for\" {\"Project\"}}";
				return Response.status(400).entity(successMsg).build();

			}

			if (MyResource.exetime1 == null) {
				String successMsg = "{\"Error message\":\"Invalid Request for \" {\"ExecutionTime\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			if (MyResource.complex == null) {
				String successMsg = "{\"Error message\":\"Invalid Request for \" {\"Complexity\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			if (MyResource.user1 == null) {

				String successMsg = "{\"Error message\":\"Invalid Request \" {\"User\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			if (MyResource.debug1 == null) {

				String successMsg = "{\"Error message\":\"Invalid Request \" {\"Debug\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			if (((MyResource.debug.trim().equalsIgnoreCase("\"true\""))
					|| (MyResource.debug.trim().equalsIgnoreCase("\"false\""))) == false) {

				String successMsg = "{\"Error message\":\"Invalid Request "
						+ "{Only allowed values are \'true / false'}\"}";
				return Response.status(400).entity(successMsg).build();
			}

			if (((MyResource.category.trim().equalsIgnoreCase("\"High\"")) || (MyResource.category.trim().equalsIgnoreCase("\"Medium\""))
					|| (MyResource.category.trim().equalsIgnoreCase("\"Low\""))) == false) {
				String successMsg = "{\"Error message\":\"Invalid Request "
						+ "{Only allowed values are \'High / Medium / Low\'}\"}";
				return Response.status(400).entity(successMsg).build();
			}

			i = i + 1;
		}

		Connection connection6 = null;
		connection6 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement6 = null;

		statement6 = connection6.createStatement();

		ResultSet resultSet6 = null;

		as = 0;
		String s = "ROI_TEST";

		String qh1 = "select * from project where NAME = " + MyResource.projectName + "";
		String sh1;
		System.out.println("sssss=====" + qh1);
		resultSet6 = statement6.executeQuery(qh1);
		while (resultSet6.next()) {
			MyResource.as = resultSet6.getInt(1);
		}
		System.out.println("valueee===" + MyResource.as);
		if (MyResource.as == 0) {
			String successMsg = "{\"Error message\":\"Invalid Project Name\"}";
			return Response.status(400).entity(successMsg).build();
		}
		connection6.close();

		Connection connection9 = null;
		connection9 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement9 = null;
		statement9 = connection9.createStatement();
		ResultSet resultSet9 = null;
		Statement statement10 = null;
		statement10 = connection9.createStatement();
		ResultSet resultSet10 = null;

		String vv = "select * from project_configure_element where PROJECT_ID=" + MyResource.as
				+ " and CONFIG_ELEMENT_ID=13";
		resultSet10 = statement10.executeQuery(vv);
		while (resultSet10.next()) {
			MyResource.cycle = resultSet10.getInt(4);
		}
		System.out.println("cycle====" + MyResource.cycle);

		connection9.close();


		Connection connection3 = null;
		connection3 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement3 = null;
		statement3 = connection3.createStatement();

		String query = "UPDATE tblautomation " + "SET autoTest = (SELECT SUM(No) FROM no_of_test_cases) WHERE id=1";
		statement3.executeUpdate(query);

		System.out.println("ssssss" + apiValues);

		Connection connection1 = null;
		connection1 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement1 = null;
		Statement statement2 = null;
		Statement statement8 = null;
		statement1 = connection1.createStatement();
		statement2 = connection1.createStatement();
		statement8 = connection1.createStatement();
		ResultSet resultSet1 = null;
		ResultSet result = null;
		String qh3 = "select * from no_of_tests where projectId = " + MyResource.as + "";

		System.out.println("sssss=====" + qh3);
		result = statement8.executeQuery(qh3);
		if (!result.isBeforeFirst()) {
			System.out.println("No data");
			statement9 = connection1.createStatement();

			String qhin = ("INSERT INTO no_of_tests (projectId,high,medium,low) " + "VALUES (" + MyResource.as
					+ ",'0','0','0')");
			System.out.println(qhin);

			statement9.executeUpdate(qhin);
		}

		System.out.println("dateeee=====" + LocalDate.now());
		MyResource.gh11 = LocalDate.now().toString();
		System.out.println("dateeee=====" + MyResource.gh11);

		if (MyResource.category.trim().equals("\"Medium\"")) {

			String query1 = "UPDATE no_of_tests " + "SET medium = medium + 1  WHERE projectId= " + MyResource.as + " ";
			statement2.executeUpdate(query1);

		}

		if (MyResource.category.trim().equals("\"Low\"")) {

			String query1 = "UPDATE no_of_tests " + "SET low = low + 1 WHERE projectId= " + MyResource.as + " ";
			statement2.executeUpdate(query1);
		}

		if (MyResource.category.trim().equals("\"High\"")) {
			String query1 = "UPDATE no_of_tests " + "SET high = high + 1 WHERE projectId = " + MyResource.as + " ";
			System.out.println("query====" + query1);
			statement2.executeUpdate(query1);
		}
		connection1.close();

		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection connection = null;
		Statement statementh = null;

		try {

			connection = DriverManager.getConnection(connectionUrl + dbName, userId, password);
			statementh = connection.createStatement();

			String qhin = ("INSERT INTO tbl_exe_time (date,projectId,complexity,exeTime,User,debug)" + "VALUES (\""
					+ MyResource.gh11 + "\"," + MyResource.as + "," + MyResource.category + "," + MyResource.exetime
					+ "," + MyResource.user + "," + MyResource.debug + ")");

			System.out.println(qhin);

			statementh.executeUpdate(qhin);

			connection.close();

		} catch (Exception e) {

			e.printStackTrace();
		}
		category = null;
		projectName = null;
		starttime = null;

		exetime = null;
		seconds = null;
		projectName1 = null;
		starttime1 = null;

		exetime1 = null;
		seconds1 = null;
		user = null;
		user1 = null;
		debug = null;
		debug1 = null;
		apiValues.clear();
		apiValues_sub.clear();
		String successMsg = "{\"Status\":\"Success\"}";

		return Response.status(200).entity(successMsg).build();
	}

}