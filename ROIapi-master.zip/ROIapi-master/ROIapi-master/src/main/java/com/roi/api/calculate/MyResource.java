package com.roi.api.calculate;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("myresource")
public class MyResource {

	static String driverName = "com.mysql.jdbc.Driver";
	static String connectionUrl = "jdbc:mysql://localhost:3306/";
	static String dbName = "roicaldb";
	static String userId = "root";
	static String password = "qwerty12345";
	static ArrayList<Integer> TestDatalist = new ArrayList<Integer>();
	static int nl = 0;
	static int nh = 0;
	static int nm = 0;
	static int as = 0;
	static boolean boo = true;
	static boolean test = true;
	static double nt;
	static String tl = null;
	static String tm = null;
	static String th = null;
	static String category = null;
	static String projectName = null;
	static String starttime = null;
	static String date = null;
	static String exetime = null;
	static String seconds = null;
	static String projectName1 = null;
	static String starttime1 = null;
	static String date1 = null;
	static String exetime1 = null;
	static String seconds1 = null;
	static String complex = null;
	static String testCycle = null;
	static String testCycle1 = null;
	static int cycle = 0;
	static String gh11 = null;
	static String user = null;
	static String user1 = null;
	static String debug = null;
	static String debug1 = null;

	private static DecimalFormat df2 = new DecimalFormat(".##");

	@POST
	@Path("/roiexeupdate")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response ROICALapi(InputStream incomingData) throws SQLException {
		StringBuilder ROICAL = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				ROICAL.append(line);
			}
		} catch (Exception e) {
			System.out.println("Error while Parsing: - ");
		}
		System.out.println("Data Received: " + ROICAL.toString());
		String time_values = ROICAL.toString();
		time_values = time_values.replaceAll("[{}]", "");
		System.out.println(time_values);
		String[] kvPairs = time_values.split(",");
		System.out.println("kv" + kvPairs[1]);
		ArrayList<String> apiValues = new ArrayList<String>();
		ArrayList<String> apiValues_sub = new ArrayList<String>();
		apiValues.clear();
		apiValues_sub.clear();
		for (String kvPair : kvPairs) {
			String[] kv = kvPair.split(":", 2);

			String key = kv[0];
			// System.out.println(kv[0]);
			apiValues_sub.add(key);
			String value = kv[1];
			apiValues.add(value);
			if (key.equals("specialkey")) {
				// Do something with value if the key is "specialvalue"...
			}

		}
		int i = 0;
		int l = apiValues_sub.size();
		System.out.println(apiValues_sub);
		// System.out.println("l===="+l);
		if (l != 6) { // && l<3) {

			String successMsg = "{\"Error message\":\"Invalid Request\"}";
			return Response.status(200).entity(successMsg).build();

		}

		else {
			category = null;
			projectName = null;
			// starttime = null;
			// endtime = null;
			exetime = null;
			// seconds =null;
			projectName1 = null;
			// starttime1 = null;
			// endtime1 = null;
			exetime1 = null;
			complex = null;
			date = null;
			date1 = null;
			user = null;
			user1 = null;
			debug = null;
			debug1 = null;
			// seconds1 =null;

			while (i < l) {

				if (apiValues_sub.get(i).trim().equals("\"Date\"") == true) {
					MyResource.date = apiValues.get(i);
					MyResource.date1 = apiValues_sub.get(i);
				}

				if (apiValues_sub.get(i).trim().equals("\"Project\"") == true) {
					MyResource.projectName = apiValues.get(i);
					MyResource.projectName1 = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"Complexity\"") == true) {
					MyResource.category = apiValues.get(i);
					MyResource.complex = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"ExecutionTime\"") == true) {
					MyResource.exetime = apiValues.get(i);
					MyResource.exetime1 = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"User\"") == true) {
					MyResource.user = apiValues.get(i);
					MyResource.user1 = apiValues_sub.get(i);
				}
				if (apiValues_sub.get(i).trim().equals("\"debug\"") == true) {
					MyResource.debug = apiValues.get(i);
					MyResource.debug1 = apiValues_sub.get(i);
				}

				/*
				 * if (apiValues_sub.get(i).trim().equals("\"TestCycle\"") == true) {
				 * MyResource.testCycle = apiValues.get(i); MyResource.testCycle1 =
				 * apiValues_sub.get(i); }
				 */
				/*
				 * if ((apiValues.get(i).trim().equals("\"Seconds\"") ==
				 * true)||(apiValues.get(i).trim().equals("\"Minutes\"") ==
				 * true)||(apiValues.get(i).trim().equals("\"Milliseconds\"") == true)) {
				 * MyResource.seconds = apiValues.get(i); //MyResource.seconds1 =
				 * apiValues_sub.get(i); }
				 * 
				 * if (apiValues_sub.get(i).trim().equals("\"timeUnit\"") == true) {
				 * MyResource.seconds1 = apiValues_sub.get(i); //MyResource.exetime1 =
				 * apiValues_sub.get(i); }
				 */

				i = i + 1;

			}
		}

		// System.out.println("myresor======="+ MyResource.projectName1);
		// System.out.println("starttime======="+ MyResource.starttime1);
		// System.out.println("endtime======="+ MyResource.endtime1);
		System.out.println("exetime=======" + MyResource.exetime1);
		// System.out.println("seconds======="+ MyResource.seconds);
		System.out.println("COMPLEX=======" + MyResource.complex);
		System.out.println("PROJECT=======" + MyResource.projectName1);
		System.out.println("DATE=======" + MyResource.date);
		System.out.println("cattt=======" + MyResource.category);
		System.out.println("testcycle=======" + MyResource.testCycle);
		System.out.println("debug===" + debug1);
		System.out.println("debugg====" + debug);

		/*
		 * else {
		 * 
		 * if (apiValues_sub.get(0).trim().equals("\"startTime\"") == true ||
		 * apiValues_sub.get(1).trim().equals("\"startTime\"") == true||
		 * apiValues_sub.get(2).trim().equals("\"startTime\"") == true s ) {
		 * 
		 * }
		 * 
		 * }
		 */

		System.out.println("sub======" + apiValues_sub);

		String k = "startTime";
		System.out.println(k);
		System.out.println(apiValues_sub);
		// String s="";
		/* if (apiValues_sub.get(0).trim().equals("\"projectName\"") == false) { */
		// System.out.println("\"startTime\"");
		i = 0;
		while (i < l) {
			if (MyResource.projectName1 == null) {
				String successMsg = "{\"Error message\":\"Invalid Request for\" {\"Project\"}}";
				return Response.status(400).entity(successMsg).build();
				// s= "Mismatch in startTime ";
			}
			/*
			 * if (apiValues_sub.get(1).trim().equals("\"startTime\"") == false) { //
			 * System.out.println("\"startTime\"");
			 */
			/*
			 * if( MyResource.starttime1 == null ) { String successMsg =
			 * "{\"Error message\":\"Invalid Request for \" {\"startTime\"}}"; return
			 * Response.status(201).entity(successMsg).build(); // s=
			 * "Mismatch in startTime "; }
			 */
			/*
			 * if (apiValues_sub.get(2).trim().equals("\"endTime\"") == false) { // s= s+
			 * '\n'+ "Mismatch in endTime";
			 */
			/*
			 * if( MyResource.endtime1 == null ) { String successMsg =
			 * "{\"Error message\":\"Invalid Request for \" {\"endTime\"}}"; return
			 * Response.status(201).entity(successMsg).build(); }
			 */
			/* if (apiValues_sub.get(3).trim().equals("\"exeTime\"") == false) { */
			if (MyResource.exetime1 == null) {
				String successMsg = "{\"Error message\":\"Invalid Request for \" {\"ExecutionTime\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			/* if (apiValues_sub.get(4).trim().equals("\"timeUnit\"") == false) { */
			if (MyResource.complex == null) {
				String successMsg = "{\"Error message\":\"Invalid Request for \" {\"Complexity\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			/*
			 * if(MyResource.date1==null) {
			 * 
			 * String successMsg = "{\"Error message\":\"Invalid Request " +
			 * "{Only allowed values for timeUnit are \'Minutes / Seconds / Milliseconds\'}\"}"
			 * ; return Response.status(201).entity(successMsg).build();
			 * 
			 * }
			 */
			if (MyResource.date1 == null) {

				String successMsg = "{\"Error message\":\"Invalid Request \" {\"Date\"}}";
				return Response.status(400).entity(successMsg).build();

			}
			/*
			 * if (MyResource.testCycle1 == null) {
			 * 
			 * String successMsg =
			 * "{\"Error message\":\"Invalid Request \" {\"TestCycle\"}}"; return
			 * Response.status(400).entity(successMsg).build();
			 * 
			 * }
			 */
			if (MyResource.user1 == null) {

				String successMsg = "{\"Error message\":\"Invalid Request \" {\"User\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			if (MyResource.debug1 == null) {

				String successMsg = "{\"Error message\":\"Invalid Request \" {\"Debug\"}}";
				return Response.status(400).entity(successMsg).build();
			}

			if (((MyResource.debug.trim().equals("\"true\""))
					|| (MyResource.debug.trim().equals("\"false\""))) == false) {

				String successMsg = "{\"Error message\":\"Invalid Request "
						+ "{Only allowed values are \'true / false'}\"}";
				return Response.status(400).entity(successMsg).build();
			}

			if (((MyResource.category.trim().equals("\"High\"")) || (MyResource.category.trim().equals("\"Medium\""))
					|| (MyResource.category.trim().equals("\"Low\""))) == false) {
				String successMsg = "{\"Error message\":\"Invalid Request "
						+ "{Only allowed values are \'High / Medium / Low\'}\"}";
				return Response.status(400).entity(successMsg).build();
			}

			i = i + 1;
		}

		Connection connection6 = null;
		connection6 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement6 = null;
		// Statement statement6 = null;
		statement6 = connection6.createStatement();
		// statement6=connection6.createStatement();
		ResultSet resultSet6 = null;
		// ResultSet resultset2 = null;
		as = 0;
		String s = "ROI_TEST";

		String qh1 = "select * from project where NAME = " + MyResource.projectName + "";
		String sh1;
		System.out.println("sssss=====" + qh1);
		resultSet6 = statement6.executeQuery(qh1);
		while (resultSet6.next()) {
			MyResource.as = resultSet6.getInt(1);
		}
		System.out.println("valueee===" + MyResource.as);
		if (MyResource.as == 0) {
			String successMsg = "{\"Error message\":\"Invalid Project Name\"}";
			return Response.status(400).entity(successMsg).build();
		}
		connection6.close();

		Connection connection9 = null;
		connection9 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement9 = null;
		statement9 = connection9.createStatement();
		ResultSet resultSet9 = null;
		Statement statement10 = null;
		statement10 = connection9.createStatement();
		ResultSet resultSet10 = null;
		// ResultSet resultset2 = null;
		/*
		 * String qh11 =
		 * "SELECT (SELECT sum(No) FROM roicaldb.no_of_test_cases)>=(SELECT TOTAL_VALUE FROM roicaldb.user_input where PROJECT_ID="
		 * + MyResource.as + " and INPUT_TYPE_ID=2)";
		 */
		String vv = "select * from project_configure_element where PROJECT_ID=" + MyResource.as
				+ " and CONFIG_ELEMENT_ID=13";
		resultSet10 = statement10.executeQuery(vv);
		while (resultSet10.next()) {
			MyResource.cycle = resultSet10.getInt(4);
		}
		System.out.println("cycle====" + MyResource.cycle);

		String qh9 = "select (select VALUE from project_configure_element where PROJECT_ID=" + MyResource.as
				+ " and CONFIG_ELEMENT_ID=13)>=" + MyResource.testCycle + " ";

		System.out.println("qh9===" + qh9);
		resultSet9 = statement9.executeQuery(qh9);

		while (resultSet9.next()) {
			MyResource.test = resultSet9.getBoolean(1);

		}

		System.out.println("BOOOOLEAN===" + MyResource.test);

		/*
		 * if (MyResource.test == false) { String successMsg =
		 * "{\"Error message\":\"Please update the Test Cycle Count: Current value is {"
		 * +MyResource.cycle+" }\"}"; return
		 * Response.status(400).entity(successMsg).build(); }
		 */

		connection9.close();

		Connection connection7 = null;
		connection7 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement7 = null;
		statement7 = connection7.createStatement();
		ResultSet resultSet7 = null;
		// ResultSet resultset2 = null;
		/*
		 * String qh11 =
		 * "SELECT (SELECT sum(No) FROM roicaldb.no_of_test_cases)>=(SELECT TOTAL_VALUE FROM roicaldb.user_input where PROJECT_ID="
		 * + MyResource.as + " and INPUT_TYPE_ID=2)";
		 */

		String qh11 = "SELECT (SELECT sum(high)+sum(medium)+sum(low) FROM roicaldb.no_of_tests where projectId="
				+ MyResource.as + ")>=(SELECT TOTAL_VALUE FROM roicaldb.user_input where PROJECT_ID=" + MyResource.as
				+ " and INPUT_TYPE_ID=2)";

		System.out.println(qh11);
		resultSet7 = statement7.executeQuery(qh11);

		while (resultSet7.next()) {
			MyResource.boo = resultSet7.getBoolean(1);

		}

		System.out.println("BOOOOLEAN===" + MyResource.boo);
		connection7.close();

		if (MyResource.boo == true) {
			String successMsg = "{\"Error message\":\"Limit of Automation test cases exceeded for Test Cycle : {"
					+ MyResource.testCycle.trim() + " }\"}";
			return Response.status(400).entity(successMsg).build();
		}

		Connection connection3 = null;
		connection3 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement3 = null;
		statement3 = connection3.createStatement();
		// Statement statement4 = null;
		/*
		 * ResultSet resultSet3 = null; String
		 * que="SELECT SUM(No) FROM no_of_test_cases";
		 * resultSet3=statement3.executeQuery(que);
		 */
		String query = "UPDATE tblautomation " + "SET autoTest = (SELECT SUM(No) FROM no_of_test_cases) WHERE id=1";
		statement3.executeUpdate(query);

		// System.out.println("check " + apiValues.get(3));
		/*
		 * if (((MyResource.seconds.trim().equals("\"Seconds\"")) ||
		 * (MyResource.seconds.trim().equals("\"Milliseconds\"")) ||
		 * (MyResource.seconds.trim().equals("\"Minutes\""))) == false) { String
		 * successMsg = "{\"Error message\":\"Invalid Request " +
		 * "{Only allowed values are \'Minutes / Seconds / Milliseconds\'}\"}"; return
		 * Response.status(201).entity(successMsg).build(); }
		 */

		// System.out.println(apiValues.get(3));
		// System.out.println("APIII==" + apiValues.get(4));
		/*
		 * if (MyResource.seconds.trim().equals("\"Seconds\"") == true) { String cat2 =
		 * MyResource.exetime.replace("\"", ""); cat2 = cat2.trim();
		 * System.out.println("CAT2==" + cat2); MyResource.nt = Integer.parseInt(cat2);
		 * MyResource.nt = MyResource.nt / 3600;
		 * 
		 * } else if (MyResource.seconds.trim().equals("\"Milliseconds\"") == true) {
		 * String cat2 = MyResource.exetime.replace("\"", ""); cat2 = cat2.trim();
		 * MyResource.nt = Integer.parseInt(cat2); MyResource.nt = MyResource.nt /
		 * 3600000; } else if (MyResource.seconds.trim().equals("\"Minutes\"") == true)
		 * { String cat2 = MyResource.exetime.replace("\"", ""); cat2 = cat2.trim();
		 * MyResource.nt = Integer.parseInt(cat2); MyResource.nt = MyResource.nt / 60; }
		 */

		/*
		 * Connection connection1 = null; connection1 =
		 * DriverManager.getConnection(connectionUrl + dbName, userId, password);
		 * Statement statement1 = null; Statement statement2 = null; Statement
		 * statement8 = null; Statement statement9 = null; statement1 =
		 * connection1.createStatement(); statement2 = connection1.createStatement();
		 * statement8 = connection1.createStatement(); ResultSet resultSet1 = null;
		 * ResultSet result = null; // ResultSet resultset2 = null; String qh =
		 * "SELECT * FROM project_configure_element where PROJECT_ID=" + MyResource.as +
		 * " AND CONFIG_ELEMENT_ID IN(14,15,16)"; System.out.println(qh); resultSet1 =
		 * statement1.executeQuery(qh); String sh, sm, sl; ArrayList<Double> api = new
		 * ArrayList<Double>(); while (resultSet1.next()) { // sh =
		 * resultSet1.getString("1"); api.add(resultSet1.getDouble("VALUE"));
		 * MyResource.nh = resultSet1.getInt(1); // sm = resultSet1.getString("2");
		 * MyResource.nm = resultSet1.getInt(2); // sl = resultSet1.getString("3");
		 * MyResource.nl = resultSet1.getInt(3);
		 * 
		 * } System.out.println("nh=====" + MyResource.nh); System.out.println("nh====="
		 * + MyResource.nm); System.out.println("nh=====" + MyResource.nl);
		 * System.out.println("api===" + api.get(0) + api.get(1) + api.get(2));
		 * System.out.println(apiValues.get(2)); String cat =
		 * apiValues.get(3).replace("\"", ""); System.out.println(cat); cat =
		 * cat.trim(); int cat1 = Integer.parseInt(cat); System.out.println(cat1);
		 * System.out.println("fffffffffff"+MyResource.nt); if (MyResource.nt >=
		 * api.get(0)) { MyResource.category = "\"high\""; }
		 * 
		 * if (MyResource.nt >= api.get(1) && MyResource.nt < api.get(0)) {
		 * MyResource.category = "\"medium\""; }
		 * 
		 * if (MyResource.nt < api.get(2)) { MyResource.category = "\"low\""; }
		 * 
		 * System.out.println("cat======"+MyResource.category);
		 * apiValues.add(MyResource.category);
		 */

		/*
		 * Connection connection1 = null; connection1 =
		 * DriverManager.getConnection(connectionUrl + dbName, userId, password);
		 * Statement statement1 = null; Statement statement2 = null;
		 * statement1=connection1.createStatement();
		 * statement2=connection1.createStatement(); ResultSet resultSet1 = null; //
		 * ResultSet resultset2 = null; String qh ="SELECT * FROM tbl_category";
		 * resultSet1 = statement1.executeQuery(qh); String sh,sm,sl;
		 * 
		 * while(resultSet1.next()){ sh = resultSet1.getString("high");
		 * MyResource.nh=Integer.parseInt(sh); sm = resultSet1.getString("medium");
		 * MyResource.nm=Integer.parseInt(sm); sl = resultSet1.getString("low");
		 * MyResource.nl=Integer.parseInt(sl);
		 * 
		 * } System.out.println(apiValues.get(2)); String cat =
		 * apiValues.get(3).replace("\"", ""); System.out.println(cat); cat=cat.trim();
		 * int cat1 = Integer.parseInt(cat); System.out.println(cat1); if(cat1 >=
		 * MyResource.nh) { MyResource.category = "\"high\""; }
		 * 
		 * if(cat1 >= MyResource.nm && cat1 < MyResource.nh) { MyResource.category
		 * ="\"medium\"" ; }
		 * 
		 * if(cat1 < MyResource.nm) { MyResource.category = "\"low\""; }
		 * 
		 * System.out.println(MyResource.category); apiValues.add(MyResource.category);
		 */
		System.out.println("ssssss" + apiValues);
		/*
		 * if (apiValues_sub.get(3).trim().equals("\"category\"")==false) { String
		 * successMsg = "{\"Error message\":\"Mismatch in category\"}"; return
		 * Response.status(200).entity(successMsg).build(); }* /*if (s!=null) { return
		 * Response.status(200).entity(s).build(); }
		 */

		Connection connection1 = null;
		connection1 = DriverManager.getConnection(connectionUrl + dbName, userId, password);
		Statement statement1 = null;
		Statement statement2 = null;
		Statement statement8 = null;
		statement1 = connection1.createStatement();
		statement2 = connection1.createStatement();
		statement8 = connection1.createStatement();
		ResultSet resultSet1 = null;
		ResultSet result = null;
		String qh3 = "select * from no_of_tests where projectId = " + MyResource.as + "";
		// String sh1;
		System.out.println("sssss=====" + qh3);
		result = statement8.executeQuery(qh3);
		if (!result.isBeforeFirst()) {
			System.out.println("No data");
			statement9 = connection1.createStatement();

			String qhin = ("INSERT INTO no_of_tests (projectId,high,medium,low) " + "VALUES (" + MyResource.as
					+ ",'0','0','0')");
			System.out.println(qhin);

			statement9.executeUpdate(qhin);
		}

		System.out.println("dateeee=====" + LocalDate.now());
		MyResource.gh11 = LocalDate.now().toString();
		System.out.println("dateeee=====" + MyResource.gh11);
		/*
		 * else {
		 * 
		 * statement9 = connection1.createStatement();
		 * 
		 * String qhin = ("INSERT INTO no_of_tests (project_id,high,medium,low) " +
		 * "VALUES ("+ MyResource.as +",'0','0','0')");
		 * 
		 * statement9.executeUpdate(qhin);
		 * 
		 * 
		 * }
		 */
		// System.out.println("cattt===="+MyResource.category.trim());
		// System.out.println("\"high\"");
		// System.out.println((MyResource.category.trim().equals("\"high\"")));
		if (MyResource.category.trim().equals("\"Medium\"")) {
			//System.out.println("11111111111111");
			// String query1 = "UPDATE no_of_test_cases " + "SET No = No + 1 WHERE id=2";
			String query1 = "UPDATE no_of_tests " + "SET medium = medium + 1  WHERE projectId= " + MyResource.as + " ";
			statement2.executeUpdate(query1);

		}

		if (MyResource.category.trim().equals("\"Low\"")) {
		/*	System.out.println("Hellllloooooooooooooo");*/
			String query1 = "UPDATE no_of_tests " + "SET low = low + 1 WHERE projectId= " + MyResource.as + " ";
			statement2.executeUpdate(query1);
		}

		if (MyResource.category.trim().equals("\"High\"")) {
			String query1 = "UPDATE no_of_tests " + "SET high = high + 1 WHERE projectId = " + MyResource.as + " ";
			System.out.println("query====" + query1);
			statement2.executeUpdate(query1);
		}
		connection1.close();

		// System.out.println("double : " + String.format("%.4f", MyResource.nt));
		// System.out.println("check thissss" + MyResource.nt);
		// System.out.println(String.format("%.3f", MyResource.nt));
		// System.out.println(apiValues.get(2));
		// System.out.println(MyResource.nt);
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection connection = null;
		Statement statementh = null;

		try {

			/*
			 * if (starttime== null) { starttime = "0"; } if(endtime==null) { endtime="0"; }
			 */
			connection = DriverManager.getConnection(connectionUrl + dbName, userId, password);
			statementh = connection.createStatement();

			String qhin = ("INSERT INTO tbl_exe_time (date,projectId,complexity,exeTime,User,debug)" + "VALUES (\""
					+ MyResource.gh11 + "\"," + MyResource.as + ","
					+ /* String.format("%.4f", MyResource.nt) */ MyResource.category + "," + MyResource.exetime + ","
					+ MyResource.user + "," + MyResource.debug + ")");

			System.out.println(qhin);

			statementh.executeUpdate(qhin);

			connection.close();
 
		} catch (Exception e) {

			e.printStackTrace();
		}
		category = null;
		projectName = null;
		starttime = null;
		// endtime = null;
		exetime = null;
		seconds = null;
		projectName1 = null;
		starttime1 = null;
		// endtime1 = null;
		exetime1 = null;
		seconds1 = null;
		user = null;
		user1 = null;
		debug = null;
		debug1 = null;
		apiValues.clear();
		apiValues_sub.clear();
		String successMsg = "{\"Status\":\"Success\"}";
		// return Response.status(200).entity(ROICAL.toString()).build();
		return Response.status(200).entity(successMsg).build();
	}

}