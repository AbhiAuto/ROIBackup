package com.ust.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ust.roi.abstracts.AbstractServlet;
import com.ust.roi.db.model.ProjectBean;
import com.ust.roi.db.model.ProjectUserBean;
import com.ust.roi.logic.ProjectLogic;
import com.ust.roi.logic.ProjectUserLogic;
import com.ust.roi.sec.PageUrl;

@WebServlet("/CreateProject")
public class SrvCreateProject extends AbstractServlet {

	private static final long serialVersionUID = 506521049369947326L;

	public SrvCreateProject() {
		super();
	}

	@Override
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			printAllParanKeys(request);
			if (!validateField(request)) {
				return;
			}
			String name = request.getParameter("pname");
			String desp = request.getParameter("desp");
			String manager = request.getParameter("manager");
			if (null == manager || manager.trim().length() == 0) {
				manager = "0";
			}
			String[] users = request.getParameterValues("users");
			ProjectLogic plogic = new ProjectLogic();
			List<ProjectBean> lst = new ArrayList<>();
			ProjectBean pbean = new ProjectBean();
			pbean.setDescription(desp);
			pbean.setName(name);
			// pbean.setManagerId(Integer.parseInt(manager));
			lst.add(pbean);
			plogic.save(lst);
			pbean = plogic.getBeanByName(name);
			if (null != pbean) {
				ProjectUserLogic pulogic = new ProjectUserLogic();
				List<ProjectUserBean> pulst = new ArrayList<>();
				for (String userid : users) {
					ProjectUserBean pubean = new ProjectUserBean();
					pubean.setProjectId(pbean.getId());
					pubean.setUserId(Integer.parseInt(userid));
					pulst.add(pubean);
				}
				pulogic.save(pulst);
			} else {
				showMessage(request, MSG_SAVE_FAIL);
			}
			showMessage(request, MSG_SAVE_SUCCESS + " Please select the newly created project from Current Project tab to proceed with next steps.");
		} catch (Exception e) {
			showMessage(request, MSG_SAVE_FAIL);
			logError("Page[Create Project]:", e);
		} finally {
			forwardRequest(request, response, PageUrl.NEWPROJECT);
		}
	}

	private boolean validateField(HttpServletRequest request) {
		boolean status = true;
		clearMessage();
		ProjectLogic logic = new ProjectLogic();
		if (status && isParameterEmpty(request, "pname")) {
			status = false;
			showMessage("Project Name is mandatory.");
		}

		String name = getParameterValue("pname");
		ProjectBean pbean = logic.getBeanByName(name);
		if (status && null != pbean) {
			status = false;
			showMessage("Project Name already exists.");
		}
		return status;
	}

}
