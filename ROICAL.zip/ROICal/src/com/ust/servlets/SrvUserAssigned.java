package com.ust.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ust.roi.abstracts.AbstractServlet;
import com.ust.roi.logic.UserAssignedLogic;
import com.ust.roi.sec.PageUrl;
import com.ust.roi.sec.SessionKeys;

@WebServlet("/UserAssign")
public class SrvUserAssigned extends AbstractServlet {
	private static final long serialVersionUID = 1L;

	public SrvUserAssigned() {
		super();
	}

	@Override
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String[] userids = request.getParameterValues("seluser");
			Integer projectId = (Integer) request.getSession().getAttribute(SessionKeys.PROJECT_ID.name());
			UserAssignedLogic logic = new UserAssignedLogic();
			logic.saveUserAssignment(userids, projectId);
			showMessage(request, MSG_SAVE_SUCCESS);
		} catch (Exception e) {
			showMessage(request, MSG_SAVE_FAIL);
			logError("Page[User Assign]:", e);
		} finally {
			forwardRequest(request, response, PageUrl.USERASSIGN);
		}
	}
}
