package com.ust.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ust.roi.abstracts.AbstractServlet;
import com.ust.roi.db.model.ProjectCurrencyBean;
import com.ust.roi.db.model.TestingToolsBean;
import com.ust.roi.logic.ProjectCurrencyLogic;
import com.ust.roi.logic.TestingToolsLogic;
import com.ust.roi.sec.PageUrl;
import com.ust.roi.sec.SessionKeys;

@WebServlet("/ToolConfigure")
public class SrvToolConfigure extends AbstractServlet {

	private static final long serialVersionUID = -9113234102267180225L;

	public SrvToolConfigure() {
		super();
	}

	@Override
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			String pcid = request.getParameter("pcid");
			String seltool = request.getParameter("seltool");
			String[] ttids = request.getParameterValues("ttid");
			String[] toolIds = request.getParameterValues("toolId");
			String[] toolCosts = request.getParameterValues("tcost");
			String[] tooltypes = request.getParameterValues("ttidd"); 

			String temp = (String) request.getParameter("flag");
			System.out.println("flag===" + temp);

			System.out.println("toolcostsize===" + toolIds.length + toolCosts.length); 
			ArrayList<String> ar = new ArrayList<String>();
			ar.clear();

			String st = "Open Source";
			for (int i = 0; i < toolCosts.length; i++) {
				ar.add(toolCosts[i]);
			}

			for (int i = 0; i < tooltypes.length; i++) {
				if (tooltypes[i].equals(st)) {
					ar.add(i, "0");
				}
			}

			Integer projectId = (Integer) request.getSession().getAttribute(SessionKeys.PROJECT_ID.name());
			ProjectCurrencyLogic pclogic = new ProjectCurrencyLogic();
			ProjectCurrencyBean pcbean = new ProjectCurrencyBean();
			pcbean.setProjectId(projectId);
			pcbean.setCurrencyId(Integer.parseInt(seltool));
			List<ProjectCurrencyBean> pclst = new ArrayList<>();
			if (null == pcid || pcid.trim().length() == 0 || "0".equals(pcid)) {
				pclst.add(pcbean);
				pclogic.save(pclst);
			} else {
				pcbean.setId(Integer.valueOf(pcid));
				pclst.add(pcbean);
				pclogic.update(pclst);
			}

			TestingToolsLogic ttlogic = new TestingToolsLogic();
			boolean isNew = true;

			List<TestingToolsBean> ts = new ArrayList<>();
			int cntt = ttids.length;

			for (int i = 0; i < cntt; i++) {
				String ttid = ttids[i];
				String toolId = toolIds[i];
				String toolCost = ar.get(i);
				String tooltype = tooltypes[i];
				if (null == ttid || ttid.trim().length() == 0) {
					ttid = "0";
				}
				TestingToolsBean ttbean = new TestingToolsBean();
				if (null != toolId && toolId.length() > 0) {
					ttbean = ttlogic.getBeanById(ttid);
					if (ttbean.getId() > 0) {
						isNew = false;
					}
				}
				if (null == toolCost || toolCost.length() == 0) {
					toolCost = "0";
				}

				if (tooltype == "Open Source") {
					toolCost = "0.0";

				}

				ttbean.setId(Integer.parseInt(ttid));
				ttbean.setProjectId(projectId);
				ttbean.setLicenseCost(Float.parseFloat(toolCost));
				ttbean.setToolId(Integer.parseInt(toolId));
				ttbean.setLicensetype(tooltype);

				ts.add(ttbean);
			}
			if (isNew) {
				ttlogic.save(ts);
			} else {
				ttlogic.update(ts);
			}

			showMessage(request, MSG_SAVE_SUCCESS);
		} catch (Exception e) {
			showMessage(request, MSG_SAVE_FAIL);
			logError("Page[Configuration]:", e);
		} finally {
			forwardRequest(request, response, PageUrl.TOOLCONFIGURE);
		}
	}

}
