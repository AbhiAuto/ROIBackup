package com.ust.servlets;

import static com.ust.roi.util.helper.CommonUtil.getEmptyAsZero;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ust.roi.abstracts.AbstractServlet;
import com.ust.roi.db.model.InputUserBean;
import com.ust.roi.db.model.TestingToolsUsedBean;
import com.ust.roi.logic.InputFromUserLogic;
import com.ust.roi.logic.TestingToolsLogic;
import com.ust.roi.logic.TestingToolsUsedLogic;
import com.ust.roi.sec.PageUrl;
import com.ust.roi.sec.SessionKeys;

@WebServlet("/UserInput")
public class SrvUserInput extends AbstractServlet {

	private static final long serialVersionUID = -665686831938356499L;

	public SrvUserInput() {
		super();
	}

	@Override
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String[] ids = request.getParameterValues("id");
			String[] tids = request.getParameterValues("tid");
			String[] cpxhighs = request.getParameterValues("cpxhigh");
			String[] cpxmediums = request.getParameterValues("cpxmedium");
			String[] cpxlows = request.getParameterValues("cpxlow");
			String[] cpxtotals = request.getParameterValues("cpxtotal");
			String[] ttid = request.getParameterValues("ttid");
			String[] liccnt = request.getParameterValues("liccnt");
			String[] cylcnt = request.getParameterValues("cylcnt");
			// String[] toolid = request.getParameterValues("toolid");
			String[] yearid = request.getParameterValues("yearid");
			String[] seltool = request.getParameterValues("seltool");
			int cnt = ids.length;
			List<InputUserBean> lst = new ArrayList<>();
			InputFromUserLogic logic = new InputFromUserLogic();
			TestingToolsLogic logic1 = new TestingToolsLogic();
			Integer prjId = (Integer) request.getSession().getAttribute(SessionKeys.PROJECT_ID.name());
			boolean isNew = true;
			for (int i = 0; i < cnt; i++) {
				String id = getEmptyAsZero(ids[i]);
				String tid = getEmptyAsZero(tids[i]);
				InputUserBean bean = logic.getBeanById(id);
				if (null == bean) {
					bean = new InputUserBean();
					bean.setTypeId(Integer.parseInt(tid));
				}
				if (null != bean.getId() && bean.getId() > 0) {
					isNew = false;
				}
				bean.setProjectId(prjId);
				bean.setComplexityHigh(Float.parseFloat(getEmptyAsZero(cpxhighs[i])));
				bean.setComplexityMedium(Float.parseFloat(getEmptyAsZero(cpxmediums[i])));
				bean.setComplexityLow(Float.parseFloat(getEmptyAsZero(cpxlows[i])));
				bean.setTotalVal(Float.parseFloat(getEmptyAsZero(cpxtotals[i])));
				lst.add(bean);
			}
			if (isNew) {
				logic.save(lst);
			} else {
				logic.update(lst);
			}
			cnt = ttid.length;
			List<TestingToolsUsedBean> ttlst = new ArrayList<>();
			TestingToolsUsedLogic ttlogic = new TestingToolsUsedLogic();
			isNew = true;
			for (int i = 0; i < cnt; i++) {
				String id = getEmptyAsZero(ttid[i]);
				TestingToolsUsedBean bean = ttlogic.getBeanById(id);
				if (null == bean) {
					bean = new TestingToolsUsedBean();
				}
				if (null != bean.getId() && bean.getId() > 0) {
					isNew = false;
				}
				bean.setProjectId((Integer) request.getSession().getAttribute(SessionKeys.PROJECT_ID.name()));
				bean.setToolId(Integer.parseInt(getEmptyAsZero(seltool[i])));
				if (null == bean.getToolId() || bean.getToolId() == 0) {
					bean.setToolId(logic1.getToolForProjectId("" + prjId).getToolId());
				}
				bean.setYearId(Integer.parseInt(getEmptyAsZero(yearid[i])));
				bean.setLicenseCount(Integer.parseInt(getEmptyAsZero(liccnt[i])));
				bean.setTestCyclesCount(Integer.parseInt(getEmptyAsZero(cylcnt[i])));
				ttlst.add(bean);
			}
			if (isNew) {
				ttlogic.save(ttlst);
			} else {
				ttlogic.update(ttlst);
			}
			showMessage(request, MSG_SAVE_SUCCESS);
		} catch (Exception e) {
			showMessage(request, MSG_SAVE_FAIL);
			logError("Page[Create User]:", e);
		} finally {
			forwardRequest(request, response, PageUrl.USERINPUT);
		}
	}
}
