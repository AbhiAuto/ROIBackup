package com.ust.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ust.roi.abstracts.AbstractServlet;
import com.ust.roi.db.model.ConfigureElementBean;
import com.ust.roi.logic.ConfigureElementLogic;
import com.ust.roi.sec.PageUrl;
import com.ust.roi.sec.SecUtils;
import com.ust.roi.sec.SessionKeys;

@WebServlet("/Configure")
public class SrvConfigure extends AbstractServlet {

	private static final long serialVersionUID = -9113234102267180225L;

	public SrvConfigure() {
		super();
	}
	
	
	@Override
	public void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String[] ids = request.getParameterValues("id");
			String[] ivalueds = request.getParameterValues("ivalue");
			String[] cids = request.getParameterValues("cid");
			int cnt = ids.length;
			List<ConfigureElementBean> lst = new ArrayList<>();
			ConfigureElementLogic logic = new ConfigureElementLogic();
			boolean isNew = true;
			Integer projectId = (Integer) request.getSession().getAttribute(SessionKeys.PROJECT_ID.name());
			isNew = true;
			for (int i = 0; i < cnt; i++) {
				String id = SecUtils.deHidValue(ids[i]);
				String val = ivalueds[i];
				String cid = SecUtils.deHidValue(cids[i]);
				if (null == id || id.length() == 0) {
					id = "0";
				}
				if (null == val || val.length() == 0) {
					val = "0";
				}
				if (null == cid || cid.length() == 0) {
					cid = "0";
				}
				ConfigureElementBean bean = logic.getBeanById(id);
				if (null == bean) {
					bean = new ConfigureElementBean();
					bean.setConfigId(Integer.parseInt(cid));
				}
				bean.setValue(val);
				if (null != bean.getId() && bean.getId() > 0) {
					isNew = false;
				}
				bean.setProjectId(projectId);
				lst.add(bean);
			}
			if (isNew) {
				logic.save(lst);
			} else {
				logic.update(lst);
			}
			showMessage(request, MSG_SAVE_SUCCESS);
		} catch (Exception e) {
			showMessage(request, MSG_SAVE_FAIL);
			logError("Page[Configuration]:", e);
		} finally {
			forwardRequest(request, response, PageUrl.CONFIGURATION);
		}
	}

}
