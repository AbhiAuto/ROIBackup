


package com.ust.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ust.roi.abstracts.AbstractServlet;
import com.ust.roi.db.model.MaintenanceEffortBean;
import com.ust.roi.db.model.ProjectUserBean;
import com.ust.roi.db.model.UserBean;
import com.ust.roi.db.model.UserRoleBean;
import com.ust.roi.logic.MaintenanceEffortLogic;
import com.ust.roi.logic.ProjectUserLogic;
import com.ust.roi.logic.UserLogic;
import com.ust.roi.logic.UserRoleLogic;
import com.ust.roi.sec.PageUrl;

@WebServlet("/CreateMaintenance")
public class SrvMaintenance extends AbstractServlet {

	

	public SrvMaintenance() {
		super();
	}

	@Override
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			
			String uname = request.getParameter("uname");
			String fname = request.getParameter("fname");
		
			String prjid = request.getParameter("selprj");
			if (null == prjid || prjid.trim().length() == 0) {
				prjid = "0";
			}

			MaintenanceEffortLogic logic = new MaintenanceEffortLogic();
			List<MaintenanceEffortBean> lst = new ArrayList<>();
			MaintenanceEffortBean bean = new MaintenanceEffortBean();
			bean.setdate(uname);
			bean.sethours(fname);
			
			bean.setProjectId(Integer.parseInt(prjid));
			lst.add(bean);
			//logic.save(lst);
			showMessage(request, MSG_SAVE_SUCCESS);
		} catch (Exception e) {
			showMessage(request, MSG_SAVE_FAIL);
			logError("Page[Create User]:", e);
		} finally {
			forwardRequest(request, response, PageUrl.USERMANAGEMENT);
		}
	}
}
	