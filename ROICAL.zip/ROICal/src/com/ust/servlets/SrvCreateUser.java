package com.ust.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ust.roi.abstracts.AbstractServlet;
import com.ust.roi.db.model.ProjectUserBean;
import com.ust.roi.db.model.UserBean;
import com.ust.roi.db.model.UserRoleBean;
import com.ust.roi.logic.ProjectUserLogic;
import com.ust.roi.logic.UserLogic;
import com.ust.roi.logic.UserRoleLogic;
import com.ust.roi.sec.PageUrl;

@WebServlet("/CreateUser")
public class SrvCreateUser extends AbstractServlet {

	private static final long serialVersionUID = 3485242956047088132L;

	public SrvCreateUser() {
		super();
	}

	@Override
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			if (!validateField(request)) {
				return;
			}
			String uname = request.getParameter("uname");
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String email = request.getParameter("email");
			String upass = request.getParameter("upass");
			String prjid = request.getParameter("selprj");
			if (null == prjid || prjid.trim().length() == 0) {
				prjid = "0";
			}

			UserLogic logic = new UserLogic();
			List<UserBean> lst = new ArrayList<>();
			UserBean bean = new UserBean();
			bean.setUsername(uname);
			bean.setFirstName(fname);
			bean.setLastName(lname);
			bean.setEmail(email);
			bean.setPassword(upass);
			bean.setProjectId(Integer.parseInt(prjid));
			lst.add(bean);
			logic.save(lst);
			UserBean sbean = logic.getBeanByUserName(uname);
			if (null != sbean) {
				UserRoleLogic urlogic = new UserRoleLogic();
				List<UserRoleBean> urlst = new ArrayList<>();
				UserRoleBean urbean = new UserRoleBean();
				urbean.setUserName(uname);
				urbean.setRoleName("user");
				urlst.add(urbean);
				urlogic.save(urlst);

				ProjectUserLogic pulogic = new ProjectUserLogic();
				List<ProjectUserBean> pulst = new ArrayList<>();
				ProjectUserBean pubean = new ProjectUserBean();
				pubean.setProjectId(Integer.parseInt(prjid));
				pubean.setUserId(sbean.getId());
				pulst.add(pubean);
				pulogic.save(pulst);
			}
			showMessage(request, MSG_SAVE_SUCCESS);
		} catch (Exception e) {
			showMessage(request, MSG_SAVE_FAIL);
			logError("Page[Create User]:", e);
		} finally {
			forwardRequest(request, response, PageUrl.USERMANAGEMENT);
		}
	}

	private boolean validateField(HttpServletRequest request) {
		boolean status = true;
		clearMessage();
		UserLogic logic = new UserLogic();
		if (status && isParameterEmpty("uname")) {
			status = false;
			showMessage("User Name is mandatory.");
		}
		if (status && isParameterEmpty("fname")) {
			status = false;
			showMessage("First Name is mandatory.");
		}
		if (status && isParameterEmpty("lname")) {
			status = false;
			showMessage("Last Name is mandatory.");
		}
		if (status && isParameterEmpty("email")) {
			status = false;
			showMessage("E-Mail is mandatory.");
		}
		String uname = getParameterValue("uname");
		UserBean sbean = logic.getBeanByUserName(uname);
		if (status && null != sbean) {
			status = false;
			showMessage("User Name already exists.");
		}
		return status;
	}
}
