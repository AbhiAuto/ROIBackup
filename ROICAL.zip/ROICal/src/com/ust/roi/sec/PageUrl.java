package com.ust.roi.sec;

public enum PageUrl {
	TOOLCONFIGURE("pages/admins/toolconfig.jsp?s=1"),
	USERINPUT("pages/users/uinput.jsp?s=1"), USERASSIGN("pages/admins/userassignment.jsp?s=1"), USERMANAGEMENT(
			"pages/admins/usermanagement.jsp?s=1"), NEWPROJECT(
					"pages/admins/newproject.jsp?s=1"), CONFIGURATION("pages/admins/configuration.jsp?s=1");

	private String url;

	private PageUrl(String url) {
		this.url = url;
	}

	public String getURL() {
		return url;
	}
}
