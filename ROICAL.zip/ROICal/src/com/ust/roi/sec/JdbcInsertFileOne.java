package com.ust.roi.sec;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcInsertFileOne {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/roicaldb";
		String user = "test";
		String pass = "test123";
		String filePath = "D:/Test/demo.png";
		try {
			try (Connection conn = DriverManager.getConnection(url, user, pass)) {
				String sql = "INSERT INTO file_data (code, name, mime_type,BIN_DATA) values (?, ?, ?,?)";
				try (PreparedStatement statement = conn.prepareStatement(sql)) {
					statement.setString(1, "AX01");
					statement.setString(2, "demo.png");
					statement.setString(3, "application/octastream");
					InputStream inputStream = new FileInputStream(new File(filePath));
					statement.setBlob(4, inputStream);
					int row = statement.executeUpdate();
					if (row > 0) {
						System.out.println("A contact was inserted with photo image.");
					}
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
