package com.ust.roi.sec;

import java.security.GeneralSecurityException;
import java.security.spec.KeySpec;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.jasypt.util.text.BasicTextEncryptor;

public class SecUtils {

	private static final boolean ENABLE_SEC = false;

	private SecUtils() {

	}

	public static String encode(String text) {
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPassword("JKN1NW1TH11$TR)IC@L");
		return textEncryptor.encrypt(text);
	}

	public static String decode(String enval) {
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPassword("JKN1NW1TH11$TR)IC@L");
		return textEncryptor.decrypt(enval);
	}

	public static SecretKey generateKeyFromPassword(String password, byte[] saltBytes) throws GeneralSecurityException {
		KeySpec keySpec = new PBEKeySpec(password.toCharArray(), saltBytes, 100, 128);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
		SecretKey secretKey = keyFactory.generateSecret(keySpec);
		return new SecretKeySpec(secretKey.getEncoded(), "AES");
	}

	public static byte[] hexStringToByteArray(String s) {
		int len = s.length();
		byte[] data = new byte[len / 2];
		for (int i = 0; i < len; i += 2) {
			data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
		}
		return data;
	}

	public static String decrypt_old(String encryptedData, SecretKeySpec sKey, IvParameterSpec ivParameterSpec)
			throws Exception {
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		c.init(Cipher.DECRYPT_MODE, sKey, ivParameterSpec);
		@SuppressWarnings("restriction")
		byte[] decordedValue = new sun.misc.BASE64Decoder().decodeBuffer(encryptedData);
		byte[] decValue = c.doFinal(decordedValue);
		return  new String(decValue);
	}
	
	public static String decrypt(String encryptedData, SecretKeySpec sKey, IvParameterSpec ivParameterSpec)
			throws Exception {
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		c.init(Cipher.DECRYPT_MODE, sKey, ivParameterSpec);
		@SuppressWarnings("restriction")
		byte[] decordedValue = new sun.misc.BASE64Decoder().decodeBuffer(encryptedData);
		byte[] decValue = c.doFinal(decordedValue);
		return  new String(decValue);
	}

	public static String encodeString(String val) {
		String code = val;
		code = code.replaceAll("<", "&lt;");
		code = code.replaceAll(">", "&gt;");
		code = code.replaceAll("(", "&#40;");
		code = code.replaceAll(")", "&#41;");
		code = code.replaceAll("*", "&#42;");
		code = code.replaceAll("&", "&amp;");
		code = code.replaceAll("javascript", "");
		return code;
	}

	public static String decodeString(String val) {
		String code = val;
		code = code.replaceAll("&lt;", "<");
		code = code.replaceAll("&gt;", ">");
		code = code.replaceAll("&#40;", "(");
		code = code.replaceAll("&#41;", ")");
		code = code.replaceAll("&#42;", "*");
		code = code.replaceAll("&amp;", "&");
		return code;
	}

	public static String generateKey1() {
		StringBuilder sb = new StringBuilder();
		SecureRandomNumberGenerator srng = new SecureRandomNumberGenerator();
		for (int i = 0; i < 4; i++) {
			sb.append(Integer.toString(srng.getSecureRandom().nextInt()));
		}
		return sb.toString().replaceAll("-", "");
	}

	public static String generateKey() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	public static String enHidValue(String val) {
		if (!ENABLE_SEC) {
			return val;
		}
		return encode(val);
	}

	public static String deHidValue(String val) {
		if (!ENABLE_SEC) {
			return val;
		}
		return decode(val);
	}
}
