package com.ust.roi.sec;

public enum SessionKeys {
	PROJECT_ID,
	PROJECT_NAME,
	APP_NAME,
	UNAME,
	USRBEAN
}
