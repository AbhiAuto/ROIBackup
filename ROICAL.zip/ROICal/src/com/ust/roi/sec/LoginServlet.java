package com.ust.roi.sec;

import java.io.IOException;
import java.security.GeneralSecurityException;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.ExcessiveAttemptsException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ust.roi.db.model.UserBean;
import com.ust.roi.logic.UserLogic;

@WebServlet("/LoginSec")
public class LoginServlet extends HttpServlet {
	private static final Logger logger = LoggerFactory.getLogger(LoginServlet.class);

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String password = (String) req.getSession().getAttribute("KEYB");
		String salt = (String) req.getSession().getAttribute("SALT");
		String iv = (String) req.getSession().getAttribute("IV");
		byte[] saltBytes = SecUtils.hexStringToByteArray(salt);
		byte[] ivBytes = SecUtils.hexStringToByteArray(iv);
		IvParameterSpec ivParameterSpec = new IvParameterSpec(ivBytes);
		SecretKeySpec sKey = null;
		try {
			sKey = (SecretKeySpec) SecUtils.generateKeyFromPassword(password, saltBytes);
		} catch (GeneralSecurityException e1) {
			logger.warn("Failing send 1:", e1);
		}
		String uname = "";
		try {
			uname = SecUtils.decrypt(req.getParameter("uname"), sKey, ivParameterSpec);
		} catch (Exception e1) {
			logger.warn("Failing send 2:", e1);
		}
		String upass = "";
		try {
			upass = SecUtils.decrypt(req.getParameter("upass"), sKey, ivParameterSpec);
		} catch (Exception e1) {
			logger.warn("Failing send 3:", e1);
		}
		UsernamePasswordToken token = new UsernamePasswordToken(uname, upass);
		Subject currentUser = SecurityUtils.getSubject();
		boolean status = false;
		try {
			currentUser.login(token);
			status = true;
		} catch (UnknownAccountException uae) {
			logger.warn("Failing login with 401:", uae);
		} catch (IncorrectCredentialsException ice) {
			logger.warn("Failing login with 402:", ice);
		} catch (LockedAccountException lae) {
			logger.warn("Failing login with 403:", lae);
		} catch (ExcessiveAttemptsException eae) {
			logger.warn("Failing login with 404:", eae);
		} catch (AuthenticationException ae) {
			logger.warn("Failing login with 405:", ae);
		}
		if (status) {
			req.getSession().setAttribute("err", "");
			UserLogic ulogic = new UserLogic();
			UserBean bean = ulogic.getBeanByUserName(uname);
			req.getSession().setAttribute(SessionKeys.USRBEAN.name(), bean);
			req.getSession().setAttribute("shiroLoginFailure", "");
			req.getSession().setAttribute(SessionKeys.UNAME.name(), bean.getDisplayName());
			try {
				resp.sendRedirect("pages/sec/home.jsp");
			} catch (Exception e) {
				logger.warn("Failing send :", e);
			}
		} else {
			req.getSession().setAttribute("err", "Invalid User Name and Password.");
			RequestDispatcher rd = req.getRequestDispatcher("/pages/sec/login.jsp");
			try {
				rd.forward(req, resp);
			} catch (Exception e) {
				logger.warn("Failing send 4:", e);
			}
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
