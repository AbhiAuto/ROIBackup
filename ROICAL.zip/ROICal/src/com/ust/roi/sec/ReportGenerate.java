package com.ust.roi.sec;

import java.util.ArrayList;
import java.util.HashMap;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class ReportGenerate {
	public static ArrayList<DataBean> getDataBeanList() {
		ArrayList<DataBean> dataBeanList = new ArrayList<DataBean>();

		dataBeanList.add(produce("Manisha", "India"));
		dataBeanList.add(produce("Dennis Ritchie", "USA"));
		dataBeanList.add(produce("V.Anand", "India"));
		dataBeanList.add(produce("Shrinath", "California"));

		return dataBeanList;
	}

	/**
	 * This method returns a DataBean object, with name and country set in it.
	 */
	private static DataBean produce(String name, String country) {
		DataBean dataBean = new DataBean();
		dataBean.setName(name);
		dataBean.setCountry(country);

		return dataBean;
	}

	public static void main(String[] args) {

		ArrayList<DataBean> dataList = getDataBeanList();

		JRBeanCollectionDataSource beanBurritoWrap = new JRBeanCollectionDataSource(dataList);

		JasperReport jasperReport;
		JasperPrint jasperPrint;
		HashMap<String, Object> hashMap = new HashMap<>();
		hashMap.put("ReportTitle", "List of Contacts");
		hashMap.put("Author", "Prepared By JKN");
		boolean reportCreated;
		String outFile = "D:/Test/test.pdf";
		try {
			jasperReport = JasperCompileManager.compileReport("D:/Test/test.jrxml");
			jasperPrint = JasperFillManager.fillReport(jasperReport, hashMap, beanBurritoWrap);
			JasperExportManager.exportReportToPdfFile(jasperPrint, outFile);
			reportCreated = true;
		} catch (JRException e) {
			e.printStackTrace();
			reportCreated = false;
		}

		// Report on build status
		System.out.println("Jasper Report built: " + reportCreated);

	}
}
