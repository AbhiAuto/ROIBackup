package com.ust.roi.db.model;

import java.io.Serializable;
import com.ust.roi.abstracts.AbstractModel;

public class TestingToolsBean extends AbstractModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer projectId;
	private Integer toolId;
	private String toolName;
	private Float actualCost;
	private Float licenseCost;
	private String licenseType;

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getToolId() {
		return toolId;
	}

	public void setToolId(Integer toolId) {
		this.toolId = toolId;
	}

	public String getToolName() {
		return toolName;
	}

	public void setToolName(String toolName) {
		this.toolName = toolName;
	}

	public Float getActualCost() {
		return actualCost;
	}

	public void setActualCost(Float actualCost) {
		this.actualCost = actualCost;
	}

	public Float getLicenseCost() {
		return licenseCost;
	}

	public void setLicenseCost(Float licenseCost) {
		this.licenseCost = licenseCost;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getLicensetype() {
		return licenseType;
	}

	public void setLicensetype(String licenseType) {
		this.licenseType = licenseType;
	}

}
