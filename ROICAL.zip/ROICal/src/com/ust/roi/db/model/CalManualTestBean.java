package com.ust.roi.db.model;

public class CalManualTestBean {
	private String manualTestCases;
	private String highTestCases;
	private String mediumTestCases;
	private String lowTestCases;
	private String highTestCaseExecutionEffect;
	private String mediumTestCaseExecutionEffect;
	private String lowTestCaseExecutionEffect;
	private String totalHours;
	private String onsiteHours;
	private String offshoreHours;
	private String onsiteCost;
	//private String offshorHours;
	private String offshoreCost;
	private String totalManualCostPerCycle;
	private String TotalManualCostRealTime;

	public String getManualTestCases() {
		return manualTestCases;
	}

	public void setManualTestCases(String manualTestCases) {
		this.manualTestCases = manualTestCases;
	}

	public String getHighTestCases() {
		return highTestCases;
	}

	public void setHighTestCases(String highTestCases) {
		this.highTestCases = highTestCases;
	}

	public String getMediumTestCases() {
		return mediumTestCases;
	}

	public void setMediumTestCases(String mediumTestCases) {
		this.mediumTestCases = mediumTestCases;
	}

	public String getLowTestCases() {
		return lowTestCases;
	}

	public void setLowTestCases(String lowTestCases) {
		this.lowTestCases = lowTestCases;
	}

	public String getHighTestCaseExecutionEffect() {
		return highTestCaseExecutionEffect;
	}

	public void setHighTestCaseExecutionEffect(String highTestCaseExecutionEffect) {
		this.highTestCaseExecutionEffect = highTestCaseExecutionEffect;
	}

	public String getMediumTestCaseExecutionEffect() {
		return mediumTestCaseExecutionEffect;
	}

	public void setMediumTestCaseExecutionEffect(String mediumTestCaseExecutionEffect) {
		this.mediumTestCaseExecutionEffect = mediumTestCaseExecutionEffect;
	}

	public String getLowTestCaseExecutionEffect() {
		return lowTestCaseExecutionEffect;
	}

	public void setLowTestCaseExecutionEffect(String lowTestCaseExecutionEffect) {
		this.lowTestCaseExecutionEffect = lowTestCaseExecutionEffect;
	}

	public String getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(String totalHours) {
		this.totalHours = totalHours;
	}

	public String getOnsiteHours() {
		return onsiteHours;
	}

	public void setOnsiteHours(String onsiteHours) {
		this.onsiteHours = onsiteHours;
	}

	public String getOffshoreHours() {
		return offshoreHours;
	}

	public void setOffshoreHours(String offshoreHours) {
		this.offshoreHours = offshoreHours;
	}

	public String getOnsiteCost() {
		return onsiteCost;
	}

	public void setOnsiteCost(String onsiteCost) {
		this.onsiteCost = onsiteCost;
	}
/*
	public String getOffshorHours() {
		return offshorHours;
	}

	public void setOffshorHours(String offshorHours) {
		this.offshorHours = offshorHours;
	} */

	public String getTotalManualCostPerCycle() {
		return totalManualCostPerCycle;
	}

	public void setTotalManualCostPerCycle(String totalManualCostPerCycle) {
		this.totalManualCostPerCycle = totalManualCostPerCycle;
	}

	public String getOffshoreCost() {
		return offshoreCost;
	}

	public void setOffshoreCost(String offshoreCost) {
		this.offshoreCost = offshoreCost;
	}
	
	public String getTotalManualCostRealTime() {
		return TotalManualCostRealTime;
	}

	public void setTotalManualCostRealTime(String TotalManualCostRealTime) {
		this.TotalManualCostRealTime = TotalManualCostRealTime;
	}

	@Override
	public String toString() {
		return "CalManualTestBean [manualTestCases=" + manualTestCases + ", highTestCases=" + highTestCases
				+ ", mediumTestCases=" + mediumTestCases + ", lowTestCases=" + lowTestCases
				+ ", highTestCaseExecutionEffect=" + highTestCaseExecutionEffect + ", mediumTestCaseExecutionEffect="
				+ mediumTestCaseExecutionEffect + ", lowTestCaseExecutionEffect=" + lowTestCaseExecutionEffect
				+ ", totalHours=" + totalHours + ", onsiteHours=" + onsiteHours + ", offshoreHours=" + offshoreHours
				+ ", onsiteCost=" + onsiteCost + ", offshoreCost=" + offshoreCost
				+ ", totalManualCostPerCycle=" + totalManualCostPerCycle + "]";
	}

	
	
}
