package com.ust.roi.db.model;

public class Yes {
public  void ft() {
	System.out.println("1");
}
}
