/*package com.ust.roi.db.model;

import static com.ust.roi.util.helper.CommonUtil.getDouble;
import static com.ust.roi.util.helper.CommonUtil.getString;

import com.ust.roi.logic.CalculationFormulaLogic;

public class Test {
	public static void main(String[] args) {
		String str = "123.67";
		Object r = Double.parseDouble(str);
System.out.println(r);
	}

	}
*/