package com.ust.roi.db.model;

public class CalAutoScriptDevBean {

    private String autoTestCases;
    private String highTestCase;
    private String mediumTestCase;
    private String lowTestCase;
    private String highTestCaseDevEffort;
    private String mediumTestCaseDevEffort;
    private String lowTestCaseDevEffort;
    private String frameworkDev;
    private String totalHours;
    private String onsiteHours;
    private String offshoreHours;
    private String onsiteCost;
    private String offshoreCost;
    private String totalCostForScriptDev;

    /**
     * @return the autoTestCases
     */
    public String getAutoTestCases() {
        return autoTestCases;
    }

    /**
     * @param autoTestCases the autoTestCases to set
     */
    public void setAutoTestCases(String autoTestCases) {
        this.autoTestCases = autoTestCases;
    }

    /**
     * @return the highTestCase
     */
    public String getHighTestCase() {
        return highTestCase;
    }

    /**
     * @param highTestCase the highTestCase to set
     */
    public void setHighTestCase(String highTestCase) {
        this.highTestCase = highTestCase;
    }

    /**
     * @return the mediumTestCase
     */
    public String getMediumTestCase() {
        return mediumTestCase;
    }

    /**
     * @param mediumTestCase the mediumTestCase to set
     */
    public void setMediumTestCase(String mediumTestCase) {
        this.mediumTestCase = mediumTestCase;
    }

    /**
     * @return the lowTestCase
     */
    public String getLowTestCase() {
        return lowTestCase;
    }

    /**
     * @param lowTestCase the lowTestCase to set
     */
    public void setLowTestCase(String lowTestCase) {
        this.lowTestCase = lowTestCase;
    }

    /**
     * @return the highTestCaseDevEffort
     */
    public String getHighTestCaseDevEffort() {
        return highTestCaseDevEffort;
    }

    /**
     * @param highTestCaseDevEffort the highTestCaseDevEffort to set
     */
    public void setHighTestCaseDevEffort(String highTestCaseDevEffort) {
        this.highTestCaseDevEffort = highTestCaseDevEffort;
    }

    /**
     * @return the mediumTestCaseDevEffort
     */
    public String getMediumTestCaseDevEffort() {
        return mediumTestCaseDevEffort;
    }

    /**
     * @param mediumTestCaseDevEffort the mediumTestCaseDevEffort to set
     */
    public void setMediumTestCaseDevEffort(String mediumTestCaseDevEffort) {
        this.mediumTestCaseDevEffort = mediumTestCaseDevEffort;
    }

    /**
     * @return the lowTestCaseDevEffort
     */
    public String getLowTestCaseDevEffort() {
        return lowTestCaseDevEffort;
    }

    /**
     * @param lowTestCaseDevEffort the lowTestCaseDevEffort to set
     */
    public void setLowTestCaseDevEffort(String lowTestCaseDevEffort) {
        this.lowTestCaseDevEffort = lowTestCaseDevEffort;
    }

    /**
     * @return the frameworkDev
     */
    public String getFrameworkDev() {
        return frameworkDev;
    }

    /**
     * @param frameworkDev the frameworkDev to set
     */
    public void setFrameworkDev(String frameworkDev) {
        this.frameworkDev = frameworkDev;
    }

    /**
     * @return the totalHours
     */
    public String getTotalHours() {
        return totalHours;
    }

    /**
     * @param totalHours the totalHours to set
     */
    public void setTotalHours(String totalHours) {
        this.totalHours = totalHours;
    }

    /**
     * @return the onsiteHours
     */
    public String getOnsiteHours() {
        return onsiteHours;
    }

    /**
     * @param onsiteHours the onsiteHours to set
     */
    public void setOnsiteHours(String onsiteHours) {
        this.onsiteHours = onsiteHours;
    }

    /**
     * @return the offshoreHours
     */
    public String getOffshoreHours() {
        return offshoreHours;
    }

    /**
     * @param offshoreHours the offshoreHours to set
     */
    public void setOffshoreHours(String offshoreHours) {
        this.offshoreHours = offshoreHours;
    }

    /**
     * @return the onsiteCost
     */
    public String getOnsiteCost() {
        return onsiteCost;
    }

    /**
     * @param onsiteCost the onsiteCost to set
     */
    public void setOnsiteCost(String onsiteCost) {
        this.onsiteCost = onsiteCost;
    }

    /**
     * @return the offshoreCost
     */
    public String getOffshoreCost() {
        return offshoreCost;
    }

    /**
     * @param offshoreCost the offshoreCost to set
     */
    public void setOffshoreCost(String offshoreCost) {
        this.offshoreCost = offshoreCost;
    }

    /**
     * @return the totalCostForScriptDev
     */
    public String getTotalCostForScriptDev() {
        return totalCostForScriptDev;
    }

    /**
     * @param totalCostForScriptDev the totalCostForScriptDev to set
     */
    public void setTotalCostForScriptDev(String totalCostForScriptDev) {
        this.totalCostForScriptDev = totalCostForScriptDev;
    }

	@Override
	public String toString() {
		return "CalAutoScriptDevBean [autoTestCases=" + autoTestCases + ", highTestCase=" + highTestCase
				+ ", mediumTestCase=" + mediumTestCase + ", lowTestCase=" + lowTestCase + ", highTestCaseDevEffort="
				+ highTestCaseDevEffort + ", mediumTestCaseDevEffort=" + mediumTestCaseDevEffort
				+ ", lowTestCaseDevEffort=" + lowTestCaseDevEffort + ", frameworkDev=" + frameworkDev + ", totalHours="
				+ totalHours + ", onsiteHours=" + onsiteHours + ", offshoreHours=" + offshoreHours + ", onsiteCost="
				+ onsiteCost + ", offshoreCost=" + offshoreCost + ", totalCostForScriptDev=" + totalCostForScriptDev
				+ "]";
	}

    
    
}
