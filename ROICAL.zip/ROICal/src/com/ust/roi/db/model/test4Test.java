/*package com.ust.roi.db.model;
import org.testng.annotations.Test;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.testng.annotations.Test;


public class test4Test {
	
		

		  @Test
		public void f() throws InterruptedException {

		 
		System.out.println("x");
		Thread.sleep(4000);
		  }
		@Test
		public void ft() throws InterruptedException {


		System.out.println("y");
		Thread.sleep(4000);



		  }
		@Test
		public void ft1() throws InterruptedException {


		System.out.println("y");
		Thread.sleep(6000);
		}
		@Test
		public void fq() throws InterruptedException {


		System.out.println("y");
		Thread.sleep(3000);
		}
		@Test
		public void fw() throws InterruptedException {

		 
		System.out.println("x");
		Thread.sleep(1000);
		  }
		@Test
		public void fr() throws InterruptedException {


		System.out.println("y");
		Thread.sleep(5000);



		  }
		@Test
		public void fy1() throws InterruptedException {


		System.out.println("y");
		Thread.sleep(6000);
		}
		@Test
		public void fl() throws InterruptedException {


		System.out.println("y");
		Thread.sleep(6000);


		  }
		  
		}



*/