package com.ust.roi.db.model;

public class CalAutoScriptMait {

	private String automationScript;
	private String hoursRequiredForMaintanence;
	private String costOfAutoMaintanenceAtOffshore;

	public String getAutomationScript() {
		return automationScript;
	}

	public void setAutomationScript(String automationScript) {
		this.automationScript = automationScript;
	}

	public String getHoursRequiredForMaintanence() {
		return hoursRequiredForMaintanence;
	}

	public void setHoursRequiredForMaintanence(String hoursRequiredForMaintanence) {
		this.hoursRequiredForMaintanence = hoursRequiredForMaintanence;
	}

	public String getCostOfAutoMaintanenceAtOffshore() {
		return costOfAutoMaintanenceAtOffshore;
	}

	public void setCostOfAutoMaintanenceAtOffshore(String costOfAutoMaintanenceAtOffshore) {
		this.costOfAutoMaintanenceAtOffshore = costOfAutoMaintanenceAtOffshore;
	}

	@Override
	public String toString() {
		return "CalAutoScriptMait [automationScript=" + automationScript + ", hoursRequiredForMaintanence="
				+ hoursRequiredForMaintanence + ", costOfAutoMaintanenceAtOffshore=" + costOfAutoMaintanenceAtOffshore
				+ "]";
	}
	
	

}
