package com.ust.roi.db.model;

import java.io.Serializable;

import com.ust.roi.abstracts.AbstractModel;

public class ConfigureElementBean extends AbstractModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer configId;
	private String configType;
	private String configName;
	private Integer projectId;
	private String value;
	private String comments;
	private String uiTitle;
	private String other;

	public Integer getConfigId() {
		return configId;
	}

	public void setConfigId(Integer configId) {
		this.configId = configId;
	}

	public String getConfigType() {
		return configType;
	}

	public void setConfigType(String configType) {
		this.configType = configType;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getUiTitle() {
		if (null == uiTitle)
			uiTitle = "";
		return uiTitle;
	}

	public void setUiTitle(String uiTitle) {
		this.uiTitle = uiTitle;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

}
