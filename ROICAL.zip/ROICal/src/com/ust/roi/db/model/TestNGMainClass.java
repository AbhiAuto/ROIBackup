/*package com.ust.roi.db.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.testng.TestNG;

import com.mysql.jdbc.PreparedStatement;

public class TestNGMainClass {
	
	
	
	@SuppressWarnings("deprecation")
	public static  void fun() {
		
		Test5SuiteListener	object = new Test5SuiteListener();
		TestNG testSuite = new TestNG();
		testSuite.setTestClasses(new Class[] { test4Test.class });
		testSuite.addListener(new Test5SuiteListener());
		testSuite.setDefaultSuiteName("My Test Suite");
		testSuite.setDefaultTestName("My Test");
		testSuite.run();
	
	
		
			 
			
	try
    {
    	Test2 tester = new Test2();
    	
    	 String starttime1 = starttime[0];
    	 String time1 = starttime[0];
    	System.out.println(starttime1);
    	String endtime1 = tester.afterTime;
   
 	//long sumDate = endtime.getTime() - ((Date) starttime).getTime();
      // create a mysql database connection
      String myDriver = "org.gjt.mm.mysql.Driver";
      String myUrl = "jdbc:mysql://localhost:3306/roicaldb";
      Class.forName(myDriver);
      Connection conn = DriverManager.getConnection(myUrl, "root", "password");
    
      // create a sql date object so we can use it in our INSERT statement
     

      
     
      // the mysql insert statement
      String query = " insert into roi_testtime(Starttime, Endtime, Extime,Category)"
        + " values (?, ?,?,?)";
      String query1 ="update no_of_test_cases set No = ? where Category='Medium'";
      String query2 = "update no_of_test_cases set No  =? where Category='Low'";
      String query3 ="update no_of_test_cases set No  = ? where Category='High'";


      // create the mysql insert preparedstatement
      java.sql.PreparedStatement preparedStmt = conn.prepareStatement(query);
      java.sql.PreparedStatement preparedStmt1 = conn.prepareStatement(query1);
      java.sql.PreparedStatement preparedStmt2 = conn.prepareStatement(query2);
      java.sql.PreparedStatement preparedStmt3 = conn.prepareStatement(query3);
      for(int i=0;i<=object.time1.size();i++){  
    	
    	
      
	preparedStmt.setString (1, object.time1.get(i) );
     
      
	
preparedStmt.setString(2,   object.time2.get(i));
      
      
	preparedStmt.setString (3, object.extime.get(i));
	preparedStmt.setString (4, object.category.get(i));
	preparedStmt1.setLong (1, object.j);
	preparedStmt2.setLong (1, object.i);
	preparedStmt3.setLong (1, object.k);
    //  preparedStmt.setLong   (3,sumDate );

      // execute the preparedstatement
     
   
	 preparedStmt.execute();
	 preparedStmt1.execute();
	 preparedStmt2.execute();
	 preparedStmt3.execute();
    }
     conn.close();
    }
    catch (Exception e)
    {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
		 }
}
	
*/