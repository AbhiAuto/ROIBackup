package com.ust.roi.db.model;

import java.io.Serializable;

import com.ust.roi.abstracts.AbstractModel;

public class InputUserBean extends AbstractModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer projectId;
	private Integer typeId;
	private String typeName;
	private Float complexityHigh;
	private Float complexityMedium;
	private Float complexityLow;
	private Float totalVal;

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Float getComplexityHigh() {
		return complexityHigh;
	}

	public void setComplexityHigh(Float complexityHigh) {
		this.complexityHigh = complexityHigh;
	}

	public Float getComplexityMedium() {
		return complexityMedium;
	}

	public void setComplexityMedium(Float complexityMedium) {
		this.complexityMedium = complexityMedium;
	}

	public Float getComplexityLow() {
		return complexityLow;
	}

	public void setComplexityLow(Float complexityLow) {
		this.complexityLow = complexityLow;
	}

	public Float getTotalVal() {
		return totalVal;
	}

	public void setTotalVal(Float totalVal) {
		this.totalVal = totalVal;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
