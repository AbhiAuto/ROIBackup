
package com.ust.roi.db.model;

import java.io.Serializable;

import com.ust.roi.abstracts.AbstractModel;

public class MaintenanceEffortBean extends AbstractModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private String date;
	private String hours;
	private Integer projectId;


	public String getdate() {
		return date;
	}

	public void setdate(String date) {
		this.date = date;
	}

	public String gethours() {
		return hours;
	}

	public void sethours(String hours) {
		this.hours = hours;
	}
	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	
}