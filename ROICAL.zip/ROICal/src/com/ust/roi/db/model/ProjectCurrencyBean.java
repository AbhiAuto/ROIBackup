package com.ust.roi.db.model;

import java.io.Serializable;

import com.ust.roi.abstracts.AbstractModel;

public class ProjectCurrencyBean extends AbstractModel implements Serializable {

	private static final long serialVersionUID = -2647420204802571866L;
	private Integer projectId;
	private Integer currencyId;
	private String symbol;

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

}
