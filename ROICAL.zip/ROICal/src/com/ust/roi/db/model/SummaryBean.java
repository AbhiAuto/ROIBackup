package com.ust.roi.db.model;

public class SummaryBean {
	private String noOfTestCyclesY1;
	private String noOfTestCyclesY2;
	private String noOfTestCyclesY3;
	private String noOfTestCyclesY4;
	private String noOfTestCyclesY5;
	private String totalCostOfAutomatedTestingY1;
	private String totalCostOfAutomatedTestingY2;
	private String totalCostOfAutomatedTestingY3;
	private String totalCostOfAutomatedTestingY4;
	private String totalCostOfAutomatedTestingY5;
	private String totalCostForManualTestingY1;
	private String totalCostForManualTestingY2;
	private String totalCostForManualTestingY3;
	private String totalCostForManualTestingY4;
	private String totalCostForManualTestingY5;
	private String totalCostSavedByTestAutomationY1;
	private String totalCostSavedByTestAutomationY2;
	private String totalCostSavedByTestAutomationY3;
	private String totalCostSavedByTestAutomationY4;
	private String totalCostSavedByTestAutomationY5;
	private String automationDevCostY1;
	private String automationDevCostY2;
	private String automationDevCostY3;
	private String automationDevCostY4;
	private String automationDevCostY5;
	private String automationScriptMaintainCostY1;
	private String automationScriptMaintainCostY2;
	private String automationScriptMaintainCostY3;
	private String automationScriptMaintainCostY4;
	private String automationScriptMaintainCostY5;
	private String testingToolLicenseCostY1;
	private String testingToolLicenseCostY2;
	private String testingToolLicenseCostY3;
	private String testingToolLicenseCostY4;
	private String testingToolLicenseCostY5;
	private String totalCostOfAutomationY1;
	private String totalCostOfAutomationY2;
	private String totalCostOfAutomationY3;
	private String totalCostOfAutomationY4;
	private String totalCostOfAutomationY5;
	private String netSavingsY1;
	private String netSavingsY2;
	private String netSavingsY3;
	private String netSavingsY4;
	private String netSavingsY5;
	private String roiPercentageY1;
	private String roiPercentageY2;
	private String roiPercentageY3;
	private String roiPercentageY4;
	private String roiPercentageY5;

	public String getTestingToolLicenseCostY1() {
		return testingToolLicenseCostY1;
	}

	public void setTestingToolLicenseCostY1(String testingToolLicenseCostY1) {
		this.testingToolLicenseCostY1 = testingToolLicenseCostY1;
	}

	public String getTestingToolLicenseCostY2() {
		return testingToolLicenseCostY2;
	}

	public void setTestingToolLicenseCostY2(String testingToolLicenseCostY2) {
		this.testingToolLicenseCostY2 = testingToolLicenseCostY2;
	}

	public String getTestingToolLicenseCostY3() {
		return testingToolLicenseCostY3;
	}

	public void setTestingToolLicenseCostY3(String testingToolLicenseCostY3) {
		this.testingToolLicenseCostY3 = testingToolLicenseCostY3;
	}

	public String getTestingToolLicenseCostY4() {
		return testingToolLicenseCostY4;
	}

	public void setTestingToolLicenseCostY4(String testingToolLicenseCostY4) {
		this.testingToolLicenseCostY4 = testingToolLicenseCostY4;
	}

	public String getTestingToolLicenseCostY5() {
		return testingToolLicenseCostY5;
	}

	public void setTestingToolLicenseCostY5(String testingToolLicenseCostY5) {
		this.testingToolLicenseCostY5 = testingToolLicenseCostY5;
	}

	public String getTotalCostOfAutomationY1() {
		return totalCostOfAutomationY1;
	}

	public void setTotalCostOfAutomationY1(String totalCostOfAutomationY1) {
		this.totalCostOfAutomationY1 = totalCostOfAutomationY1;
	}

	public String getTotalCostOfAutomationY2() {
		return totalCostOfAutomationY2;
	}

	public void setTotalCostOfAutomationY2(String totalCostOfAutomationY2) {
		this.totalCostOfAutomationY2 = totalCostOfAutomationY2;
	}

	public String getTotalCostOfAutomationY3() {
		return totalCostOfAutomationY3;
	}

	public void setTotalCostOfAutomationY3(String totalCostOfAutomationY3) {
		this.totalCostOfAutomationY3 = totalCostOfAutomationY3;
	}

	public String getTotalCostOfAutomationY4() {
		return totalCostOfAutomationY4;
	}

	public void setTotalCostOfAutomationY4(String totalCostOfAutomationY4) {
		this.totalCostOfAutomationY4 = totalCostOfAutomationY4;
	}

	public String getTotalCostOfAutomationY5() {
		return totalCostOfAutomationY5;
	}

	public void setTotalCostOfAutomationY5(String totalCostOfAutomationY5) {
		this.totalCostOfAutomationY5 = totalCostOfAutomationY5;
	}

	public String getNoOfTestCyclesY1() {
		return noOfTestCyclesY1;
	}

	public void setNoOfTestCyclesY1(String noOfTestCyclesY1) {
		this.noOfTestCyclesY1 = noOfTestCyclesY1;
	}

	public String getNoOfTestCyclesY2() {
		return noOfTestCyclesY2;
	}

	public void setNoOfTestCyclesY2(String noOfTestCyclesY2) {
		this.noOfTestCyclesY2 = noOfTestCyclesY2;
	}

	public String getNoOfTestCyclesY3() {
		return noOfTestCyclesY3;
	}

	public void setNoOfTestCyclesY3(String noOfTestCyclesY3) {
		this.noOfTestCyclesY3 = noOfTestCyclesY3;
	}

	public String getNoOfTestCyclesY4() {
		return noOfTestCyclesY4;
	}

	public void setNoOfTestCyclesY4(String noOfTestCyclesY4) {
		this.noOfTestCyclesY4 = noOfTestCyclesY4;
	}

	public String getNoOfTestCyclesY5() {
		return noOfTestCyclesY5;
	}

	public void setNoOfTestCyclesY5(String noOfTestCyclesY5) {
		this.noOfTestCyclesY5 = noOfTestCyclesY5;
	}

	public String getTotalCostOfAutomatedTestingY1() {
		return totalCostOfAutomatedTestingY1;
	}

	public void setTotalCostOfAutomatedTestingY1(String totalCostOfAutomatedTestingY1) {
		this.totalCostOfAutomatedTestingY1 = totalCostOfAutomatedTestingY1;
	}

	public String getTotalCostOfAutomatedTestingY2() {
		return totalCostOfAutomatedTestingY2;
	}

	public void setTotalCostOfAutomatedTestingY2(String totalCostOfAutomatedTestingY2) {
		this.totalCostOfAutomatedTestingY2 = totalCostOfAutomatedTestingY2;
	}

	public String getTotalCostOfAutomatedTestingY3() {
		return totalCostOfAutomatedTestingY3;
	}

	public void setTotalCostOfAutomatedTestingY3(String totalCostOfAutomatedTestingY3) {
		this.totalCostOfAutomatedTestingY3 = totalCostOfAutomatedTestingY3;
	}

	public String getTotalCostOfAutomatedTestingY4() {
		return totalCostOfAutomatedTestingY4;
	}

	public void setTotalCostOfAutomatedTestingY4(String totalCostOfAutomatedTestingY4) {
		this.totalCostOfAutomatedTestingY4 = totalCostOfAutomatedTestingY4;
	}

	public String getTotalCostOfAutomatedTestingY5() {
		return totalCostOfAutomatedTestingY5;
	}

	public void setTotalCostOfAutomatedTestingY5(String totalCostOfAutomatedTestingY5) {
		this.totalCostOfAutomatedTestingY5 = totalCostOfAutomatedTestingY5;
	}

	public String getTotalCostForManualTestingY1() {
		return totalCostForManualTestingY1;
	}

	public void setTotalCostForManualTestingY1(String totalCostForManualTestingY1) {
		this.totalCostForManualTestingY1 = totalCostForManualTestingY1;
	}

	public String getTotalCostForManualTestingY2() {
		return totalCostForManualTestingY2;
	}

	public void setTotalCostForManualTestingY2(String totalCostForManualTestingY2) {
		this.totalCostForManualTestingY2 = totalCostForManualTestingY2;
	}

	public String getTotalCostForManualTestingY3() {
		return totalCostForManualTestingY3;
	}

	public void setTotalCostForManualTestingY3(String totalCostForManualTestingY3) {
		this.totalCostForManualTestingY3 = totalCostForManualTestingY3;
	}

	public String getTotalCostForManualTestingY4() {
		return totalCostForManualTestingY4;
	}

	public void setTotalCostForManualTestingY4(String totalCostForManualTestingY4) {
		this.totalCostForManualTestingY4 = totalCostForManualTestingY4;
	}

	public String getTotalCostForManualTestingY5() {
		return totalCostForManualTestingY5;
	}

	public void setTotalCostForManualTestingY5(String totalCostForManualTestingY5) {
		this.totalCostForManualTestingY5 = totalCostForManualTestingY5;
	}

	public String getTotalCostSavedByTestAutomationY1() {
		return totalCostSavedByTestAutomationY1;
	}

	public void setTotalCostSavedByTestAutomationY1(String totalCostSavedByTestAutomationY1) {
		this.totalCostSavedByTestAutomationY1 = totalCostSavedByTestAutomationY1;
	}

	public String getTotalCostSavedByTestAutomationY2() {
		return totalCostSavedByTestAutomationY2;
	}

	public void setTotalCostSavedByTestAutomationY2(String totalCostSavedByTestAutomationY2) {
		this.totalCostSavedByTestAutomationY2 = totalCostSavedByTestAutomationY2;
	}

	public String getTotalCostSavedByTestAutomationY3() {
		return totalCostSavedByTestAutomationY3;
	}

	public void setTotalCostSavedByTestAutomationY3(String totalCostSavedByTestAutomationY3) {
		this.totalCostSavedByTestAutomationY3 = totalCostSavedByTestAutomationY3;
	}

	public String getTotalCostSavedByTestAutomationY4() {
		return totalCostSavedByTestAutomationY4;
	}

	public void setTotalCostSavedByTestAutomationY4(String totalCostSavedByTestAutomationY4) {
		this.totalCostSavedByTestAutomationY4 = totalCostSavedByTestAutomationY4;
	}

	public String getTotalCostSavedByTestAutomationY5() {
		return totalCostSavedByTestAutomationY5;
	}

	public void setTotalCostSavedByTestAutomationY5(String totalCostSavedByTestAutomationY5) {
		this.totalCostSavedByTestAutomationY5 = totalCostSavedByTestAutomationY5;
	}

	public String getAutomationDevCostY1() {
		return automationDevCostY1;
	}

	public void setAutomationDevCostY1(String automationDevCostY1) {
		this.automationDevCostY1 = automationDevCostY1;
	}

	public String getAutomationDevCostY2() {
		return automationDevCostY2;
	}

	public void setAutomationDevCostY2(String automationDevCostY2) {
		this.automationDevCostY2 = automationDevCostY2;
	}

	public String getAutomationDevCostY3() {
		return automationDevCostY3;
	}

	public void setAutomationDevCostY3(String automationDevCostY3) {
		this.automationDevCostY3 = automationDevCostY3;
	}

	public String getAutomationDevCostY4() {
		return automationDevCostY4;
	}

	public void setAutomationDevCostY4(String automationDevCostY4) {
		this.automationDevCostY4 = automationDevCostY4;
	}

	public String getAutomationDevCostY5() {
		return automationDevCostY5;
	}

	public void setAutomationDevCostY5(String automationDevCostY5) {
		this.automationDevCostY5 = automationDevCostY5;
	}

	public String getAutomationScriptMaintainCostY1() {
		return automationScriptMaintainCostY1;
	}

	public void setAutomationScriptMaintainCostY1(String automationScriptMaintainCostY1) {
		this.automationScriptMaintainCostY1 = automationScriptMaintainCostY1;
	}

	public String getAutomationScriptMaintainCostY2() {
		return automationScriptMaintainCostY2;
	}

	public void setAutomationScriptMaintainCostY2(String automationScriptMaintainCostY2) {
		this.automationScriptMaintainCostY2 = automationScriptMaintainCostY2;
	}

	public String getAutomationScriptMaintainCostY3() {
		return automationScriptMaintainCostY3;
	}

	public void setAutomationScriptMaintainCostY3(String automationScriptMaintainCostY3) {
		this.automationScriptMaintainCostY3 = automationScriptMaintainCostY3;
	}

	public String getAutomationScriptMaintainCostY4() {
		return automationScriptMaintainCostY4;
	}

	public void setAutomationScriptMaintainCostY4(String automationScriptMaintainCostY4) {
		this.automationScriptMaintainCostY4 = automationScriptMaintainCostY4;
	}

	public String getAutomationScriptMaintainCostY5() {
		return automationScriptMaintainCostY5;
	}

	public void setAutomationScriptMaintainCostY5(String automationScriptMaintainCostY5) {
		this.automationScriptMaintainCostY5 = automationScriptMaintainCostY5;
	}

	public String getNetSavingsY1() {
		return netSavingsY1;
	}

	public void setNetSavingsY1(String netSavingsY1) {
		this.netSavingsY1 = netSavingsY1;
	}

	public String getNetSavingsY2() {
		return netSavingsY2;
	}

	public void setNetSavingsY2(String netSavingsY2) {
		this.netSavingsY2 = netSavingsY2;
	}

	public String getNetSavingsY3() {
		return netSavingsY3;
	}

	public void setNetSavingsY3(String netSavingsY3) {
		this.netSavingsY3 = netSavingsY3;
	}

	public String getNetSavingsY4() {
		return netSavingsY4;
	}

	public void setNetSavingsY4(String netSavingsY4) {
		this.netSavingsY4 = netSavingsY4;
	}

	public String getNetSavingsY5() {
		return netSavingsY5;
	}

	public void setNetSavingsY5(String netSavingsY5) {
		this.netSavingsY5 = netSavingsY5;
	}

	public String getRoiPercentageY1() {
		return roiPercentageY1;
	}

	public void setRoiPercentageY1(String roiPercentageY1) {
		this.roiPercentageY1 = roiPercentageY1;
	}

	public String getRoiPercentageY2() {
		return roiPercentageY2;
	}

	public void setRoiPercentageY2(String roiPercentageY2) {
		this.roiPercentageY2 = roiPercentageY2;
	}

	public String getRoiPercentageY3() {
		return roiPercentageY3;
	}

	public void setRoiPercentageY3(String roiPercentageY3) {
		this.roiPercentageY3 = roiPercentageY3;
	}

	public String getRoiPercentageY4() {
		return roiPercentageY4;
	}

	public void setRoiPercentageY4(String roiPercentageY4) {
		this.roiPercentageY4 = roiPercentageY4;
	}

	public String getRoiPercentageY5() {
		return roiPercentageY5;
	}

	public void setRoiPercentageY5(String roiPercentageY5) {
		this.roiPercentageY5 = roiPercentageY5;
	}

	@Override
	public String toString() {
		return "SummaryBean [noOfTestCyclesY1=" + noOfTestCyclesY1 + ", noOfTestCyclesY2=" + noOfTestCyclesY2
				+ ", noOfTestCyclesY3=" + noOfTestCyclesY3 + ", noOfTestCyclesY4=" + noOfTestCyclesY4
				+ ", noOfTestCyclesY5=" + noOfTestCyclesY5 + ", totalCostOfAutomatedTestingY1="
				+ totalCostOfAutomatedTestingY1 + ", totalCostOfAutomatedTestingY2=" + totalCostOfAutomatedTestingY2
				+ ", totalCostOfAutomatedTestingY3=" + totalCostOfAutomatedTestingY3
				+ ", totalCostOfAutomatedTestingY4=" + totalCostOfAutomatedTestingY4
				+ ", totalCostOfAutomatedTestingY5=" + totalCostOfAutomatedTestingY5 + ", totalCostForManualTestingY1="
				+ totalCostForManualTestingY1 + ", totalCostForManualTestingY2=" + totalCostForManualTestingY2
				+ ", totalCostForManualTestingY3=" + totalCostForManualTestingY3 + ", totalCostForManualTestingY4="
				+ totalCostForManualTestingY4 + ", totalCostForManualTestingY5=" + totalCostForManualTestingY5
				+ ", totalCostSavedByTestAutomationY1=" + totalCostSavedByTestAutomationY1
				+ ", totalCostSavedByTestAutomationY2=" + totalCostSavedByTestAutomationY2
				+ ", totalCostSavedByTestAutomationY3=" + totalCostSavedByTestAutomationY3
				+ ", totalCostSavedByTestAutomationY4=" + totalCostSavedByTestAutomationY4
				+ ", totalCostSavedByTestAutomationY5=" + totalCostSavedByTestAutomationY5 + ", automationDevCostY1="
				+ automationDevCostY1 + ", automationDevCostY2=" + automationDevCostY2 + ", automationDevCostY3="
				+ automationDevCostY3 + ", automationDevCostY4=" + automationDevCostY4 + ", automationDevCostY5="
				+ automationDevCostY5 + ", automationScriptMaintainCostY1=" + automationScriptMaintainCostY1
				+ ", automationScriptMaintainCostY2=" + automationScriptMaintainCostY2
				+ ", automationScriptMaintainCostY3=" + automationScriptMaintainCostY3
				+ ", automationScriptMaintainCostY4=" + automationScriptMaintainCostY4
				+ ", automationScriptMaintainCostY5=" + automationScriptMaintainCostY5 + ", testingToolLicenseCostY1="
				+ testingToolLicenseCostY1 + ", testingToolLicenseCostY2=" + testingToolLicenseCostY2
				+ ", testingToolLicenseCostY3=" + testingToolLicenseCostY3 + ", testingToolLicenseCostY4="
				+ testingToolLicenseCostY4 + ", testingToolLicenseCostY5=" + testingToolLicenseCostY5
				+ ", totalCostOfAutomationY1=" + totalCostOfAutomationY1 + ", totalCostOfAutomationY2="
				+ totalCostOfAutomationY2 + ", totalCostOfAutomationY3=" + totalCostOfAutomationY3
				+ ", totalCostOfAutomationY4=" + totalCostOfAutomationY4 + ", totalCostOfAutomationY5="
				+ totalCostOfAutomationY5 + ", netSavingsY1=" + netSavingsY1 + ", netSavingsY2=" + netSavingsY2
				+ ", netSavingsY3=" + netSavingsY3 + ", netSavingsY4=" + netSavingsY4 + ", netSavingsY5=" + netSavingsY5
				+ ", roiPercentageY1=" + roiPercentageY1 + ", roiPercentageY2=" + roiPercentageY2 + ", roiPercentageY3="
				+ roiPercentageY3 + ", roiPercentageY4=" + roiPercentageY4 + ", roiPercentageY5=" + roiPercentageY5
				+ "]";
	}
	
	

}
