package com.ust.roi.db.model;

import java.io.Serializable;

import com.ust.roi.abstracts.AbstractModel;

public class ProjectUserBean extends AbstractModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer userId;
	private Integer projectId;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

}
