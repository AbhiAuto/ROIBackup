package com.ust.roi.db.model;

public class CalAutoScriptExeBean {

	private String highAutomationTcScript;
	private String mediumAutomationTcScript;
	private String lowAutomationTcScript;
	private String hoursReqPerHourForHigh;
	private String hoursReqPerHourForMedium;
	private String hoursReqPerHourForLow;
	private String totalAutomationHoursPerCycle;
	private String totalAutomationHoursPerCycle1;
	private String costAutoTestingWithOffshoreRes;
	private String costAutoTestingWithOnshoreRes;
	private String costAutoTestingWithOffshoreRes1;
	private String AutoTestingExcetuionHours;
	private String onsiteHours;
	private String offshoreHours;
	private String CostAutoTestingRealOnshore;
	private String CostAutoTestingRealOffshore;
	private String MaintenanceEffortCost;

	public String getHighAutomationTcScript() {
		return highAutomationTcScript;
	}

	public void setHighAutomationTcScript(String highAutomationTcScript) {
		this.highAutomationTcScript = highAutomationTcScript;
	}

	public String getMediumAutomationTcScript() {
		return mediumAutomationTcScript;
	}

	public void setMediumAutomationTcScript(String mediumAutomationTcScript) {
		this.mediumAutomationTcScript = mediumAutomationTcScript;
	}

	public String getLowAutomationTcScript() {
		return lowAutomationTcScript;
	}

	public void setLowAutomationTcScript(String lowAutomationTcScript) {
		this.lowAutomationTcScript = lowAutomationTcScript;
	}

	public String getHoursReqPerHourForHigh() {
		return hoursReqPerHourForHigh;
	}

	public void setHoursReqPerHourForHigh(String hoursReqPerHourForHigh) {
		this.hoursReqPerHourForHigh = hoursReqPerHourForHigh;
	}

	public String getHoursReqPerHourForMedium() {
		return hoursReqPerHourForMedium;
	}

	public void setHoursReqPerHourForMedium(String hoursReqPerHourForMedium) {
		this.hoursReqPerHourForMedium = hoursReqPerHourForMedium;
	}

	public String getHoursReqPerHourForLow() {
		return hoursReqPerHourForLow;
	}

	public void setHoursReqPerHourForLow(String hoursReqPerHourForLow) {
		this.hoursReqPerHourForLow = hoursReqPerHourForLow;
	}

	public String getTotalAutomationHoursPerCycle() {
		return totalAutomationHoursPerCycle;
	}

	public void setTotalAutomationHoursPerCycle(String totalAutomationHoursPerCycle) {
		this.totalAutomationHoursPerCycle = totalAutomationHoursPerCycle;
	}

	public void setTotalAutomationHoursPerCycle1(String totalAutomationHoursPerCycle1) {
		this.totalAutomationHoursPerCycle1 = totalAutomationHoursPerCycle1;
	}

	public String getTotalAutomationHoursPerCycle1() {
		return totalAutomationHoursPerCycle1;
	}

	public String getCostAutoTestingWithOffshoreRes() {
		return costAutoTestingWithOffshoreRes;
	}

	public String getCostAutoTestingWithOnshoreRes() {
		return costAutoTestingWithOnshoreRes;
	}

	public void setCostAutoTestingWithOffshoreRes(String costAutoTestingWithOffshoreRes) {
		this.costAutoTestingWithOffshoreRes = costAutoTestingWithOffshoreRes;
	}

	public void setCostAutoTestingWithOnshoreRes(String CostAutoTestingWithOnshoreRes) {
		this.costAutoTestingWithOnshoreRes = CostAutoTestingWithOnshoreRes;
	}
	
	public void setAutoTestingExcetuionHours(String AutoTestingExcetuionHours) {
		this.AutoTestingExcetuionHours = AutoTestingExcetuionHours;
	}
	public String getAutoTestingExcetuionHours() {
		return AutoTestingExcetuionHours;
	}
	
	public String getOnsiteHours() {
		return onsiteHours;
	}

	public void setOnsiteHours(String onsiteHours) {
		this.onsiteHours = onsiteHours;
	}

	public String getOffshoreHours() {
		return offshoreHours;
	}

	public void setOffshoreHours(String offshoreHours) {
		this.offshoreHours = offshoreHours;
	}
	
	public void setCostAutoTestingRealOnshore(String CostAutoTestingRealOnshore) {
		this.CostAutoTestingRealOnshore = CostAutoTestingRealOnshore;
		
	}
	
	public String getCostAutoTestingRealOnshore() {
		return CostAutoTestingRealOnshore;
		
	}
	
	public void setCostAutoTestingRealOffshore(String CostAutoTestingRealOffshore) {
		this.CostAutoTestingRealOffshore = CostAutoTestingRealOffshore;
		
	}
	
	public String getCostAutoTestingRealOffshore() {
		return CostAutoTestingRealOffshore;
		
	}

	public void setCostAutoTestingWithOffshoreRes1(String costAutoTestingWithOffshoreRes1) {
		this.costAutoTestingWithOffshoreRes1 = costAutoTestingWithOffshoreRes1;
	}

	public String getCostAutoTestingWithOffshoreRes1() {
		return costAutoTestingWithOffshoreRes1;
	}
	
	public void setMaintenanceEffortCost(String MaintenanceEffortCost) {
		this.MaintenanceEffortCost = MaintenanceEffortCost;
	}

	public String getMaintenanceEffortCost() {
		return MaintenanceEffortCost;
	}

	@Override
	public String toString() {
		return "CalAutoScriptExeBean [highAutomationTcScript=" + highAutomationTcScript + ", mediumAutomationTcScript="
				+ mediumAutomationTcScript + ", lowAutomationTcScript=" + lowAutomationTcScript
				+ ", hoursReqPerHourForHigh=" + hoursReqPerHourForHigh + ", hoursReqPerHourForMedium="
				+ hoursReqPerHourForMedium + ", hoursReqPerHourForLow=" + hoursReqPerHourForLow
				+ ", totalAutomationHoursPerCycle=" + totalAutomationHoursPerCycle + ", costAutoTestingWithOffshoreRes="
				+ costAutoTestingWithOffshoreRes + "]";
	}


}