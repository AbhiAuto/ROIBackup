package com.ust.roi.db.model;

import java.io.Serializable;

import com.ust.roi.abstracts.AbstractModel;

public class TestingToolsUsedBean extends AbstractModel implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer yearId;
	private String year;
	private Integer projectId;
	private Integer toolId;
	private String toolName;
	private int licenseCount;
	private int testCyclesCount;

	public Integer getYearId() {
		return yearId;
	}

	public void setYearId(Integer yearId) {
		this.yearId = yearId;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getToolId() {
		return toolId;
	}

	public void setToolId(Integer toolId) {
		this.toolId = toolId;
	}

	public String getToolName() {
		return toolName;
	}

	public void setToolName(String toolName) {
		this.toolName = toolName;
	}

	public int getLicenseCount() {
		return licenseCount;
	}

	public void setLicenseCount(int licenseCount) {
		this.licenseCount = licenseCount;
	}

	public int getTestCyclesCount() {
		return testCyclesCount;
	}

	public void setTestCyclesCount(int testCyclesCount) {
		this.testCyclesCount = testCyclesCount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
