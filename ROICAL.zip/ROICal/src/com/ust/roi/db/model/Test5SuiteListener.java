/*package com.ust.roi.db.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElementDecl.GLOBAL;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.mysql.jdbc.PreparedStatement;

public class Test5SuiteListener implements ITestListener{
	//static String time1[];
	//static String time2[];
	//static long extime[];
	final String DATE_FORMAT_NOW = "HH:mm:ss";
	 static Date cal2;
	 static ArrayList<String> time1 = new ArrayList<String>();
	 static ArrayList<String> time2 = new ArrayList<String>();
	static ArrayList<String> extime = new ArrayList<String>();
	static ArrayList<String> category = new ArrayList<String>();
	static int i=0;
	static int j=0;
	static int k=0;
	  Calendar cal;
	
	@Override
	public void onStart(ITest sui) {

		

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		Test5SuiteListener.time1 = sdf.format(cal.getTime());
		Test5SuiteListener.cal2 = cal.getTime();
// TODO Auto-generated method stub
		System.out.println("TestNG suite default output directory = "+suite.getOutputDirectory());
		System.out.println(time1);
	    
		
	   
		  }
	

	@Override
	public void onFinish(ISuite suite) {
		
		Calendar cal1 = Calendar.getInstance();
		Date cal3 = cal1.getTime();
		SimpleDateFormat sdg = new SimpleDateFormat(DATE_FORMAT_NOW);
		Test5SuiteListener.time2 = sdg.format(cal1.getTime());
		
	Test5SuiteListener.extime =  cal3.getTime() -  cal2.getTime();
		
		System.out.println(extime);
		 
	
}


	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		
		Test5SuiteListener.time1.add (sdf.format(cal.getTime()));
		Test5SuiteListener.cal2 = cal.getTime();
// TODO Auto-generated method stub
	//	System.out.println("TestNG suite default output directory = "+suite.getOutputDirectory());
		
	    
		
	}


	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		Calendar cal1 = Calendar.getInstance();
		Date cal3 = cal1.getTime();
		SimpleDateFormat sdg = new SimpleDateFormat(DATE_FORMAT_NOW);
		Test5SuiteListener.time2.add(sdg.format(cal1.getTime()));
		long time3=cal3.getTime() -  cal2.getTime(); 
		if (time3 <= 2000) {
		Test5SuiteListener.category.add("low") ;
		
		Test5SuiteListener.i++;
		}
		else if (time3 <= 4000) {
			Test5SuiteListener.category.add("medium");
			Test5SuiteListener.j++;
		}
		else if (time3 > 4000) {
			
			Test5SuiteListener.category.add("high");
			Test5SuiteListener.k++;
		}
	Test5SuiteListener.extime.add(String.valueOf(time3));
		
		System.out.println(extime);
		
	}


	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}
}
	
	

*/