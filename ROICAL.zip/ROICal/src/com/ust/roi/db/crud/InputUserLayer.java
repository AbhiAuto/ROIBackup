package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getFloatValue;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractModel;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.InputUserBean;
import com.ust.roi.util.helper.RoiException;

public class InputUserLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_TOTAL_VALUE = "TOTAL_VALUE";
	private static final String COL_COMPLEX_LOW = "COMPLEX_LOW";
	private static final String COL_COMPLEX_MEDIUM = "COMPLEX_MEDIUM";
	private static final String COL_COMPLEX_HIGH = "COMPLEX_HIGH";
	private static final String COL_PROJECT_ID = "PROJECT_ID";
	private static final String TABLE_NAME = "USER_INPUT";
	private Class<?> c = InputUserBean.class;

	@Override
	public <T> void save(T t) {
		try {
			InputUserBean bean = (InputUserBean) t;
			int status = insertRecord(TABLE_NAME, COL_PROJECT_ID, String.valueOf(bean.getProjectId()), "INPUT_TYPE_ID",
					String.valueOf(bean.getTypeId()), COL_COMPLEX_HIGH, "" + bean.getComplexityHigh(),
					COL_COMPLEX_MEDIUM, "" + bean.getComplexityMedium(), COL_COMPLEX_LOW, "" + bean.getComplexityLow(),
					COL_TOTAL_VALUE, "" + bean.getTotalVal());
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			InputUserBean bean = (InputUserBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_PROJECT_ID,
					String.valueOf(bean.getProjectId()), "INPUT_TYPE_ID", String.valueOf(bean.getTypeId()),
					COL_COMPLEX_HIGH, "" + bean.getComplexityHigh(), COL_COMPLEX_MEDIUM,
					"" + bean.getComplexityMedium(), COL_COMPLEX_LOW, "" + bean.getComplexityLow(), COL_TOTAL_VALUE,
					"" + bean.getTotalVal());
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void delete(T t) {
		try {
			AbstractModel bean = (AbstractModel) t;
			int status = deleteRecordById(TABLE_NAME, bean);
			logInfo("Update status:-" + status);
		} catch (RoiException ex) {
			logSevere(ex);
		}
	}

	private List<InputUserBean> getDbValue(String sql, Class<?> c) {
		List<InputUserBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					InputUserBean bean = (InputUserBean) t;
					bean.setId(getIntValue(rs.getString("ID")));
					bean.setTypeId(getIntValue(rs.getString("TYPE_ID")));
					bean.setProjectId(getIntValue(rs.getString(COL_PROJECT_ID)));
					bean.setTypeName(rs.getString("TYPE_NAME"));
					bean.setComplexityHigh(getFloatValue(rs.getString(COL_COMPLEX_HIGH)));
					bean.setComplexityMedium(getFloatValue(rs.getString(COL_COMPLEX_MEDIUM)));
					bean.setComplexityLow(getFloatValue(rs.getString(COL_COMPLEX_LOW)));
					bean.setTotalVal(getFloatValue(rs.getString(COL_TOTAL_VALUE)));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT UI.ID AS ID,UIT.ID AS TYPE_ID,UI.PROJECT_ID AS PROJECT_ID, UIT.NAME AS TYPE_NAME, "
				+ "UI.COMPLEX_HIGH AS COMPLEX_HIGH, UI.COMPLEX_MEDIUM AS COMPLEX_MEDIUM, "
				+ "UI.COMPLEX_LOW AS COMPLEX_LOW, UI.TOTAL_VALUE AS TOTAL_VALUE " + "FROM USER_INPUT_TYPE UIT "
				+ "LEFT OUTER JOIN USER_INPUT UI ON UIT.ID = UI.INPUT_TYPE_ID WHERE UI.ID= " + id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getAll(String projectId) {
		String sql = "SELECT UI.ID AS ID,UIT.ID AS TYPE_ID,UI.PROJECT_ID AS PROJECT_ID, UIT.NAME AS TYPE_NAME, "
				+ "UI.COMPLEX_HIGH AS COMPLEX_HIGH, UI.COMPLEX_MEDIUM AS COMPLEX_MEDIUM, "
				+ "UI.COMPLEX_LOW AS COMPLEX_LOW, UI.TOTAL_VALUE AS TOTAL_VALUE " + "FROM USER_INPUT_TYPE UIT "
				+ "LEFT OUTER JOIN USER_INPUT UI ON UIT.ID = UI.INPUT_TYPE_ID AND UI.PROJECT_ID= " + projectId
				+ " ORDER BY UIT.SORT_ORDER";
		return (List<T>) getDbValue(sql, c);
	}

}
