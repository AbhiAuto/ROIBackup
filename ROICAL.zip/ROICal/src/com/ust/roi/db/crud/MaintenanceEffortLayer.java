
package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.MaintenanceEffortBean;

public class MaintenanceEffortLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_DATE = "DATE";
	private static final String COL_HOURS = "HOURS";
	private static final String COL_PROJECT_ID = "PROJECTID";
	private static final String TABLE_NAME = "MAINTENANCEEFFORT";
	private Class<?> c = MaintenanceEffortBean.class;

	@Override
	public <T> void save(T t) {
		try {
			MaintenanceEffortBean bean = (MaintenanceEffortBean) t;
			int status = insertRecord(TABLE_NAME, COL_PROJECT_ID, String.valueOf(bean.getProjectId()), COL_DATE,
					String.valueOf(bean.getdate()), COL_HOURS, bean.gethours());
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {

	}

	@Override
	public <T> T get(int id) {

		return null;
	}

	@Override
	public <T> List<T> getAll(String Condition) {

		return null;
	}
}
