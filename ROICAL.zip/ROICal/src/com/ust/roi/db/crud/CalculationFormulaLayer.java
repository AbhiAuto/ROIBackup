package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;

public class CalculationFormulaLayer extends AbstractDbLayer {

	private String projectId;

	public void setProject(String projectId) {
		this.projectId = projectId;
	}

	public String getScalarValue(String table, String column) {
		String sql = String.format("SELECT %s FROM %s WHERE 1=1 AND PROJECT_ID=%s", column, table, projectId);
		try {
			return scalarValue(sql);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
		return null;
	}

	public String getScalarValue(String table, String column, String condField, String condVal) {
		String sql = String.format("SELECT %s FROM %s WHERE 1=1 AND PROJECT_ID=%s AND %s ='%s'", column, table,
				projectId, condField, condVal);
		try {
			return scalarValue(sql);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
		return null;
	}

	public List<String> getScalarListValue(String table, String column) {
		List<String> lst = new ArrayList<>();
		String sql = String.format("SELECT %s FROM %s WHERE 1=1 AND PROJECT_ID=%s", column, table, projectId);
		try {
			lst = scalarListValue(sql);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

}
