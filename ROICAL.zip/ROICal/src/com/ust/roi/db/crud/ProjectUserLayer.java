package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractModel;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.ProjectUserBean;
import com.ust.roi.util.helper.RoiException;

public class ProjectUserLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_PROJECT_ID = "PROJECT_ID";
	private static final String COL_USER_ID = "USER_ID";
	private static final String TABLE_NAME = "PROJECT_USER";
	private Class<?> c = ProjectUserBean.class;

	@Override
	public <T> void save(T t) {
		try {
			ProjectUserBean bean = (ProjectUserBean) t;
			int status = insertRecord(TABLE_NAME, COL_USER_ID, String.valueOf(bean.getUserId()), COL_PROJECT_ID,
					String.valueOf(bean.getProjectId()));
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			ProjectUserBean bean = (ProjectUserBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_USER_ID, String.valueOf(bean.getUserId()),
					COL_PROJECT_ID, String.valueOf(bean.getProjectId()));
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void delete(T t) throws RoiException {
		try {
			AbstractModel bean = (AbstractModel) t;
			int status = deleteRecordById(TABLE_NAME, bean);
			logInfo("Update status:-" + status);
		} catch (Exception ex) {
			throw new RoiException(ex);
		}
	}

	private List<ProjectUserBean> getDbValue(String sql, Class<?> c) {
		List<ProjectUserBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					ProjectUserBean bean = (ProjectUserBean) t;
					bean.setId(getIntValue(rs.getString("ID")));
					bean.setUserId(getIntValue(rs.getString(COL_USER_ID)));
					bean.setProjectId(getIntValue(rs.getString(COL_PROJECT_ID)));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT ID , USER_ID, PROJECT_ID FROM PROJECT_USER WHERE ID = " + id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getAll(String projectId) {
		String sql = "SELECT ID , USER_ID, PROJECT_ID FROM PROJECT_USER WHERE PROJECT_ID = " + projectId;
		return (List<T>) getDbValue(sql, c);
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getAllByUserId(String userId) {
		String sql = "SELECT ID , USER_ID, PROJECT_ID FROM PROJECT_USER WHERE USER_ID = " + userId;
		return (List<T>) getDbValue(sql, c);
	}

}
