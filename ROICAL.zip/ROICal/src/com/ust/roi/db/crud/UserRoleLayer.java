package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.UserBean;
import com.ust.roi.db.model.UserRoleBean;

public class UserRoleLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_USERNAME = "USERNAME";
	private static final String COL_ROLENAME = "ROLENAME";
	private static final String TABLE_NAME = "USER_ROLES";
	private Class<?> c = UserRoleBean.class;

	@Override
	public <T> void save(T t) {
		try {
			UserRoleBean bean = (UserRoleBean) t;
			int status = insertRecord(TABLE_NAME, COL_ROLENAME, String.valueOf(bean.getRoleName()), COL_USERNAME,
					String.valueOf(bean.getUserName()));
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			UserRoleBean bean = (UserRoleBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_ROLENAME,
					String.valueOf(bean.getRoleName()), COL_USERNAME, String.valueOf(bean.getUserName()));
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	private List<UserRoleBean> getDbValue(String sql, Class<?> c) {
		List<UserRoleBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					UserRoleBean bean = (UserRoleBean) t;
					bean.setId(getIntValue(rs.getString("ID")));
					bean.setUserName(rs.getString(COL_USERNAME));
					bean.setRoleName(rs.getString(COL_ROLENAME));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT ID, USERNAME,ROLENAME FROM USER_ROLES WHERE 1=1 AND ID = " + id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	public <T> T getByUserName(String uname) {
		String sql = "SELECT ID, USERNAME,ROLENAME FROM USER_ROLES WHERE 1=1 AND USERNAME = '"
				+ uname.replaceAll("'", "''") + "'";
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getAll(String condition) {
		String sql = "SELECT ID, USERNAME,ROLENAME FROM USER_ROLES WHERE 1=1 AND " + condition;
		Class<?> c1 = UserBean.class;
		return (List<T>) getDbValue(sql, c1);
	}

}
