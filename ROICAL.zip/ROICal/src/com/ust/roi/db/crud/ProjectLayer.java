package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;
import static com.ust.roi.util.helper.CommonUtil.getStringValueFromInteger;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.ProjectBean;

public class ProjectLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_DESCRIPTION = "DESCRIPTION";
	private static final String COL_NAME = "NAME";
	private static final String COL_USER_ID = "USER_ID";
	private static final String TABLE_NAME = "PROJECT";
	private Class<?> c = ProjectBean.class;

	@Override
	public <T> void save(T t) {
		try {
			ProjectBean bean = (ProjectBean) t;
			int status = insertRecord(TABLE_NAME, COL_USER_ID, getStringValueFromInteger(bean.getManagerId()), COL_NAME,
					String.valueOf(bean.getName()), COL_DESCRIPTION, bean.getDescription());
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			ProjectBean bean = (ProjectBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_USER_ID,
					String.valueOf(bean.getManagerId()), COL_NAME, String.valueOf(bean.getName()), COL_DESCRIPTION,
					bean.getDescription());
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	private List<ProjectBean> getDbValue(String sql, Class<?> c) {
		List<ProjectBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					ProjectBean bean = (ProjectBean) t;
					bean.setId(rs.getInt("ID"));
					bean.setManagerId(getIntValue(rs.getString(COL_USER_ID)));
					bean.setName(rs.getString(COL_NAME));
					bean.setDescription(rs.getString(COL_DESCRIPTION));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT ID , NAME , USER_ID, DESCRIPTION FROM PROJECT WHERE ID = " + id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getAll(String projectId) {
		String sql = "SELECT ID , NAME , USER_ID, DESCRIPTION FROM PROJECT ";
		return (List<T>) getDbValue(sql, c);
	}

	@SuppressWarnings("unchecked")
	public <T> T getByName(String name) {
		String sql = "SELECT ID , NAME , USER_ID, DESCRIPTION FROM PROJECT WHERE NAME = '" + name + "'";
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}
}
