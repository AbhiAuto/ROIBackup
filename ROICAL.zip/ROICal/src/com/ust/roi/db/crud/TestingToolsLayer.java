package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getFloatValue;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.TestingToolsBean;

public class TestingToolsLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_LICENSE_COST = "LICENSE_COST";
	private static final String COL_TOOL_ID = "TOOL_ID";
	private static final String COL_PROJECT_ID = "PROJECT_ID";
	private static final String TABLE_NAME = "TOOLS_LICENSE_COST";
	private Class<?> c = TestingToolsBean.class;

	@Override
	public <T> void save(T t) {
		try {
			TestingToolsBean bean = (TestingToolsBean) t;
			int status = insertRecord(TABLE_NAME, COL_PROJECT_ID, String.valueOf(bean.getProjectId()), COL_TOOL_ID,
					String.valueOf(bean.getToolId()), COL_LICENSE_COST, "" + getFloatValue("" + bean.getLicenseCost()));
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			TestingToolsBean bean = (TestingToolsBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_PROJECT_ID,
					String.valueOf(bean.getProjectId()), COL_TOOL_ID, String.valueOf(bean.getToolId()),
					COL_LICENSE_COST, "" + getFloatValue("" + bean.getLicenseCost()));
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	private List<TestingToolsBean> getDbValue(String sql, Class<?> c) {
		List<TestingToolsBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					TestingToolsBean bean = (TestingToolsBean) t;
					bean.setId(getIntValue(rs.getString("ID")));
					bean.setProjectId(getIntValue(rs.getString(COL_PROJECT_ID)));
					bean.setToolId(getIntValue(rs.getString(COL_TOOL_ID)));
					bean.setToolName(rs.getString("TOOL_NAME"));
					bean.setActualCost(getFloatValue(rs.getString("ACTUAL_COST")));
					bean.setLicenseCost(getFloatValue(rs.getString(COL_LICENSE_COST)));
					
	             
					
					bean.setLicensetype(rs.getString("LICENSE_TYPE"));
					
					
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT TLC.ID,TLC.PROJECT_ID AS PROJECT_ID, TT.ID AS TOOL_ID , TT.NAME AS TOOL_NAME, TT.LICENSE_COST AS ACTUAL_COST, "
				+ " TT.LicenseType AS LICENSE_TYPE,TLC.LICENSE_COST  FROM  TESTING_TOOLS TT LEFT OUTER JOIN TOOLS_LICENSE_COST TLC ON TT.ID = TLC.TOOL_ID AND TLC.ID = "
				+ id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	/*
	 * public <T> List<T> getAll(String projectId) { String sql =
	 * "SELECT TLC.ID,TLC.PROJECT_ID AS PROJECT_ID, TT.ID AS TOOL_ID , TT.NAME AS TOOL_NAME, TT.LICENSE_COST AS ACTUAL_COST, "
	 * +
	 * " TLC.LICENSE_COST  FROM  TESTING_TOOLS TT LEFT OUTER JOIN TOOLS_LICENSE_COST TLC ON TT.ID = TLC.TOOL_ID AND PROJECT_ID = "
	 * + projectId; return (List<T>) getDbValue(sql, c); }
	 */

	
	public <T> List<T> getAll(String projectId) {
		String sql = "SELECT TLC.ID,TLC.PROJECT_ID AS PROJECT_ID, TT.ID AS TOOL_ID , TT.NAME AS TOOL_NAME, TT.LICENSE_COST AS ACTUAL_COST, "
				+ " TT.LicenseType AS LICENSE_TYPE, TLC.LICENSE_COST  FROM  TESTING_TOOLS TT LEFT OUTER JOIN TOOLS_LICENSE_COST TLC ON TT.ID = TLC.TOOL_ID AND PROJECT_ID = "
				+ projectId +" WHERE TT.NAME <> 'null'";
		return (List<T>) getDbValue(sql, c);
	}
	
	

}
