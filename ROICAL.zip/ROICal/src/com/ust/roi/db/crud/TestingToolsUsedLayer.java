package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.TestingToolsUsedBean;

public class TestingToolsUsedLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_TEST_CYCLE_COUNT = "TEST_CYCLE_COUNT";
	private static final String COL_LICENSE_COUNT = "LICENSE_COUNT";
	private static final String COL_TOOL_ID = "TOOL_ID";
	private static final String COL_YEAR_ID = "YEAR_ID";
	private static final String COL_PROJECT_ID = "PROJECT_ID";
	private static final String TABLE_NAME = "USER_INPUT_TOOL";
	private Class<?> c = TestingToolsUsedBean.class;
	@Override
	public <T> void save(T t) {
		try {
			TestingToolsUsedBean bean = (TestingToolsUsedBean) t;
			int status = insertRecord(TABLE_NAME, COL_PROJECT_ID, String.valueOf(bean.getProjectId()), COL_YEAR_ID,
					String.valueOf(bean.getYearId()), COL_TOOL_ID, String.valueOf(bean.getToolId()), COL_LICENSE_COUNT,
					"" + getIntValue(Integer.toString(bean.getLicenseCount())), COL_TEST_CYCLE_COUNT,
					"" + getIntValue(Integer.toString(bean.getTestCyclesCount())));
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			TestingToolsUsedBean bean = (TestingToolsUsedBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_PROJECT_ID,
					String.valueOf(bean.getProjectId()), COL_YEAR_ID, String.valueOf(bean.getYearId()), COL_TOOL_ID,
					String.valueOf(bean.getToolId()), COL_LICENSE_COUNT,
					"" + getIntValue(Integer.toString(bean.getLicenseCount())), COL_TEST_CYCLE_COUNT,
					"" + getIntValue(Integer.toString(bean.getTestCyclesCount())));
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	private List<TestingToolsUsedBean> getDbValue(String sql, Class<?> c) {
		List<TestingToolsUsedBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					TestingToolsUsedBean bean = (TestingToolsUsedBean) t;
					bean.setId(getIntValue(rs.getString("ID")));
					bean.setProjectId(getIntValue(rs.getString(COL_PROJECT_ID)));
					bean.setYearId(getIntValue(rs.getString(COL_YEAR_ID)));
					bean.setToolId(getIntValue(rs.getString(COL_TOOL_ID)));
					bean.setToolName(rs.getString("TOOL_NAME"));
					bean.setYear(rs.getString("YEAR_NAME"));
					bean.setLicenseCount(getIntValue(rs.getString(COL_LICENSE_COUNT)));
					bean.setTestCyclesCount(getIntValue(rs.getString(COL_TEST_CYCLE_COUNT)));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT TU.ID AS ID, TU.PROJECT_ID,"
				+ " TY.ID AS YEAR_ID, TU.TOOL_ID AS TOOL_ID, TU.TOOL_NAME, TY.YEAR_VAL AS YEAR_NAME, TU.LICENSE_COUNT, TU.TEST_CYCLE_COUNT "
				+ "FROM TEST_YEAR TY "
				+ "LEFT OUTER JOIN ( SELECT UIT.ID AS ID,UIT.YEAR_ID, UIT.PROJECT_ID , UIT.TOOL_ID, TT.NAME AS TOOL_NAME, UIT.LICENSE_COUNT, UIT.TEST_CYCLE_COUNT "
				+ " FROM USER_INPUT_TOOL UIT " + "INNER JOIN TESTING_TOOLS TT ON TT.ID = UIT.TOOL_ID ) "
				+ " TU ON TU.YEAR_ID = TY.ID WHERE 1=1 AND TU.ID = " + id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getAll(String projectId) {
		String sql = "SELECT TU.ID AS ID, TU.PROJECT_ID,"
				+ " TY.ID AS YEAR_ID, TU.TOOL_ID AS TOOL_ID, TU.TOOL_NAME, TY.YEAR_VAL AS YEAR_NAME, TU.LICENSE_COUNT, TU.TEST_CYCLE_COUNT "
				+ "FROM TEST_YEAR TY "
				+ "LEFT OUTER JOIN ( SELECT UIT.ID AS ID,UIT.YEAR_ID, UIT.PROJECT_ID , UIT.TOOL_ID, TT.NAME AS TOOL_NAME, UIT.LICENSE_COUNT, UIT.TEST_CYCLE_COUNT "
				+ " FROM USER_INPUT_TOOL UIT " + "INNER JOIN TESTING_TOOLS TT ON TT.ID = UIT.TOOL_ID ) "
				+ " TU ON TU.YEAR_ID = TY.ID AND TU.PROJECT_ID=" + projectId;
		return (List<T>) getDbValue(sql, c);
	}
}
