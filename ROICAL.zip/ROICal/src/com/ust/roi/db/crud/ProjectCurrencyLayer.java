package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.getStringValueFromInteger;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.ProjectCurrencyBean;
import com.ust.roi.view.model.NameValuePair;

public class ProjectCurrencyLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_CURRENCY_ID = "CURRENCY_ID";
	private static final String COL_PROJECT_ID = "PROJECT_ID";
	private static final String TABLE_NAME = "PROJECT_CURRENCY";
	private Class<?> c = ProjectCurrencyBean.class;
	@Override
	public <T> void save(T t) {
		try {
			ProjectCurrencyBean bean = (ProjectCurrencyBean) t;
			int status = insertRecord(TABLE_NAME, COL_PROJECT_ID, getStringValueFromInteger(bean.getProjectId()),
					COL_CURRENCY_ID, getStringValueFromInteger(bean.getCurrencyId()));
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			ProjectCurrencyBean bean = (ProjectCurrencyBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_PROJECT_ID,
					getStringValueFromInteger(bean.getProjectId()), COL_CURRENCY_ID,
					getStringValueFromInteger(bean.getCurrencyId()));
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	private List<ProjectCurrencyBean> getDbValue(String sql, Class<?> c) {
		List<ProjectCurrencyBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					ProjectCurrencyBean bean = (ProjectCurrencyBean) t;
					bean.setId(rs.getInt("ID"));
					bean.setProjectId(getIntValue(rs.getString(COL_PROJECT_ID)));
					bean.setCurrencyId(getIntValue(rs.getString(COL_CURRENCY_ID)));
					bean.setSymbol(rs.getString("SYMBL"));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT PC.ID ,PC.PROJECT_ID , PC.CURRENCY_ID , C.SYMBL FROM PROJECT_CURRENCY PC INNER JOIN CURRENCY C ON PC.CURRENCY_ID=C.ID WHERE PD.ID = " + id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getAll(String projectId) {
		String sql = "SELECT PC.ID ,PC.PROJECT_ID , PC.CURRENCY_ID , C.SYMBL FROM PROJECT_CURRENCY PC INNER JOIN CURRENCY C ON PC.CURRENCY_ID=C.ID WHERE PROJECT_ID= "
				+ projectId;
		return (List<T>) getDbValue(sql, c);
	}

	private List<NameValuePair> getDbValue1(String sql, Class<?> c) {
		List<NameValuePair> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					NameValuePair bean = (NameValuePair) t;
					bean.setValue(rs.getString("ID"));
					bean.setName(rs.getString("RCURRENCY"));

				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getAllCurrency() {
		String sql = "SELECT ID, CONCAT( SYMBL,' (',CODE,')') AS RCURRENCY FROM CURRENCY ORDER BY SORT_ORDER";
		Class<?> c1 = NameValuePair.class;
		return (List<T>) getDbValue1(sql, c1);
	}

}
