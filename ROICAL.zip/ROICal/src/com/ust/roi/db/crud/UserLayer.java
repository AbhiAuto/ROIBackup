package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.UserBean;

public class UserLayer extends AbstractDbLayer implements DbLayer {

	private static final String COL_DESIGNATION = "DESIGNATION";
	private static final String COL_EMAIL = "EMAIL";
	private static final String COL_LNAME = "LNAME";
	private static final String COL_FNAME = "FNAME";
	private static final String COL_PASSWORD = "PASSWORD";
	private static final String COL_USERNAME = "USERNAME";
	private static final String COL_PROJECT_ID = "PROJECT_ID";
	private static final String TABLE_NAME = "USERS";
	private Class<?> c = UserBean.class;

	@Override
	public <T> void save(T t) {
		try {
			UserBean bean = (UserBean) t;
			int status = insertRecord(TABLE_NAME, COL_PROJECT_ID, String.valueOf(bean.getProjectId()), COL_USERNAME,
					String.valueOf(bean.getUsername()), COL_PASSWORD, bean.getPassword(), COL_FNAME,
					bean.getFirstName(), COL_LNAME, bean.getLastName(), COL_EMAIL, bean.getEmail(), COL_DESIGNATION,
					bean.getDesignation());
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			UserBean bean = (UserBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_PROJECT_ID,
					String.valueOf(bean.getProjectId()), COL_USERNAME, String.valueOf(bean.getUsername()), COL_PASSWORD,
					bean.getPassword(), COL_FNAME, bean.getFirstName(), COL_LNAME, bean.getLastName(), COL_EMAIL,
					bean.getEmail(), COL_DESIGNATION, bean.getDesignation());
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	private List<UserBean> getDbValue(String sql, Class<?> c) {
		List<UserBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					UserBean bean = (UserBean) t;
					bean.setId(getIntValue(rs.getString("ID")));
					bean.setProjectId(getIntValue(rs.getString(COL_PROJECT_ID)));
					bean.setUsername(rs.getString(COL_USERNAME));
					bean.setPassword(rs.getString(COL_PASSWORD));
					bean.setFirstName(rs.getString(COL_FNAME));
					bean.setLastName(rs.getString(COL_LNAME));
					bean.setEmail(rs.getString(COL_EMAIL));
					bean.setDesignation(rs.getString(COL_DESIGNATION));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT ID, USERNAME,PASSWORD,FNAME, LNAME, EMAIL, PROJECT_ID, DESIGNATION FROM USERS WHERE 1=1 AND ID = "
				+ id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	public <T> T getByUserName(String uname) {
		String sql = "SELECT ID, USERNAME,PASSWORD,FNAME, LNAME, EMAIL, PROJECT_ID, DESIGNATION FROM USERS WHERE 1=1 AND USERNAME = '"
				+ uname.replaceAll("'", "''") + "'";
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> getAll(String condition) {
		String sql = "SELECT ID, USERNAME,PASSWORD,FNAME, LNAME, EMAIL, PROJECT_ID, DESIGNATION FROM USERS WHERE 1=1 AND "
				+ condition;
		return (List<T>) getDbValue(sql, c);
	}

}
