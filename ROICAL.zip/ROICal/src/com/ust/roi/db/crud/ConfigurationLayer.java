package com.ust.roi.db.crud;

import static com.ust.roi.util.helper.CommonUtil.getFirstRecordFromList;
import static com.ust.roi.util.helper.CommonUtil.getIntValue;
import static com.ust.roi.util.helper.CommonUtil.logInfo;
import static com.ust.roi.util.helper.CommonUtil.logSevere;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.abstracts.AbstractDbLayer;
import com.ust.roi.abstracts.AbstractModel;
import com.ust.roi.abstracts.AbstractSqlExecute;
import com.ust.roi.abstracts.DbLayer;
import com.ust.roi.db.model.ConfigureElementBean;
import com.ust.roi.util.helper.RoiException;

public class ConfigurationLayer extends AbstractDbLayer implements DbLayer {
	private static final String COL_VALUE = "VALUE";
	private static final String COL_COMMENTS = "COMMENTS";
	private static final String COL_PROJECT_ID = "PROJECT_ID";
	private static final String TABLE_NAME = "PROJECT_CONFIGURE_ELEMENT";
	private Class<?> c = ConfigureElementBean.class;
	@Override
	public <T> void save(T t) {
		try {
			ConfigureElementBean bean = (ConfigureElementBean) t;
			int status = insertRecord(TABLE_NAME, COL_PROJECT_ID, String.valueOf(bean.getProjectId()),
					"CONFIG_ELEMENT_ID", String.valueOf(bean.getConfigId()), COL_VALUE, bean.getValue(), COL_COMMENTS,
					bean.getComments());
			logInfo("Save status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void update(T t) {
		try {
			ConfigureElementBean bean = (ConfigureElementBean) t;
			int status = updateRecord(TABLE_NAME, "ID=" + bean.getId(), COL_PROJECT_ID,
					String.valueOf(bean.getProjectId()), "CONFIG_ELEMENT_ID", String.valueOf(bean.getConfigId()),
					COL_VALUE, bean.getValue(), COL_COMMENTS, bean.getComments());
			logInfo("Update status:-" + status);
		} catch (NamingException | SQLException ex) {
			logSevere(ex);
		}
	}

	@Override
	public <T> void delete(T t) {
		try {
			AbstractModel bean = (AbstractModel) t;
			int status = deleteRecordById(TABLE_NAME, bean);
			logInfo("Update status:-" + status);
		} catch (RoiException ex) {
			logSevere(ex);
		}
	}

	private List<ConfigureElementBean> getDbValue(String sql, Class<?> c) {
		List<ConfigureElementBean> lst = new ArrayList<>();
		try {
			lst = selectRecord(sql, new AbstractSqlExecute() {
				@Override
				public <U> void select(java.sql.ResultSet rs, U t) throws SQLException {
					ConfigureElementBean bean = (ConfigureElementBean) t;
					bean.setId(getIntValue(rs.getString("ID")));
					bean.setConfigId(getIntValue(rs.getString("EMLEMENT_ID")));
					bean.setProjectId(getIntValue(rs.getString(COL_PROJECT_ID)));
					bean.setConfigType(rs.getString("CONFIG_TYPE"));
					bean.setConfigName(rs.getString("CONFIG_NAME"));
					bean.setValue(rs.getString(COL_VALUE));
					bean.setComments(rs.getString(COL_COMMENTS));
					bean.setUiTitle(rs.getString("UITITLE"));
					bean.setOther(rs.getString("OTHER"));
				};
			}, c);
		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			logSevere(ex);
		}
		return lst;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T get(int id) {
		String sql = "SELECT pce.ID AS ID, ce.ID AS EMLEMENT_ID, pce.PROJECT_ID AS PROJECT_ID, ct.NAME AS CONFIG_TYPE, "
				+ "ce.NAME AS CONFIG_NAME, pce.VALUE AS VALUE , pce.COMMENTS AS COMMENTS, ct.UITITLE, ct.OTHER "
				+ "FROM CONFIGURE_ELEMENT ce " + "INNER JOIN CONFIGURE_TYPE ct ON ce.CONFIG_TYPE_ID = ct.ID "
				+ "LEFT OUTER JOIN PROJECT_CONFIGURE_ELEMENT pce " + "ON pce.CONFIG_ELEMENT_ID=ce.ID WHERE pce.ID= "
				+ id;
		return (T) getFirstRecordFromList(getDbValue(sql, c));
	}

	@SuppressWarnings("unchecked")
	@Override
	
	/* With Test Cycle Count 
	 * String sql = SELECT pce.ID AS ID, ce.ID AS EMLEMENT_ID, pce.PROJECT_ID AS PROJECT_ID,
	 * ct.NAME AS CONFIG_TYPE, ce.NAME AS CONFIG_NAME, pce.VALUE AS VALUE ,
	 * pce.COMMENTS AS COMMENTS, ct.UITITLE, ct.OTHER FROM CONFIGURE_ELEMENT ce
	 * INNER JOIN CONFIGURE_TYPE ct ON ce.CONFIG_TYPE_ID = ct.ID LEFT OUTER JOIN
	 * PROJECT_CONFIGURE_ELEMENT pce ON pce.CONFIG_ELEMENT_ID=ce.ID AND
	 * pce.PROJECT_ID= 14 ORDER BY ct.SORT_ORDER, ce.SORT_ORDER
	 */
	 
	public <T> List<T> getAll(String projectId) {
		String sql = "SELECT pce.ID AS ID, ce.ID AS EMLEMENT_ID, pce.PROJECT_ID AS PROJECT_ID, ct.NAME AS CONFIG_TYPE, "
				+ "ce.NAME AS CONFIG_NAME, pce.VALUE AS VALUE , pce.COMMENTS AS COMMENTS, ct.UITITLE, ct.OTHER  "
				+ "FROM CONFIGURE_ELEMENT ce " + "INNER JOIN CONFIGURE_TYPE ct ON ce.CONFIG_TYPE_ID = ct.ID AND ct.NAME <> \"Test Cycle Count\""
				+ "LEFT OUTER JOIN PROJECT_CONFIGURE_ELEMENT pce "
				+ "ON pce.CONFIG_ELEMENT_ID=ce.ID AND pce.PROJECT_ID= " + projectId
				+ " ORDER BY ct.SORT_ORDER, ce.SORT_ORDER";
		return (List<T>) getDbValue(sql, c);
	}

}
