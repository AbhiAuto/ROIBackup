package com.ust.roi.abstracts;

import static com.ust.roi.util.helper.CommonUtil.logInfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.ust.roi.util.helper.RoiException;

public class AbstractDbLayer {

	public AbstractDbLayer() {
		super();
	}

	private static String getSafeSqlParam(String val) {
		String v = val;
		v = v.replaceAll("'", "''");
		return v;
	}

	protected Connection getDbConnection() throws NamingException, SQLException {
		Context initContext = new InitialContext();
		Context envContext = (Context) initContext.lookup("java:comp/env");
		DataSource ds = (DataSource) envContext.lookup("jdbc/roidb");
		return ds.getConnection();
	}

	protected <T> List<T> selectRecord(String sql, AbstractSqlExecute wrapper, Class<?> t)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		List<T> lst = new ArrayList<>();
		try (Connection conn = getDbConnection()) {
			try (Statement st = conn.createStatement()) {
				try (ResultSet rs = st.executeQuery(sql)) {
					while (null != rs && rs.next()) {
						@SuppressWarnings("unchecked")
						T tmp = (T) t.newInstance();
						wrapper.select(rs, tmp);
						lst.add(tmp);
					}
				}
			}
		}
		return lst;
	}

	protected int executeRecord(String sql, AbstractSqlExecute wrapper) throws NamingException, SQLException {
		try (Connection conn = getDbConnection()) {
			try (PreparedStatement ps = conn.prepareStatement(sql)) {
				wrapper.execute(ps);
				return ps.executeUpdate();
			}
		}
	}

	protected int executeRecord(Connection conn, String sql, AbstractSqlExecute wrapper)
			throws NamingException, SQLException {
		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			wrapper.execute(ps);
			return ps.executeUpdate();
		}

	}

	protected int insertRecord(final String tableName, final String... colval) throws NamingException, SQLException {
		String sql = "INSERT INTO " + getSafeSqlParam(tableName) + " ( ";
		final int mid = colval.length;
		for (int i = 0; i < mid; i = i + 2) {
			sql += "" + colval[i] + ",";
		}
		sql = sql.substring(0, sql.length() - 1) + ") ";
		sql += " VALUES (";
		for (int i = 0; i < mid; i = i + 2) {
			String val = colval[i + 1];
			if (null == val) {
				val = null;
			} else {
				val = "'" + getSafeSqlParam(val) + "'";
			}
			sql += "" + val + ",";
		}
		sql = sql.substring(0, sql.length() - 1) + ") ";
		return executeRecord(sql, new AbstractSqlExecute() {

		});
	}

	protected int updateRecord(final String tableName, final String condition, final String... colval)
			throws NamingException, SQLException {
		String sql = "UPDATE " + getSafeSqlParam(tableName) + " SET ";
		final int mid = colval.length;
		for (int i = 0; i < mid; i = i + 2) {
			String val = colval[i + 1];
			if (null == val) {
				val = null;
			} else {
				val = "'" + getSafeSqlParam(val) + "'";
			}
			sql += " " + colval[i] + " = " + val + ",";
		}
		sql = sql.substring(0, sql.length() - 1) + " ";
		sql += "WHERE 1=1 AND " + condition;
		return executeRecord(sql, new AbstractSqlExecute() {

		});
	}

	public List<String> scalarListValue(String sql) throws NamingException, SQLException {
		List<String> lst = new ArrayList<>();
		try (Connection conn = getDbConnection()) {
			try (Statement st = conn.createStatement()) {
				try (ResultSet rs = st.executeQuery(sql)) {
					while (null != rs && rs.next()) {
						String val = rs.getString(1);
						lst.add(val);
					}
				}
			}
		}
		return lst;
	}

	public String scalarValue(String sql) throws SQLException, NamingException {
		String val = null;
		try (Connection conn = getDbConnection()) {
			try (Statement st = conn.createStatement()) {
				try (ResultSet rs = st.executeQuery(sql)) {
					while (null != rs && rs.next()) {
						val = rs.getString(1);
					}
				}
			}
		}
		return val;
	}

	protected int deleteRecord(final String tableName, final String fieldName, final String id) throws RoiException {
		try {
			String sql = "DELETE FROM " + getSafeSqlParam(tableName) + " WHERE " + getSafeSqlParam(fieldName) + " = '"
					+ getSafeSqlParam(id) + "' ";
			return executeRecord(sql, new AbstractSqlExecute() {

			});
		} catch (Exception ex) {
			throw new RoiException(ex);
		}
	}

	protected int deleteRecordById(String tableName, AbstractModel bean) throws RoiException {
		return deleteRecord(tableName, "id", "" + bean.getId());
	}

	public <T> void delete(T t) throws RoiException {
		try {
			AbstractModel bean = (AbstractModel) t;
			int status = deleteRecordById("PROJECT_CONFIGURE_ELEMENT", bean);
			logInfo("Update status:-" + status);
		} catch (RoiException ex) {
			throw new RoiException(ex);
		}
	}

	protected int getAllRecord(final String tableName, final String condition, final String... colval)
			throws NamingException, SQLException {
		String sql = "SELECT ";
		final int mid = colval.length / 2;
		for (int i = 0; i < mid; i = i + 2) {
			sql += "" + colval[i] + ",";
		}
		sql = sql.substring(0, sql.length() - 1) + " ";
		sql += " FROM " + getSafeSqlParam(tableName);
		sql += "WHERE 1=1 AND " + condition;
		return executeRecord(sql, new AbstractSqlExecute() {
			@Override
			public void execute(PreparedStatement ps) throws SQLException {
				for (int i = 1; i < mid; i = i + 2) {
					ps.setString(i, colval[i]);
				}
			}
		});
	}

	protected int deleteRecord(final Connection conn, final String tableName, final String fieldName, final String id)
			throws NamingException, SQLException {
		String sql = "DELETE FROM " + getSafeSqlParam(tableName) + " WHERE " + getSafeSqlParam(fieldName) + " = ? ";
		return executeRecord(conn, sql, new AbstractSqlExecute() {
			@Override
			public void execute(PreparedStatement ps) throws SQLException {
				ps.setString(1, id);
			}
		});
	}

	protected int insertRecord(final Connection conn, final String tableName, final String... colval)
			throws NamingException, SQLException {
		String sql = "INSERT INTO " + getSafeSqlParam(tableName) + " ( ";
		final int mid = colval.length;
		for (int i = 0; i < mid; i = i + 2) {
			sql += "" + colval[i] + ",";
		}
		sql = sql.substring(0, sql.length() - 1) + ") ";
		sql += " VALUES (";
		for (int i = 0; i < mid; i = i + 2) {
			sql += "?,";
		}
		sql = sql.substring(0, sql.length() - 1) + ") ";
		return executeRecord(conn, sql, new AbstractSqlExecute() {
			@Override
			public void execute(PreparedStatement ps) throws SQLException {
				int col = 0;
				for (int i = 0; i < mid; i = i + 2) {
					col++;
					String val = colval[i + 1];
					ps.setString(col, val);
				}
			}
		});
	}

	protected int updateRecord(final Connection conn, final String tableName, final String condition,
			final String... colval) throws NamingException, SQLException {
		String sql = "UPDATE " + getSafeSqlParam(tableName) + " SET ";
		final int mid = colval.length;
		for (int i = 0; i < mid; i = i + 2) {
			sql += " " + colval[i] + " = ? ,";
		}
		sql = sql.substring(0, sql.length() - 1) + " ";
		sql += "WHERE 1=1 AND " + condition;
		return executeRecord(conn, sql, new AbstractSqlExecute() {
			@Override
			public void execute(final PreparedStatement ps) throws SQLException {
				int col = 0;
				for (int i = 0; i < mid; i = i + 2) {
					col++;
					ps.setString(col, colval[i + 1]);
				}
			}
		});
	}

	public static void main(String[] args) {
		try {
			AbstractDbLayer lay = new AbstractDbLayer();
			Class.forName("com.mysql.jdbc.Driver");
			try (Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/roicaldb?zeroDateTimeBehavior=convertToNull", "root", "qwerty12345")) {
				int i = lay.deleteRecord(con, "PROJECT_CURRENCY", "ID", "3");
				System.out.println("status=" + i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}