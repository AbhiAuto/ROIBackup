
package com.ust.roi.abstracts;

import java.util.List;

import com.ust.roi.util.helper.RoiException;


public interface DbLayer {

    <T> void save(T t);

    <T> void update(T t);

    <T> void delete(T t) throws RoiException;

    <T> T get(int id);

    <T> List<T> getAll(String Condition);
}
