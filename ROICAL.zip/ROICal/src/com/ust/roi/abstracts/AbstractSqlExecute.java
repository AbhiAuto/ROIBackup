package com.ust.roi.abstracts;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class AbstractSqlExecute {
	public void execute(PreparedStatement ps) throws SQLException {
	}

	public <T> void select(ResultSet rs, T t) throws SQLException {
	}
}
