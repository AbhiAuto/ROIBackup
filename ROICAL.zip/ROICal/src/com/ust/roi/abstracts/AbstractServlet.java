package com.ust.roi.abstracts;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ust.roi.sec.PageUrl;
import com.ust.roi.sec.SessionKeys;

public abstract class AbstractServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(AbstractServlet.class);
	protected static final String MSG_SAVE_SUCCESS = "Record(s) saved successfully.";
	protected static final String MSG_SAVE_FAIL = "Record(s) cannot be saved.";
	private HttpServletRequest req;
	private HttpServletResponse resp;

	protected void logWarn(String msg) {
		log.warn(msg);
	}

	protected void logWarn(String msg, Exception e) {
		log.warn(msg, e);
	}

	protected void logInfo(String msg) {
		log.info(msg);
	}

	protected void logInfo(String msg, Exception e) {
		log.info(msg, e);
	}

	protected void logError(String msg) {
		log.error(msg);
	}

	protected void logError(String msg, Exception e) {
		log.error(msg, e);
	}

	public void showMessage(HttpServletRequest request, String msg) {
		request.getSession().setAttribute("err", msg);
	}

	public void clearMessage(HttpServletRequest request) {
		request.getSession().setAttribute("err", "");
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		req = request;
		resp = response;
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void forwardRequest(HttpServletRequest request, HttpServletResponse response, PageUrl purl)
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher(purl.getURL());
		rd.forward(request, response);
	}

	protected void forwardRequest(PageUrl purl) throws ServletException, IOException {
		RequestDispatcher rd = req.getRequestDispatcher(purl.getURL());
		rd.forward(req, resp);
	}

	protected final String getParameterValue(String param) {
		return req.getParameter(param);
	}

	protected final String getParameterValue(HttpServletRequest request, String param) {
		return request.getParameter(param);
	}

	protected final String[] getParameterValues(String param) {
		return req.getParameterValues(param);
	}

	protected final boolean isParameterEmpty(String param) {
		boolean status = false;
		String val = getParameterValue(param);
		if (null == val || val.trim().length() == 0) {
			status = true;
		}
		return status;
	}

	protected final boolean isParameterEmpty(HttpServletRequest request, String param) {
		boolean status = false;
		String val = getParameterValue(request, param);
		if (null == val || val.trim().length() == 0) {
			status = true;
		}
		return status;
	}

	protected final void setSessionValue(SessionKeys key, final Object val) {
		req.getSession().setAttribute(key.name(), val);
	}

	protected final Object getSessionValue(SessionKeys key) {
		return req.getSession().getAttribute(key.name());
	}

	public void showMessage(String msg) {
		req.getSession().setAttribute("err", msg);
	}

	public void clearMessage() {
		req.getSession().setAttribute("err", "");
	}

	public void printAllParanKeys(HttpServletRequest request) {
		Enumeration<String> keys = request.getParameterNames();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			log.info("" + key + " val:" + request.getParameter(key));
		}
	}
}
