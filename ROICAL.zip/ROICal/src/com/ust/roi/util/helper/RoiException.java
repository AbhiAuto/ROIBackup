package com.ust.roi.util.helper;

public class RoiException extends Exception {

	private static final long serialVersionUID = 8319829201449673467L;

	public RoiException() {
		super();
	}

	public RoiException(String message) {
		super(message);
	}

	public RoiException(String message, Throwable cause) {
		super(message, cause);
	}

	public RoiException(Throwable cause) {
		super(cause);
	}

	protected RoiException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
