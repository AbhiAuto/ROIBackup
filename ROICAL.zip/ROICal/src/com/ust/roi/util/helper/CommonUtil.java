package com.ust.roi.util.helper;

import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.ust.roi.db.crud.ConfigurationLayer;

public class CommonUtil {
	private CommonUtil() {

	}

	public static <T> T getFirstRecordFromList(List<T> lst) {
		return !lst.isEmpty() ? lst.get(0) : null;
	}

	public static void logInfo(String msg) {
		Logger.getLogger(ConfigurationLayer.class.getName()).log(Level.INFO, msg);
	}

	public static void logSevere(String msg) {
		Logger.getLogger(ConfigurationLayer.class.getName()).log(Level.SEVERE, msg);
	}

	public static void logSevere(Exception ex) {
		Logger.getLogger(ConfigurationLayer.class.getName()).log(Level.SEVERE, null, ex);
	}

	public static void logWarn(String msg) {
		Logger.getLogger(ConfigurationLayer.class.getName()).log(Level.WARNING, msg);
	}

	public static String getEmptyAsZero(String val) {
		return (null == val || val.length() == 0) ? "0" : val;
	}

	public static Integer getIntValue(String value) {
		int i = 0;
		if (null != value) {
			i = Integer.parseInt(value);
		}
		return i;
	}

	public static Integer getIntValueNullIfNull(String value) {
		Integer i = null;
		if (null != value) {
			i = Integer.parseInt(value);
		}
		return i;
	}

	public static String getStringValueFromInteger(Integer value) {
		String i = null;
		if (null != value) {
			i = "" + value;
		}
		return i;
	}

	public static Float getFloatValue(String value) {
		Float i = 0F;
		if (null != value) {
			i = Float.parseFloat(value);
		}
		return i;
	}

	public static double getDouble(final String val) {
		String v = val;
		if (null == v || v.trim().length() == 0) {
			v = "0";
		}
		return Double.parseDouble(v);
	}

	public static String getString(double val) {
		return String.valueOf(val);
	}
	
	public static Double getRoundDecimal(Double d) {
		return Math.round(d * 100) / 100.0;
	}

	public static Double getRoundBigDecimal(Double d) {
		return new BigDecimal(d).setScale(2, BigDecimal.ROUND_HALF_EVEN).doubleValue();
	}

	public static String getRoundBigDecimalToString(String d) {
		if (null == d || d.trim().length() == 0 || "NaN".equals(d)) {
			return "0";
		}
		return new BigDecimal(d).setScale(0, BigDecimal.ROUND_HALF_EVEN).toString();
	}
}
