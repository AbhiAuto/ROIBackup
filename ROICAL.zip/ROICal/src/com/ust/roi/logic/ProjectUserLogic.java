package com.ust.roi.logic;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ust.roi.db.crud.ProjectUserLayer;
import com.ust.roi.db.model.ProjectUserBean;

public class ProjectUserLogic {
	private static final Logger log = LoggerFactory.getLogger(CalculationFormulaLogic.class);
	private static final String CLASS_NAME = "Class[ProjectUserLogic]";
	private ProjectUserLayer layer = new ProjectUserLayer();

	public List<ProjectUserBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public ProjectUserBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public void save(List<ProjectUserBean> lst) {
		for (ProjectUserBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<ProjectUserBean> lst) {
		for (ProjectUserBean bean : lst) {
			layer.update(bean);
		}
	}

	public void delete(List<ProjectUserBean> lst) {
		try {
			for (ProjectUserBean bean : lst) {
				layer.delete(bean);
			}
		} catch (Exception ex) {
			log.error(CLASS_NAME, ex);
		}

	}

	public List<ProjectUserBean> getListByUserId(String userId) {
		return layer.getAllByUserId(userId);
	}

}
