package com.ust.roi.logic;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.ust.roi.db.crud.CalculationFormulaLayer;

public class Dashboardlogic {
	
	private CalculationFormulaLayer layer = new CalculationFormulaLayer();
	
	private String getComplexityCount(String complexity, Integer projectId)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		String sql = "select count(*) from tbl_exe_time where complexity ='" + complexity + "' and projectId = "+ projectId;
		return layer.scalarValue(sql);
	}
	
	public ArrayList<String> getRealComplexityData(Integer projectId) throws InstantiationException, IllegalAccessException, NamingException, SQLException {
		
		ArrayList<String> RealTimeComplexity = new ArrayList<String>();
		String ComplexityHigh = getComplexityCount("high", projectId);
		RealTimeComplexity.add(ComplexityHigh);
		
		String ComplexityMedium = getComplexityCount("medium", projectId);
		RealTimeComplexity.add(ComplexityMedium);
		
		String ComplexityLow = getComplexityCount("low", projectId);
		RealTimeComplexity.add(ComplexityLow);
		
		return RealTimeComplexity;
		
	}
	

	
	

}
