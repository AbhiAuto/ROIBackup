package com.ust.roi.logic;

import static com.ust.roi.util.helper.CommonUtil.getDouble;
import static com.ust.roi.util.helper.CommonUtil.getRoundBigDecimalToString;
import static com.ust.roi.util.helper.CommonUtil.getString;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.db.crud.CalculationFormulaLayer;
import com.ust.roi.db.model.CalAutoScriptDevBean;
import com.ust.roi.db.model.CalAutoScriptExeBean;
import com.ust.roi.db.model.CalAutoScriptMait;
import com.ust.roi.db.model.CalManualTestBean;
import com.ust.roi.view.model.NameValuePair;
import com.ust.roi.view.model.SummaryView;

public class SummaryLogic {
	
	ArrayList<String> lst2 = new ArrayList<String>();
	ArrayList<String> lst3 = new ArrayList<String>();

	private static final String CNST_STYLE_BOLD = "style=\"font-weight: bold\"";
	private CalculationFormulaLayer layer = new CalculationFormulaLayer();

	/*private String getValueFromConfigTable(String projectId, String typeName, String elementName)
			throws InstantiationException, IllegalAccessException, NamingException, SQLException {
		String sql = "SELECT VALUE FROM ( "
				+ "SELECT ct.NAME AS TYPE_NAME,ce.NAME AS ELE_NAME, pce.VALUE AS VALUE    FROM configure_type ct INNER JOIN  configure_element ce "
				+ "ON ct.ID= ce.CONFIG_TYPE_ID INNER JOIN project_configure_element pce ON ce.ID=pce.CONFIG_ELEMENT_ID "
				+ " AND PROJECT_ID = " + projectId + " ) a WHERE a.TYPE_NAME='" + typeName + "' AND a.ELE_NAME='"
				+ elementName + "' ";
		return layer.scalarValue(sql);
	} */
	

	private String getLicenseCost(String projectId, String year)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		String sql = "SELECT tt.LICENSE_COST AS COST FROM tools_license_cost tt INNER JOIN USER_INPUT_TOOL ut " 
		        + "	 ON tt.TOOL_ID = ut.TOOL_ID INNER JOIN TEST_YEAR ty ON ut.YEAR_ID = ty.ID AND ut.PROJECT_ID = '"+ projectId +"' " 
				+ "	AND ut.year_id = '"+ year +"' AND tt.PROJECT_ID =  '"+ projectId +"'  ";
		return layer.scalarValue(sql);
	}

	/*private String getTestCycleCount(String projectId, String year)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		String sql = "SELECT ut.TEST_CYCLE_COUNT AS TC_COUNT FROM USER_INPUT_TOOL ut INNER JOIN TEST_YEAR ty "
				+ "ON ut.YEAR_ID = ty.ID AND PROJECT_ID = '" + projectId + "' AND YEAR_ID = '" + year + "'";
		return layer.scalarValue(sql);
	}*/
	
	private String getTestCycleCount(String projectId, String year)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		String sql = "SELECT TEST_CYCLE_COUNT from user_input_tool WHERE (PROJECT_ID = " + projectId + " AND YEAR_ID = "+ year +")";
		return layer.scalarValue(sql);
	}

	private String getLicenseCount(String projectId, String year)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		String sql = "SELECT LICENSE_COUNT AS TC_COUNT FROM USER_INPUT_TOOL WHERE PROJECT_ID = '" + projectId
				+ "' AND YEAR_ID = '" + year + "'";
		return layer.scalarValue(sql);
	}
	
	

	public List<SummaryView> doSummaryCalculation(String projectId)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		
		List<SummaryView> lstView = new ArrayList<>();
		CalAutoScriptExeBean cbean;
		CalManualTestBean cManbean;
		CalAutoScriptDevBean cAdbean;
		CalAutoScriptMait cAmbean;
		CalculationFormulaLogic cabean;
		SummaryView bean;
		cabean = new CalculationFormulaLogic();
		cbean = cabean.doCalculationForAutoScriptExecution(projectId);
		cManbean = cabean.doCaluclationForMaualtesting(projectId);
		cAdbean = cabean.doCalculationForAutoScriptDevelopment(projectId);
		String caY1c32 = cAdbean.getTotalCostForScriptDev();
		cAmbean = cabean.doCalculationForAutoScriptMaintainence(projectId);
		String caY1c46 = cAmbean.getCostOfAutoMaintanenceAtOffshore();
		bean = new SummaryView();
		bean.setElements("Number of test cycle");
		String sY1c5 = getTestCycleCount(projectId, "1");
		bean.setY1(getRoundBigDecimalToString(sY1c5));
		String sY2d5 = getTestCycleCount(projectId, "2");
		bean.setY2(getRoundBigDecimalToString(sY2d5));
		String sY3e5 = getTestCycleCount(projectId, "3");
		bean.setY3(getRoundBigDecimalToString(sY3e5));
		String sY4f5 = getTestCycleCount(projectId, "4");
		bean.setY4(getRoundBigDecimalToString(sY4f5));
		String sY5g5 = getTestCycleCount(projectId, "5");
		System.out.println("testcount=="+sY1c5+sY2d5+sY3e5);
		bean.setY5(getRoundBigDecimalToString(sY5g5));
		bean.setPercent(false);
		bean.setSybl(false);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Total cost of Automated testing");
		//String cY2d15 = getValueFromConfigTable(projectId, 'Test Cycle Count', 'Test Cycle Count');
		String caY1c41 = cbean.getCostAutoTestingWithOffshoreRes();
		String caY1c42 = cbean.getCostAutoTestingWithOnshoreRes();
				
		Double TotalY1cal = getDouble(caY1c41) + getDouble(caY1c42);
		String strTotalY1cal = getString(TotalY1cal);
		
		System.out.println("costwithoff===" + caY1c41);
		bean.setY1(getRoundBigDecimalToString(getTotCostAutoTest(sY1c5, strTotalY1cal, "")));
		String sY1c6 = bean.getY1();
		bean.setY2(getRoundBigDecimalToString(getTotCostAutoTest(sY2d5, strTotalY1cal, sY1c6)));
		String sY2d6 = bean.getY2();
		bean.setY3(getRoundBigDecimalToString(getTotCostAutoTest(sY3e5, strTotalY1cal, sY2d6)));
		String sY3e6 = bean.getY3();
		bean.setY4(getRoundBigDecimalToString(getTotCostAutoTest(sY4f5, strTotalY1cal, sY3e6)));
		String sY4f6 = bean.getY4();
		bean.setY5(getRoundBigDecimalToString(getTotCostAutoTest(sY5g5, strTotalY1cal, sY4f6)));
		String sY5g6 = bean.getY5();
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Total cost of manual Testing");
		String caY1c16 = cManbean.getTotalManualCostPerCycle();
		bean.setY1(getRoundBigDecimalToString(getTotCostManualTest(caY1c16, sY1c5, "")));
		String sY1c7 = bean.getY1();
		bean.setY2(getRoundBigDecimalToString(getTotCostManualTest(sY2d5, caY1c16, sY1c7)));
		String sY2d7 = bean.getY2();
		bean.setY3(getRoundBigDecimalToString(getTotCostManualTest(sY3e5, caY1c16, sY2d7)));
		String sY3e7 = bean.getY3();
		bean.setY4(getRoundBigDecimalToString(getTotCostManualTest(sY4f5, caY1c16, sY3e7)));
		String sY4f7 = bean.getY4();
		bean.setY5(getRoundBigDecimalToString(getTotCostManualTest(sY5g5, caY1c16, sY4f7)));
		String sY5g7 = bean.getY5();
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Total cost saved");
		bean.setY1(getRoundBigDecimalToString(getTotCostSaved(sY1c6, sY1c7)));
		String sY1c8 = bean.getY1();
		bean.setY2(getRoundBigDecimalToString(getTotCostSaved(sY2d6, sY2d7)));
		String sY2d8 = bean.getY2();
		bean.setY3(getRoundBigDecimalToString(getTotCostSaved(sY3e6, sY3e7)));
		String sY3e8 = bean.getY3();
		bean.setY4(getRoundBigDecimalToString(getTotCostSaved(sY4f6, sY4f7)));
		String sY4f8 = bean.getY4();
		bean.setY5(getRoundBigDecimalToString(getTotCostSaved(sY5g6, sY5g7)));
		String sY5g8 = bean.getY5();
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Cost of automation");
		bean.setY1("");
		bean.setY2("");
		bean.setY3("");
		bean.setY4("");
		bean.setY5("");
		bean.setViewM(CNST_STYLE_BOLD);
		bean.setPercent(false);
		bean.setSybl(false);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Automation Development Cost");
		bean.setY1(getRoundBigDecimalToString(getString(getDouble(caY1c32))));
		String sY1c10 = bean.getY1();
		bean.setY2(getRoundBigDecimalToString(getString(getDouble(caY1c32))));
		String sY2d10 = bean.getY2();
		bean.setY3(getRoundBigDecimalToString(getString(getDouble(caY1c32))));
		String sY3e10 = bean.getY3();
		bean.setY4(getRoundBigDecimalToString(getString(getDouble(caY1c32))));
		String sY4f10 = bean.getY4();
		bean.setY5(getRoundBigDecimalToString(getString(getDouble(caY1c32))));
		String sY5g10 = bean.getY5();
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Automatic Script Maintain cost");
		bean.setY1(getRoundBigDecimalToString(getString(getDouble(caY1c46))));
		String sY1c11 = bean.getY1();
		bean.setY2(getRoundBigDecimalToString(getString(getDouble(sY1c11) * 2)));
		String sY2d11 = bean.getY2();
		bean.setY3(getRoundBigDecimalToString(getString(getDouble(sY1c11) * 3)));
		String sY3e11 = bean.getY3();
		bean.setY4(getRoundBigDecimalToString(getString(getDouble(sY1c11) * 4)));
		String sY4f11 = bean.getY4();
		bean.setY5(getRoundBigDecimalToString(getString(getDouble(sY1c11) * 5)));
		String sY5g11 = bean.getY5();
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Testing Tool License Cost");
		String iY1c14Y1 = getLicenseCount(projectId, "1");
		String cY1c22Y1 = getLicenseCost(projectId, "1");
		bean.setY1(getRoundBigDecimalToString(getString(getDouble(iY1c14Y1) * getDouble(cY1c22Y1))));
		String sY1c12 = bean.getY1();
		String iY1c14Y2 = getLicenseCount(projectId, "2");
		String cY1c22Y2 = getLicenseCost(projectId, "2");
		bean.setY2(getRoundBigDecimalToString(getString(getDouble(iY1c14Y2) * getDouble(cY1c22Y2))));
		String sY2d12 = bean.getY2();
		String iY1c14Y3 = getLicenseCount(projectId, "3");
		String cY1c22Y3 = getLicenseCost(projectId, "3");
		bean.setY3(getRoundBigDecimalToString(getString(getDouble(iY1c14Y3) * getDouble(cY1c22Y3))));
		String sY3e12 = bean.getY3();
		String iY1c14Y4 = getLicenseCount(projectId, "4");
		String cY1c22Y4 = getLicenseCost(projectId, "4");
		bean.setY4(getRoundBigDecimalToString(getString(getDouble(iY1c14Y4) * getDouble(cY1c22Y4))));
		String sY4f12 = bean.getY4();
		String iY1c14Y5 = getLicenseCount(projectId, "5");
		String cY1c22Y5 = getLicenseCost(projectId, "5");
		bean.setY5(getRoundBigDecimalToString(getString(getDouble(iY1c14Y5) * getDouble(cY1c22Y5))));
		String sY5g12 = bean.getY5();
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Total cost of Automation");
		bean.setY1(getRoundBigDecimalToString(
				getString(getDouble(sY1c6) + getDouble(sY1c10) + getDouble(sY1c11) + getDouble(sY1c12))));
		String sY1c13 = bean.getY1();
		bean.setY2(getRoundBigDecimalToString(
				getString(getDouble(sY2d6) + getDouble(sY2d10) + getDouble(sY2d11) + getDouble(sY2d12))));
		String sY2d13 = bean.getY2();
		bean.setY3(getRoundBigDecimalToString(
				getString(getDouble(sY3e6) + getDouble(sY3e10) + getDouble(sY3e11) + getDouble(sY3e12))));
		String sY3e13 = bean.getY3();
		bean.setY4(getRoundBigDecimalToString(
				getString(getDouble(sY4f6) + getDouble(sY4f10) + getDouble(sY4f11) + getDouble(sY4f12))));
		String sY4f13 = bean.getY4();
		bean.setY5(getRoundBigDecimalToString(
				getString(getDouble(sY5g6) + getDouble(sY5g10) + getDouble(sY5g11) + getDouble(sY5g12))));
		String sY5g13 = bean.getY5();
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("Net Savings");
		bean.setY1(getRoundBigDecimalToString(getTotCostSaved(sY1c13, sY1c8)));
		String sY1c14 = bean.getY1();
		lst3.add(sY1c14);
		bean.setY2(getRoundBigDecimalToString(getTotCostSaved(sY2d13, sY2d8)));
		String sY2d14 = bean.getY2();
		bean.setY3(getRoundBigDecimalToString(getTotCostSaved(sY3e13, sY3e8)));
		String sY3e14 = bean.getY3();
		bean.setY4(getRoundBigDecimalToString(getTotCostSaved(sY4f13, sY4f8)));
		String sY4f14 = bean.getY4();
		bean.setY5(getRoundBigDecimalToString(getTotCostSaved(sY5g13, sY5g8)));
		String sY5g14 = bean.getY5();
		bean.setViewM(CNST_STYLE_BOLD);
		bean.setPercent(false);
		bean.setSybl(true);
		lstView.add(bean);

		bean = new SummaryView();
		bean.setElements("ROI");
		DecimalFormat df=new DecimalFormat("0.00");
		if (getDouble(sY1c13) != 0) {
		bean.setY1(df.format(getDouble(sY1c14) / getDouble(sY1c13) * 100));
		bean.setY2(df.format(getDouble(sY2d14) / getDouble(sY2d13) * 100));
		bean.setY3(df.format(getDouble(sY3e14) / getDouble(sY3e13) * 100));
		bean.setY4(df.format(getDouble(sY4f14) / getDouble(sY4f13) * 100));
		bean.setY5(df.format(getDouble(sY5g14) / getDouble(sY5g13) * 100));
		}
		else {
			bean.setY1("0");
			bean.setY2("0");
			bean.setY3("0");
			bean.setY4("0");
			bean.setY5("0");
		}
		bean.setViewM(CNST_STYLE_BOLD);
		bean.setSybl(false);
		bean.setPercent(true);
		lstView.add(bean);
		lst2.add(bean.getY1());
		lst2.add(bean.getY2());
		//lst2.add(bean.getY1());
		//lst2.add(bean.getY1());
		//lst2.add(bean.getY1());
		System.out.println("y1roi==="+bean.getY1());
		return lstView;
	}

	public HashMap<String, List<NameValuePair>> getGraphData(String projectId)
			throws InstantiationException, IllegalAccessException, NamingException, SQLException {
		HashMap<String, List<NameValuePair>> hmList = new HashMap<>();
		List<SummaryView> lstSum = doSummaryCalculation(projectId);
		SummaryView svNetSave = null;
		SummaryView svROIPer = null;
		for (SummaryView summaryView : lstSum) {
			if ("Net Savings".equals(summaryView.getElements())) {
				svNetSave = summaryView;
			}
			if ("ROI".equals(summaryView.getElements())) {
				svROIPer = summaryView;
			}
		}
		hmList.put("NETSAVE", getSumViewToNameViewList(svNetSave));
		hmList.put("ROIPERT", getSumViewToNameViewList(svROIPer));
		return hmList;
	}

	private List<NameValuePair> getSumViewToNameViewList(SummaryView sv) {
		List<NameValuePair> lst = new ArrayList<>();
		NameValuePair nvp = null;
		if (null != sv) {
			nvp = new NameValuePair("Year1", String.valueOf(getDouble(sv.getY1())));
			lst.add(nvp);
			nvp = new NameValuePair("Year2", String.valueOf(getDouble(sv.getY2())));
			lst.add(nvp);
			nvp = new NameValuePair("Year3", String.valueOf(getDouble(sv.getY3())));
			lst.add(nvp);
			nvp = new NameValuePair("Year4", String.valueOf(getDouble(sv.getY4())));
			lst.add(nvp);
			nvp = new NameValuePair("Year5", String.valueOf(getDouble(sv.getY5())));
			lst.add(nvp);
		}
		return lst;
	}

	
	public ArrayList<String> getPlannedROI()
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		return lst2;
	}
	
	public ArrayList<String> getSavingsPlanned()
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		return lst3;
	}
	
	private String getTotCostSaved(String sY1c6, String sY1c7) {
		return getString(getDouble(sY1c7) - getDouble(sY1c6));
	}

	private String getTotCostManualTest(String sY2d5, String caY1c16, String sY1c7) {
		return getString((getDouble(caY1c16) * getDouble(sY2d5)) + getDouble(sY1c7));
	}

	private String getTotCostAutoTest(String sY2d5, String caY1c41, String sY1c6) {
		return getString(getDouble(sY2d5) * getDouble(caY1c41) + getDouble(sY1c6));
	}

}
