package com.ust.roi.logic;

import java.util.List;

import com.ust.roi.db.crud.UserRoleLayer;
import com.ust.roi.db.model.UserRoleBean;

public class UserRoleLogic {

	private UserRoleLayer layer = new UserRoleLayer();

	public List<UserRoleBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public UserRoleBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public UserRoleBean getBeanByUserName(String uname) {
		return layer.getByUserName(uname);
	}

	public void save(List<UserRoleBean> lst) {
		for (UserRoleBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<UserRoleBean> lst) {
		for (UserRoleBean bean : lst) {
			layer.update(bean);
		}
	}
}
