package com.ust.roi.logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ust.roi.db.model.ProjectUserBean;
import com.ust.roi.db.model.UserBean;

public class UserAssignedLogic {
	private ProjectUserLogic logic1 = new ProjectUserLogic();
	private UserLogic logic2 = new UserLogic();

	public Map<String, List<UserBean>> getUserAssignedToProject(String projectId) {
		Map<String, List<UserBean>> hmLst = new HashMap<>();
		List<UserBean> sellst = new ArrayList<>();
		List<UserBean> nosellst = logic2.getListByProjectId(projectId);
		List<ProjectUserBean> plst = logic1.getListByProjectId(projectId);
		if (plst.isEmpty()) {
			hmLst.put("SELECTED", sellst);
			hmLst.put("NOTSELECTED", nosellst);
			return hmLst;
		}
		for (int i = 0; i < nosellst.size(); i++) {
			final UserBean ubean = nosellst.get(i);
			if (plst.isEmpty()) {
				break;
			}
			for (int j = 0; j < plst.size(); j++) {
				final ProjectUserBean pbean = plst.get(j);
				if (ubean.getId() == pbean.getUserId()) {
					sellst.add(ubean);
					plst.remove(j);
					nosellst.remove(i);
					j = j - 1;
					i = i - 1;
					break;
				}
			}
		}
		hmLst.put("SELECTED", sellst);
		hmLst.put("NOTSELECTED", nosellst);
		return hmLst;
	}

	public void saveUserAssignment(String[] userids, Integer projectId) {
		List<String> lstUserIds = new ArrayList<>();
		for (String id : userids) {
			lstUserIds.add(id);
		}

		List<ProjectUserBean> plst = logic1.getListByProjectId("" + projectId);
		for (int j = 0; j < plst.size(); j++) {
			final ProjectUserBean pbean = plst.get(j);
			for (int i = 0; i < lstUserIds.size(); i++) {
				final String userId = lstUserIds.get(i);
				if (pbean.getUserId().toString().equals(userId)) {
					plst.remove(j);
					j = j - 1;
					lstUserIds.remove(i);
					i = i - 1;
					break;
				}
			}
		}
		List<ProjectUserBean> savelst = new ArrayList<>();
		for (String id : lstUserIds) {
			ProjectUserBean bean = new ProjectUserBean();
			bean.setProjectId(projectId);
			bean.setUserId(Integer.parseInt(id));
			savelst.add(bean);
		}
		logic1.save(savelst);
		logic1.delete(plst);
	}
}
