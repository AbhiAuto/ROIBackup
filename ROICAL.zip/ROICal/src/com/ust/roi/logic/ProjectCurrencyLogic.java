package com.ust.roi.logic;

import java.util.List;

import com.ust.roi.db.crud.ProjectCurrencyLayer;
import com.ust.roi.db.model.ProjectCurrencyBean;
import com.ust.roi.view.model.NameValuePair;

public class ProjectCurrencyLogic {
	private ProjectCurrencyLayer layer = new ProjectCurrencyLayer();

	public List<ProjectCurrencyBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public ProjectCurrencyBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public void save(List<ProjectCurrencyBean> lst) {
		for (ProjectCurrencyBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<ProjectCurrencyBean> lst) {
		for (ProjectCurrencyBean bean : lst) {
			layer.update(bean);
		}
	}
	
	public List<NameValuePair> getCurrencyList() {
		return layer.getAllCurrency();
	}
}
