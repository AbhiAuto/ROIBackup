package com.ust.roi.logic;

import java.util.ArrayList;
import java.util.List;

import com.ust.roi.db.crud.UserLayer;
import com.ust.roi.db.model.UserBean;
import com.ust.roi.view.model.UserAssignAvailableView;

public class UserAssignAvailableLogic {
	private UserLayer layer = new UserLayer();

	public List<UserBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public UserBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public void save(List<UserBean> lst) {
		for (UserBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<UserBean> lst) {
		for (UserBean bean : lst) {
			layer.update(bean);
		}
	}

	public List<UserAssignAvailableView> getUserAssignAvailableLogic() {
		List<UserAssignAvailableView> lstView = new ArrayList<>();
		UserAssignAvailableView sv;
		sv = new UserAssignAvailableView();
		sv.setUname("User1");
		lstView.add(sv);

		sv = new UserAssignAvailableView();
		sv.setUname("User2");
		lstView.add(sv);

		sv = new UserAssignAvailableView();
		sv.setUname("User3");
		lstView.add(sv);

		sv = new UserAssignAvailableView();
		sv.setUname("User4");
		lstView.add(sv);

		return lstView;

	}
}