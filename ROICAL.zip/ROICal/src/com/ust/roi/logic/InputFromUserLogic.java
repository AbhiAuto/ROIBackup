package com.ust.roi.logic;

import java.util.List;

import com.ust.roi.db.crud.InputUserLayer;
import com.ust.roi.db.model.InputUserBean;

public class InputFromUserLogic {
	private InputUserLayer layer = new InputUserLayer();

	public List<InputUserBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public InputUserBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public void save(List<InputUserBean> lst) {
		for (InputUserBean bean : lst) {
			layer.save(bean);
		}
	}
	
	public void update(List<InputUserBean> lst) {
		for (InputUserBean bean : lst) {
			layer.update(bean);
		}
	}
}
