package com.ust.roi.logic;

import java.util.ArrayList;
import java.util.List;

import com.ust.roi.db.crud.ProjectLayer;
import com.ust.roi.db.model.ProjectBean;
import com.ust.roi.view.model.AdminCurrentLandingView;

public class CurrentProjectLogic {
	private ProjectLayer layer = new ProjectLayer();

	public ProjectBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public List<ProjectBean> getList() {
		return layer.getAll("");
	}

	public List<AdminCurrentLandingView> getAdminCurrentLandingLogic() {
		List<AdminCurrentLandingView> lstView = new ArrayList<>();
		List<ProjectBean> lst = getList();
		if (null != lst) {
			AdminCurrentLandingView sv;
			for (ProjectBean bean : lst) {
				sv = new AdminCurrentLandingView();
				sv.setPrjName(bean.getName());
				sv.setPrjDesp(bean.getDescription());
				sv.setPrjId("" + bean.getId());
				lstView.add(sv);
			}
		}
		return lstView;

	}

	public List<AdminCurrentLandingView> getAdminCurrentLandingLogic(List<String> prjIds) {
		List<AdminCurrentLandingView> lstView = new ArrayList<>();
		List<ProjectBean> lst = getList();
		if (null != lst) {
			AdminCurrentLandingView sv;
			for (ProjectBean bean : lst) {
				if (prjIds.contains("" + bean.getId())) {
					sv = new AdminCurrentLandingView();
					sv.setPrjName(bean.getName());
					sv.setPrjDesp(bean.getDescription());
					sv.setPrjId("" + bean.getId());
					lstView.add(sv);
				}
			}
		}
		return lstView;

	}
}
