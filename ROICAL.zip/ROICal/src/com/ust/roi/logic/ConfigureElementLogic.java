package com.ust.roi.logic;

import java.util.Currency;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.ust.roi.db.crud.ConfigurationLayer;
import com.ust.roi.db.model.ConfigureElementBean;

public class ConfigureElementLogic {

	String driverName = "com.mysql.jdbc.Driver";
	String connectionUrl = "jdbc:mysql://localhost:3306/";
	String dbName = "roicaldb";
	String userId = "root";
	String password = "qwerty12345";

	private static String sh;
	private ConfigurationLayer layer = new ConfigurationLayer();

	public List<ConfigureElementBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public ConfigureElementBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public void save(List<ConfigureElementBean> lst) {
		for (ConfigureElementBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<ConfigureElementBean> lst) {
		for (ConfigureElementBean bean : lst) {
			layer.update(bean);
		}
	}

	static String sh1 = null;

	public void save1(String tool, String cost, String currencyId, int projectId, String type) {
		String driverName = "com.mysql.jdbc.Driver";
		String connectionUrl = "jdbc:mysql://localhost:3306/";
		String dbName = "roicaldb";
		String userId = "root";
		String password = "qwerty12345";
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Connection connection = null;
			Statement statementh = null;
			Statement statementh1 = null;
			Statement stat1 = null;
			ResultSet resultSetl = null;
			ResultSet res = null;

			connection = DriverManager.getConnection(connectionUrl + dbName, userId, password);
			statementh = connection.createStatement();
			statementh1 = connection.createStatement();
			stat1 = connection.createStatement();
			System.out.println("tool====" + tool + cost);
			int cost1 = Integer.parseInt(cost);
			int symbol = Integer.parseInt(currencyId);

			String gg = "select * from currency where ID = " + symbol + " ";
			System.out.println(gg);
			resultSetl = statementh1.executeQuery(gg);
			while (resultSetl.next()) {
				ConfigureElementLogic.sh1 = resultSetl.getString("SYMBL");
			}
			String k = ConfigureElementLogic.sh1;
			System.out.println("sh====" + ConfigureElementLogic.sh1);
			String qmin = "insert into testing_tools(NAME,LICENSE_COST,CURRENCY,LicenseType) values (\"" + tool + "\","
					+ cost1 + ",\"$\",\"" + type + "\")";
			System.out.println("qmin===" + qmin);

			statementh.executeUpdate(qmin);

			String gh = "insert into tools_license_cost(PROJECT_ID,TOOL_ID,LICENSE_COST) values(" + projectId
					+ ",(select ID from testing_tools where Name=\"" + tool + "\")," + cost1 + ")";
			stat1.executeUpdate(gh);

			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String sa(String CurrencyId) {
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Connection connection = null;
			Statement statementh = null;
			Statement statementh1 = null;
			Statement stat1 = null;
			ResultSet resultSetl = null;
			ResultSet res = null;

			connection = DriverManager.getConnection(connectionUrl + dbName, userId, password);
			statementh = connection.createStatement();
			statementh1 = connection.createStatement();
			stat1 = connection.createStatement();
			int symbol = Integer.parseInt(CurrencyId);

			String gg = "select * from currency where ID = " + symbol + " ";
			System.out.println(gg);
			resultSetl = statementh1.executeQuery(gg);
			while (resultSetl.next()) {
				ConfigureElementLogic.sh1 = resultSetl.getString("SYMBL");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ConfigureElementLogic.sh1;
	}

}
