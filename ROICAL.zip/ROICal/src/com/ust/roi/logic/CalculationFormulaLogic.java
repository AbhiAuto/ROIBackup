package com.ust.roi.logic;

import com.ust.roi.logic.Dashboardlogic;
import static com.ust.roi.util.helper.CommonUtil.getDouble;
import static com.ust.roi.util.helper.CommonUtil.getString;

import java.sql.SQLException;
import java.text.DecimalFormat;

import javax.naming.NamingException;

import org.jfree.chart.block.ColumnArrangement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ust.roi.db.crud.CalculationFormulaLayer;
import com.ust.roi.db.model.CalAutoScriptDevBean;
import com.ust.roi.db.model.CalAutoScriptExeBean;
import com.ust.roi.db.model.CalAutoScriptMait;
import com.ust.roi.db.model.CalManualTestBean;

public class CalculationFormulaLogic {
	private static final Logger log = LoggerFactory.getLogger(CalculationFormulaLogic.class);
	private static final String CLASS_NAME = "Class[CalculationFormulaLogic]";
	private static final String VAL_PRODUCTIVITY_AUTOMATION = "Productivity Automation";
	private static final String VAL_PRODUCTIVITY_EXECUTION_AUTOMATION = "Productivity Execution - Automation";
	private static final String VAL_OFF_SHORE_COST = "OffShore Cost";
	private static final String VAL_ON_SITE_COST = "OnSite Cost";
	private static final String VAL_BILL_RATE = "Bill Rate";
	private static final String VAL_OFFSHORE = "Offshore";
	private static final String VAL_ONSITE = "Onsite";
	private static final String VAL_RESOURCE_MIX = "Resource Mix";
	private static final String VAL_LOW = "Low";
	private static final String VAL_MEDIUM = "Medium";
	private static final String VAL_HIGH = "High";
	private static final String VAL_PRODUCTIVITY_MANUAL = "Productivity Manual";
	private static final String COL_COMPLEX_LOW = "COMPLEX_LOW";
	private static final String COL_COMPLEX_MEDIUM = "COMPLEX_MEDIUM";
	private static final String COL_COMPLEX_HIGH = "COMPLEX_HIGH";
	private CalculationFormulaLayer layer = new CalculationFormulaLayer();

	private String getValueFromInputTable(String column, String projectId, String inputTypeId)
			throws InstantiationException, IllegalAccessException, NamingException, SQLException {
		String sql = String.format("SELECT %s FROM USER_INPUT WHERE PROJECT_ID=%s AND INPUT_TYPE_ID=%s", column,
				projectId, inputTypeId);
		return layer.scalarValue(sql);
	}

	private String getValueFromConfigTable(String projectId, String typeName, String elementName)
			throws InstantiationException, IllegalAccessException, NamingException, SQLException {
		String sql = String.format(
				"SELECT VALUE FROM ( SELECT ct.NAME AS TYPE_NAME,ce.NAME AS ELE_NAME, pce.VALUE AS VALUE FROM configure_type ct "
						+ " INNER JOIN  configure_element ce ON ct.ID= ce.CONFIG_TYPE_ID INNER JOIN project_configure_element pce ON ce.ID=pce.CONFIG_ELEMENT_ID "
						+ " AND PROJECT_ID = %s ) a WHERE a.TYPE_NAME='%s' AND a.ELE_NAME='" + elementName + "' ",
				projectId, typeName);
		return layer.scalarValue(sql);
	}

	private String getValueFromExeTimetable(String projectId)
			throws InstantiationException, IllegalAccessException, NamingException, SQLException {
		String sql = "SELECT sum(exeTime) FROM roicaldb.tbl_exe_time where projectId=" + projectId + "";
		System.out.println("sql------------------"+sql);
		return layer.scalarValue(sql);
	}
	
	private String getValueFromMaintEfforttable(String projectId)
			throws InstantiationException, IllegalAccessException, NamingException, SQLException {
		String sql = "SELECT sum(HOURS) FROM roicaldb.maintenanceeffort where projectid=" + projectId + "";
		System.out.println("sql------------------"+sql);
		return layer.scalarValue(sql);
	}
	
	private String getComplexityCount(String complexity)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		String sql = "select count(*) from tbl_exe_time where complexity ='" + complexity + "'";
		return layer.scalarValue(sql);
	}
	
	
	public CalManualTestBean doCaluclationForMaualtesting(String projectId) {

		CalManualTestBean bean = new CalManualTestBean();
		String sql = "";
		try {
			sql = String.format("SELECT TOTAL_VALUE FROM USER_INPUT WHERE PROJECT_ID=%s AND INPUT_TYPE_ID=1",
					projectId);
			String iC6 = layer.scalarValue(sql);
			bean.setManualTestCases(iC6);

			String iD6 = getValueFromInputTable(COL_COMPLEX_HIGH, projectId, "1");
			bean.setHighTestCases(iD6);

			String iE6 = getValueFromInputTable(COL_COMPLEX_MEDIUM, projectId, "1");
			bean.setMediumTestCases(iE6);

			String iF6 = getValueFromInputTable(COL_COMPLEX_LOW, projectId, "1");
			bean.setLowTestCases(iF6);

			String cD8 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_MANUAL, VAL_HIGH);
			bean.setHighTestCaseExecutionEffect(getString(getDouble(iD6) * getDouble(cD8)));

			String cD9 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_MANUAL, VAL_MEDIUM);
			bean.setMediumTestCaseExecutionEffect(getString(getDouble(iE6) * getDouble(cD9)));

			String cD10 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_MANUAL, VAL_LOW);
			bean.setLowTestCaseExecutionEffect(getString(getDouble(iF6) * getDouble(cD10)));

			String caC8 = bean.getHighTestCaseExecutionEffect();
			String caC9 = bean.getMediumTestCaseExecutionEffect();
			String caC10 = bean.getLowTestCaseExecutionEffect();
			bean.setTotalHours(getString(getDouble(caC8) + getDouble(caC9) + getDouble(caC10)));

			String cD3 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_ONSITE);
			String cD4 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_OFFSHORE);
			String caC11 = bean.getTotalHours();
			bean.setOnsiteHours(getString(getDouble(cD3) / 100 * getDouble(caC11)));
			bean.setOffshoreHours(getString(getDouble(cD4) / 100 * getDouble(caC11)));

			String caC12 = bean.getOnsiteHours();
			String caC13 = bean.getOffshoreHours();
			String cD5 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_ON_SITE_COST);
			String cD6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_OFF_SHORE_COST);
			bean.setOnsiteCost(getString(getDouble(caC12) * getDouble(cD5)));
			bean.setOffshoreCost(getString(getDouble(caC13) * getDouble(cD6)));

			String caC14 = bean.getOnsiteCost();
			String caC15 = bean.getOffshoreCost();
			bean.setTotalManualCostPerCycle(getString(getDouble(caC14) + getDouble(caC15)));

		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			log.error(CLASS_NAME, ex);
		}
		return bean;
	}

	public CalAutoScriptDevBean doCalculationForAutoScriptDevelopment(String projectId) {

		CalAutoScriptDevBean bean = new CalAutoScriptDevBean();
		String sql = "";
		try {
			sql = String.format("SELECT TOTAL_VALUE FROM USER_INPUT WHERE PROJECT_ID=%s AND INPUT_TYPE_ID=2",
					projectId);
			String iC7 = layer.scalarValue(sql);
			bean.setAutoTestCases(iC7);

			String iD7 = getValueFromInputTable(COL_COMPLEX_HIGH, projectId, "2");
			bean.setHighTestCase(iD7);

			String iE7 = getValueFromInputTable(COL_COMPLEX_MEDIUM, projectId, "2");
			bean.setMediumTestCase(iE7);

			String iF7 = getValueFromInputTable(COL_COMPLEX_LOW, projectId, "2");
			bean.setLowTestCase(iF7);

			String cD11 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_AUTOMATION, VAL_HIGH);
			bean.setHighTestCaseDevEffort(getString(getDouble(cD11) * getDouble(iD7)));

			String cD12 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_AUTOMATION, VAL_MEDIUM);
			bean.setMediumTestCaseDevEffort(getString(getDouble(cD12) * getDouble(iE7)));

			String cD13 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_AUTOMATION, VAL_LOW);
			bean.setLowTestCaseDevEffort(getString(getDouble(cD13) * getDouble(iF7)));

			sql = "SELECT TOTAL_VALUE FROM USER_INPUT WHERE PROJECT_ID=" + projectId + " AND INPUT_TYPE_ID=5";
			String iC10 = layer.scalarValue(sql);
			bean.setFrameworkDev(iC10);

			String caC23 = bean.getHighTestCaseDevEffort();
			String caC24 = bean.getMediumTestCaseDevEffort();
			String caC25 = bean.getLowTestCaseDevEffort();
			String caC26 = bean.getFrameworkDev();

			bean.setTotalHours(getString(getDouble(caC23) + getDouble(caC24) + getDouble(caC25) + getDouble(caC26)));

			String cD3 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_ONSITE);
			String caC27 = bean.getTotalHours();

			bean.setOnsiteHours(getString(getDouble(cD3) / 100 * getDouble(caC27)));

			String cD4 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_OFFSHORE);
			bean.setOffshoreHours(getString(getDouble(cD4) / 100 * getDouble(caC27)));

			String caC28 = bean.getOnsiteHours();
			String caC29 = bean.getOffshoreHours();

			String cD5 = getValueFromConfigTable(projectId, VAL_BILL_RATE, "Onsite Cost");
			String cD6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, "Offshore Cost");

			bean.setOnsiteCost(getString(getDouble(caC28) * getDouble(cD5)));
			bean.setOffshoreCost(getString(getDouble(caC29) * getDouble(cD6)));
			String caC30 = bean.getOnsiteCost();
			String caC31 = bean.getOffshoreCost();

			bean.setTotalCostForScriptDev(getString(getDouble(caC30) + getDouble(caC31)));

		} catch (NamingException | SQLException | InstantiationException | IllegalAccessException ex) {
			log.error(CLASS_NAME, ex);
		}
		return bean;
	}

	public CalAutoScriptExeBean doCalculationForAutoScriptExecution(String projectId) {

		CalAutoScriptExeBean bean = new CalAutoScriptExeBean();
		try {
			String iC9 = getValueFromInputTable(COL_COMPLEX_HIGH, projectId, "4");
			String iD9 = getValueFromInputTable(COL_COMPLEX_MEDIUM, projectId, "4");
			String iE9 = getValueFromInputTable(COL_COMPLEX_LOW, projectId, "4");
			bean.setHighAutomationTcScript(iC9);
			bean.setMediumAutomationTcScript(iD9);
			bean.setLowAutomationTcScript(iE9);

			String cD16 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_EXECUTION_AUTOMATION, VAL_HIGH);
			/*
			 * int caC34 = Integer.parseInt(getValueFromhigh(projectId));
			 * System.out.println("high===" + caC34); int caC35 =
			 * Integer.parseInt(getValueFrommedium(projectId));
			 * System.out.println("medium===" + caC35); int caC36 =
			 * Integer.parseInt(getValueFromlow(projectId)); System.out.println("low===" +
			 * caC36);
			 */
			String cD17 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_EXECUTION_AUTOMATION, VAL_MEDIUM);
			String cD18 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_EXECUTION_AUTOMATION, VAL_LOW);
			bean.setHoursReqPerHourForHigh(getString(getDouble(iC9) * getDouble(cD16)));
			bean.setHoursReqPerHourForMedium(getString(getDouble(iD9) * getDouble(cD17)));
			bean.setHoursReqPerHourForLow(getString(getDouble(iE9) * getDouble(cD18)));
			System.out.println("ic9==" + iC9 + " " + iD9 + " " + iE9 + " " + cD16 + " " + cD17 + " " + cD18);
			String caC37 = bean.getHoursReqPerHourForHigh();
			String caC38 = bean.getHoursReqPerHourForMedium();
			String caC39 = bean.getHoursReqPerHourForLow();


			/*
			 * System.out.println("val====" + getString(getDouble(caC37) * caC34 +
			 * getDouble(caC38) * caC35 + getDouble(caC39) * caC36));
			 */
			// bean.setTotalAutomationHoursPerCycle1(getString(getDouble(caC37)*caC34 +
			// getDouble(caC38)*caC35 + getDouble(caC39)*caC36));

			bean.setTotalAutomationHoursPerCycle(getString(getDouble(caC37) + getDouble(caC38) + getDouble(caC39)));

			bean.setHoursReqPerHourForHigh(getString(getDouble(cD16)));
			bean.setHoursReqPerHourForMedium(getString(getDouble(cD17)));
			bean.setHoursReqPerHourForLow(getString(getDouble(cD18)));
			caC37 = bean.getHoursReqPerHourForHigh();
			caC38 = bean.getHoursReqPerHourForMedium();
			caC39 = bean.getHoursReqPerHourForLow();
			// this code is written by arjun
			/*
			 * bean.setTotalAutomationHoursPerCycle1( getString(getDouble(caC37) * caC34 +
			 * getDouble(caC38) * caC35 + getDouble(caC39) * caC36));
			 */
			// To fetch the Offshore and Onshore cost- 2/15/2019
			String cD6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_OFF_SHORE_COST);
			String cOn6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_ON_SITE_COST);
			
			String cD3 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_ONSITE);
			String cD4 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_OFFSHORE);
			String caC40 = bean.getTotalAutomationHoursPerCycle();
			
			bean.setOnsiteHours(getString(getDouble(cD3) / 100 * getDouble(caC40)));
			bean.setOffshoreHours(getString(getDouble(cD4) / 100 * getDouble(caC40)));
			
			String caC28 = bean.getOnsiteHours();
			String caC29 = bean.getOffshoreHours();

			bean.setCostAutoTestingWithOnshoreRes(getString(getDouble(cOn6) * getDouble(caC28)));// mycode
			String cads = bean.getCostAutoTestingWithOffshoreRes1();

			bean.setCostAutoTestingWithOffshoreRes(getString(getDouble(cD6) * getDouble(caC29)));
			
			
		} catch (NamingException | SQLException | InstantiationException | IllegalAccessException ex) {
			log.error(CLASS_NAME, ex);
		}
		return bean;
	}

	public CalAutoScriptMait doCalculationForAutoScriptMaintainence(String projectId) throws InstantiationException {
		CalAutoScriptMait bean = new CalAutoScriptMait();
		String sql = "";
		try {
			sql = "SELECT TOTAL_VALUE FROM USER_INPUT WHERE PROJECT_ID=" + projectId + " AND INPUT_TYPE_ID=2";
			String iC7 = layer.scalarValue(sql);
			String cD7 = getValueFromConfigTable(projectId, "Script Failure", "Script Failure");
			bean.setAutomationScript(getString(getDouble(iC7) * getDouble(cD7) / 100));

			String cD14 = getValueFromConfigTable(projectId, "Productivity Maintainence", "ALL");
			String caC44 = bean.getAutomationScript();

			System.out.println("-------------" + caC44);

			bean.setHoursRequiredForMaintanence(getString(getDouble(cD14) * getDouble(caC44)));

			String cD6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_OFF_SHORE_COST);
			String cOn = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_ON_SITE_COST);

			String cD3 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_ONSITE);
			String cD4 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_OFFSHORE);

			String caC45 = bean.getHoursRequiredForMaintanence();

			double dCostMainOn = (getDouble(cOn) * getDouble(caC45)) * getDouble(cD3) / 100;
			double dCostMainOff = (getDouble(cD6) * getDouble(caC45)) * getDouble(cD4) / 100;

			double totalMainCost = dCostMainOn + dCostMainOff;

			System.out.println("-------------" + totalMainCost);

			bean.setCostOfAutoMaintanenceAtOffshore(getString(totalMainCost));

		} catch (NamingException | SQLException | IllegalAccessException ex) {
			log.error(CLASS_NAME, ex);
		}
		return bean;

	}
	
	public CalAutoScriptExeBean doCalculationForAutoScriptExecRealTime(String projectId) {

		CalAutoScriptExeBean bean = new CalAutoScriptExeBean();
		try {
			String iC9 = getValueFromInputTable(COL_COMPLEX_HIGH, projectId, "4");
			String iD9 = getValueFromInputTable(COL_COMPLEX_MEDIUM, projectId, "4");
			String iE9 = getValueFromInputTable(COL_COMPLEX_LOW, projectId, "4");
			bean.setHighAutomationTcScript(iC9);
			bean.setMediumAutomationTcScript(iD9);
			bean.setLowAutomationTcScript(iE9);

			String cD16 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_EXECUTION_AUTOMATION, VAL_HIGH);
			/*
			 * int caC34 = Integer.parseInt(getValueFromhigh(projectId));
			 * System.out.println("high===" + caC34); int caC35 =
			 * Integer.parseInt(getValueFrommedium(projectId));
			 * System.out.println("medium===" + caC35); int caC36 =
			 * Integer.parseInt(getValueFromlow(projectId)); System.out.println("low===" +
			 * caC36);
			 */
			String cD17 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_EXECUTION_AUTOMATION, VAL_MEDIUM);
			String cD18 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_EXECUTION_AUTOMATION, VAL_LOW);
			bean.setHoursReqPerHourForHigh(getString(getDouble(iC9) * getDouble(cD16)));
			bean.setHoursReqPerHourForMedium(getString(getDouble(iD9) * getDouble(cD17)));
			bean.setHoursReqPerHourForLow(getString(getDouble(iE9) * getDouble(cD18)));
			System.out.println("ic9==" + iC9 + " " + iD9 + " " + iE9 + " " + cD16 + " " + cD17 + " " + cD18);
			String caC37 = bean.getHoursReqPerHourForHigh();
			String caC38 = bean.getHoursReqPerHourForMedium();
			String caC39 = bean.getHoursReqPerHourForLow();

			/*
			 * System.out.println("val====" + getString(getDouble(caC37) * caC34 +
			 * getDouble(caC38) * caC35 + getDouble(caC39) * caC36));
			 */
			// bean.setTotalAutomationHoursPerCycle1(getString(getDouble(caC37)*caC34 +
			// getDouble(caC38)*caC35 + getDouble(caC39)*caC36));

			bean.setTotalAutomationHoursPerCycle(getString(getDouble(caC37) + getDouble(caC38) + getDouble(caC39)));

			bean.setHoursReqPerHourForHigh(getString(getDouble(cD16)));
			bean.setHoursReqPerHourForMedium(getString(getDouble(cD17)));
			bean.setHoursReqPerHourForLow(getString(getDouble(cD18)));
			caC37 = bean.getHoursReqPerHourForHigh();
			caC38 = bean.getHoursReqPerHourForMedium();
			caC39 = bean.getHoursReqPerHourForLow();
			// this code is written by arjun
			/*
			 * bean.setTotalAutomationHoursPerCycle1( getString(getDouble(caC37) * caC34 +
			 * getDouble(caC38) * caC35 + getDouble(caC39) * caC36));
			 */
			// To fetch the Offshore and Onshore cost- 2/15/2019
			String cD6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_OFF_SHORE_COST);
			String cOn6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_ON_SITE_COST);

			String autoExeHours = getValueFromExeTimetable(projectId);
			DecimalFormat df=new DecimalFormat("0.00");
			String strAutoExeHours= df.format(getDouble(autoExeHours));
			
			String cD3 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_ONSITE);
			String cD4 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_OFFSHORE);
			
			bean.setCostAutoTestingRealOnshore(getString(getDouble(cOn6) * getDouble(strAutoExeHours) * getDouble(cD3) / 100));

			bean.setCostAutoTestingRealOffshore(getString(getDouble(cD6) * getDouble(strAutoExeHours) * getDouble(cD4) / 100));
			
			String MaintEffortHour = getValueFromMaintEfforttable(projectId);
			bean.setMaintenanceEffortCost(getString(getDouble(MaintEffortHour)* getDouble(cD6)));
			
			
		} catch (NamingException | SQLException | InstantiationException | IllegalAccessException ex) {
			log.error(CLASS_NAME, ex);
		}
		return bean;
	}
	
	public CalManualTestBean doCaluclationForMaualtestingRealTime(String projectId) {

		CalManualTestBean bean = new CalManualTestBean();
		String sql = "";
		try {
			sql = String.format("SELECT TOTAL_VALUE FROM USER_INPUT WHERE PROJECT_ID=%s AND INPUT_TYPE_ID=1",
					projectId);
			String iC6 = layer.scalarValue(sql);
			bean.setManualTestCases(iC6);

			String iD6RealTime = getComplexityCount("High");
			//bean.setHighTestCases(iD6RealTime);

			String iE6RealTime = getComplexityCount("Medium");
			//bean.setMediumTestCases(iE6RealTime);

			String iF6RealTime = getComplexityCount("Low");
			//bean.setLowTestCases(iF6RealTime);

			String cD8 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_MANUAL, VAL_HIGH);
			bean.setHighTestCaseExecutionEffect(getString(getDouble(iD6RealTime) * getDouble(cD8)));

			String cD9 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_MANUAL, VAL_MEDIUM);
			bean.setMediumTestCaseExecutionEffect(getString(getDouble(iE6RealTime) * getDouble(cD9)));

			String cD10 = getValueFromConfigTable(projectId, VAL_PRODUCTIVITY_MANUAL, VAL_LOW);
			bean.setLowTestCaseExecutionEffect(getString(getDouble(iF6RealTime) * getDouble(cD10)));

			String caC8 = bean.getHighTestCaseExecutionEffect();
			String caC9 = bean.getMediumTestCaseExecutionEffect();
			String caC10 = bean.getLowTestCaseExecutionEffect();
			bean.setTotalHours(getString(getDouble(caC8) + getDouble(caC9) + getDouble(caC10)));

			String cD3 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_ONSITE);
			String cD4 = getValueFromConfigTable(projectId, VAL_RESOURCE_MIX, VAL_OFFSHORE);
			String caC11 = bean.getTotalHours();
			bean.setOnsiteHours(getString(getDouble(cD3) / 100 * getDouble(caC11)));
			bean.setOffshoreHours(getString(getDouble(cD4) / 100 * getDouble(caC11)));

			String caC12 = bean.getOnsiteHours();
			String caC13 = bean.getOffshoreHours();
			String cD5 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_ON_SITE_COST);
			String cD6 = getValueFromConfigTable(projectId, VAL_BILL_RATE, VAL_OFF_SHORE_COST);
			bean.setOnsiteCost(getString(getDouble(caC12) * getDouble(cD5)));
			bean.setOffshoreCost(getString(getDouble(caC13) * getDouble(cD6)));

			String caC14 = bean.getOnsiteCost();
			String caC15 = bean.getOffshoreCost();
			bean.setTotalManualCostRealTime(getString(getDouble(caC14) + getDouble(caC15)));

		} catch (InstantiationException | IllegalAccessException | NamingException | SQLException ex) {
			log.error(CLASS_NAME, ex);
		}
		return bean;
	}
	
	
}
