package com.ust.roi.logic;

import java.util.List;

import com.ust.roi.db.crud.ProjectLayer;
import com.ust.roi.db.model.ProjectBean;

public class ProjectLogic {
	private ProjectLayer layer = new ProjectLayer();

	public List<ProjectBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public ProjectBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}
	public ProjectBean getBeanByName(String name) {
		return layer.getByName(name);
	}

	public void save(List<ProjectBean> lst) {
		for (ProjectBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<ProjectBean> lst) {
		for (ProjectBean bean : lst) {
			layer.update(bean);
		}
	}
}
