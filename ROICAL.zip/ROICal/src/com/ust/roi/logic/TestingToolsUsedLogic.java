package com.ust.roi.logic;

import java.util.List;

import com.ust.roi.db.crud.TestingToolsUsedLayer;
import com.ust.roi.db.model.TestingToolsUsedBean;

public class TestingToolsUsedLogic {
	private TestingToolsUsedLayer layer = new TestingToolsUsedLayer();

	public List<TestingToolsUsedBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public TestingToolsUsedBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public void save(List<TestingToolsUsedBean> lst) {
		for (TestingToolsUsedBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<TestingToolsUsedBean> lst) {
		for (TestingToolsUsedBean bean : lst) {
			layer.update(bean);
		}
	}
}
