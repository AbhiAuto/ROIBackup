package com.ust.roi.logic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ust.roi.db.crud.CalculationFormulaLayer;
import com.ust.roi.db.crud.ConfigurationLayer;
import com.ust.roi.db.crud.MaintenanceEffortLayer;
import com.ust.roi.db.crud.UserLayer;
import com.ust.roi.db.model.ConfigureElementBean;
import com.ust.roi.db.model.MaintenanceEffortBean;

public class MaintenanceEffortLogic {
	
	private CalculationFormulaLayer layer = new CalculationFormulaLayer();
	private String getDatesMaintEffortTable(Integer projectId)
			throws NamingException, SQLException, InstantiationException, IllegalAccessException {
		String sql = "SELECT Date, Hours FROM roicaldb.maintenanceeffort where projectId = 37";
		return layer.scalarValue(sql);
	}

	public void saveto(String date, String hours, int projectId) {
		String driverName = "com.mysql.jdbc.Driver";
		String connectionUrl = "jdbc:mysql://localhost:3306/";
		String dbName = "roicaldb";
		String userId = "root";
		String password = "qwerty12345";
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Connection connection = null;
			Statement statement = null;


			connection = DriverManager.getConnection(connectionUrl + dbName, userId, password);
			PreparedStatement pstmt = null;
			pstmt = connection.prepareStatement("insert into maintenanceeffort(DATE,HOURS,PROJECTID) values(?,?,?)");
			pstmt.setString(1, date);
			pstmt.setString(2, hours);
			pstmt.setInt(3, projectId);
			pstmt.executeUpdate();
			//statement = connection.createStatement();

			//String qmin = "insert into maintenanceeffort(DATE,HOURS,PROJECTID) values("+date+","+ hours +"," + projectId+")";
			//System.out.println("qmin===" + qmin);

			//statement.executeUpdate(qmin);

			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public ArrayList<ArrayList<String>> getDateData(int projectId) throws InstantiationException, IllegalAccessException, NamingException, SQLException{
		ArrayList<ArrayList<String>> lst = new ArrayList<ArrayList<String>>();
		
		//String value = getDatesMaintEffortTable(projectId);
		//System.out.println(value);
		
		String driverName = "com.mysql.jdbc.Driver";
		String connectionUrl = "jdbc:mysql://localhost:3306/";
		String dbName = "roicaldb";
		String userId = "root";
		String password = "qwerty12345";
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Connection connection = null;
			Statement statement = null;


			connection = DriverManager.getConnection(connectionUrl + dbName, userId, password);

			statement = connection.createStatement();

			String query = "SELECT Date, Hours FROM roicaldb.maintenanceeffort where projectId = "+ projectId;
			System.out.println("qmin===" + query);

			ResultSet rs = statement.executeQuery(query);
			
			
			while (rs.next()) {
				String date = rs.getString("Date");
				String hrs = rs.getString("Hours");
				//System.out.println("datehrs-----" + date + "  " + hrs);
				ArrayList<String> lst1 = new ArrayList<String>();
				lst1.add(date);
				lst1.add(hrs);
				lst.add(lst1);
				//lst1.clear();		
			}

			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(lst);
		for (int i = 0; i < lst.size(); i++) {
			ArrayList<String> tmp = lst.get(i);
			//System.out.println(tmp);
			for (int j = 0; j < tmp.size(); j++) {
				System.out.print("---" + tmp.get(j) + "--");
			}
		}
		
		return lst;
		
	}
}
