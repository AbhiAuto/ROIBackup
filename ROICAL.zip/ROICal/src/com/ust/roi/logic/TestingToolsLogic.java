package com.ust.roi.logic;

import java.util.ArrayList;
import java.util.List;
import com.ust.roi.db.crud.TestingToolsLayer;
import com.ust.roi.db.model.TestingToolsBean;
import com.ust.roi.view.model.NameValuePair;

public class TestingToolsLogic {
	private TestingToolsLayer layer = new TestingToolsLayer();

	public List<TestingToolsBean> getListByProjectId(String projectId) {
		return layer.getAll(projectId);
	}

	public TestingToolsBean getBeanById(String id) {
		return layer.get(Integer.parseInt(id));
	}

	public void save(List<TestingToolsBean> lst) {
		for (TestingToolsBean bean : lst) {
			layer.save(bean);
		}
	}

	public void update(List<TestingToolsBean> lst) {
		for (TestingToolsBean bean : lst) {
			layer.update(bean);
		}
	}

	public List<NameValuePair> getNameValueListProjectId(String projectId) {
		List<NameValuePair> lst = new ArrayList<>();
		List<TestingToolsBean> lstt = getListByProjectId(projectId);
		for (TestingToolsBean lbean : lstt) {
			NameValuePair nvp = new NameValuePair();
			nvp.setValue("" + lbean.getToolId());
			nvp.setName(lbean.getToolName());
			lst.add(nvp);
		}
		return lst;
	}

	public TestingToolsBean getToolForProjectId(String projectId) {
		TestingToolsBean bean = new TestingToolsBean();
		List<TestingToolsBean> lstt = getListByProjectId(projectId);
		for (TestingToolsBean lbean : lstt) {
			if (null != lbean.getId() && lbean.getId() > 0) {
				bean = lbean;
				break;
			}
		}
		bean.setProjectId(Integer.parseInt(projectId));
		return bean;
	}
}
