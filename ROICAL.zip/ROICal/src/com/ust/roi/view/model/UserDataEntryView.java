package com.ust.roi.view.model;

public class UserDataEntryView {

	private float mtCountHigh;
	private float mtCountMed;
	private float mtCountLow;
	private float mtValue;
	private float asCountHigh;
	private float asCountMed;
	private float asCountLow;
	private float asValue;
	private float ecmCountHigh;
	private float ecmCountMed;
	private float ecmCountLow;
	private float ecmValue;
	private float ecaCountHigh;
	private float ecaCountMed;
	private float ecaCountLow;
	private float ecaValue;
	private float fdCountHigh;
	private float fdCountMed;
	private float fdCountLow;
	private float fdValue;

	public float getMtCountHigh() {
		return mtCountHigh;
	}

	public void setMtCountHigh(float mtCountHigh) {
		this.mtCountHigh = mtCountHigh;
	}

	public float getMtCountMed() {
		return mtCountMed;
	}

	public void setMtCountMed(float mtCountMed) {
		this.mtCountMed = mtCountMed;
	}

	public float getMtCountLow() {
		return mtCountLow;
	}

	public void setMtCountLow(float mtCountLow) {
		this.mtCountLow = mtCountLow;
	}

	public float getMtValue() {
		mtValue = mtCountHigh + mtCountMed + mtCountLow;
		return mtValue;
	}

	public float getAsCountHigh() {
		return asCountHigh;
	}

	public void setAsCountHigh(float asCountHigh) {
		this.asCountHigh = asCountHigh;
	}

	public float getAsCountMed() {
		return asCountMed;
	}

	public void setAsCountMed(float asCountMed) {
		this.asCountMed = asCountMed;
	}

	public float getAsCountLow() {
		return asCountLow;
	}

	public void setAsCountLow(float asCountLow) {
		this.asCountLow = asCountLow;
	}

	public float getAasValue() {
		asValue = asCountHigh + asCountLow + asCountMed;
		return asValue;
	}

	public float getEcmCountHigh() {
		return ecmCountHigh;
	}

	public void setEcmCountHigh(float ecmCountHigh) {
		this.ecmCountHigh = ecmCountHigh;
	}

	public float getEcmCountMed() {
		return ecmCountMed;
	}

	public void setEcmCountMed(float ecmCountMed) {
		this.ecmCountMed = ecmCountMed;
	}

	public float getEcmCountLow() {
		return ecmCountLow;
	}

	public void setEcmCountLow(float ecmCountLow) {
		this.ecmCountLow = ecmCountLow;
	}

	public float getEcmValue() {
		ecmValue = ecmCountLow + ecmCountHigh + ecmCountMed;
		return ecmValue;
	}

	public float getEcaCountHigh() {
		return ecaCountHigh;
	}

	public void setEcaCountHigh(float ecaCountHigh) {
		this.ecaCountHigh = ecaCountHigh;
	}

	public float getEcaCountMed() {
		return ecaCountMed;
	}

	public void setEcaCountMed(float ecaCountMed) {
		this.ecaCountMed = ecaCountMed;
	}

	public float getEcaCountLow() {
		return ecaCountLow;
	}

	public void setEcaCountLow(float ecaCountLow) {
		this.ecaCountLow = ecaCountLow;
	}

	public float getEcaValue() {
		ecaValue = ecaCountLow + ecaCountHigh + ecaCountMed;
		return ecaValue;
	}

	public float getFdCountHigh() {
		return fdCountHigh;
	}

	public void setFdCountHigh(float fdCountHigh) {
		this.fdCountHigh = fdCountHigh;
	}

	public float getFdCountMed() {
		return fdCountMed;
	}

	public void setFdCountMed(float fdCountMed) {
		this.fdCountMed = fdCountMed;
	}

	public float getFdCountLow() {
		return fdCountLow;
	}

	public void setFdCountLow(float fdCountLow) {
		this.fdCountLow = fdCountLow;
	}

	public float getFdValue() {
		fdValue = fdCountLow + fdCountHigh + fdCountMed;
		return fdValue;
	}

}
