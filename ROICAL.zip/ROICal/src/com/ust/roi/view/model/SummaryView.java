
package com.ust.roi.view.model;

public class SummaryView {

	private String elements;
	private String y1;
	private String y2;
	private String y3;
	private String y4;
	private String y5;
	private String viewM;
	private boolean sybl;
	private boolean perCent;

	public String getElements() {
		return elements;
	}

	public void setElements(String elements) {
		this.elements = elements;
	}

	public String getY1() {
		return y1;
	}

	public void setY1(String y1) {
		this.y1 = y1;
	}

	public String getY2() {
		return y2;
	}

	public void setY2(String y2) {
		this.y2 = y2;
	}

	public String getY3() {
		return y3;
	}

	public void setY3(String y3) {
		this.y3 = y3;
	}

	public String getY4() {
		return y4;
	}

	public void setY4(String y4) {
		this.y4 = y4;
	}

	public String getY5() {
		return y5;
	}

	public void setY5(String y5) {
		this.y5 = y5;
	}

	public String getViewM() {
		return viewM;
	}

	public void setViewM(String viewM) {
		this.viewM = viewM;
	}

	public boolean isSybl() {
		return sybl;
	}

	public void setSybl(boolean sybl) {
		this.sybl = sybl;
	}

	@Override
	public String toString() {
		return "SummaryView [elements=" + elements + ", y1=" + y1 + ", y2=" + y2 + ", y3=" + y3 + ", y4=" + y4 + ", y5="
				+ y5 + "]";
	}

	public void setPercent(boolean perCent) {
		this.perCent = perCent;
	}
	
	public boolean isPercent() {
		return perCent;
	}

}
