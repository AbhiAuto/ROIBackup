
package com.ust.roi.view.model;

public class AdminCurrentLandingView {
	private String prjName;
	private String prjDesp;
	private String prjId;

	public String getPrjName() {
		return prjName;
	}

	public void setPrjName(String prjName) {
		this.prjName = prjName;
	}

	public String getPrjDesp() {
		return prjDesp;
	}

	public void setPrjDesp(String prjDesp) {
		this.prjDesp = prjDesp;
	}

	public String getPrjId() {
		return prjId;
	}

	public void setPrjId(String prjId) {
		this.prjId = prjId;
	}

}
