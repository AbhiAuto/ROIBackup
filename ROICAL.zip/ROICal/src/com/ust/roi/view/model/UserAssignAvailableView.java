package com.ust.roi.view.model;

public class UserAssignAvailableView {

	private String uname;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

}
