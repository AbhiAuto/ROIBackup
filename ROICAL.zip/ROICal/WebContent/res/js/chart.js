$(function () {
    Highcharts.chart('container', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Column chart with negative values'
        },
        xAxis: {
            categories: ['Y1', 'Y2', 'Y3']
        },
        credits: {
            enabled: false
        },
        series: [{
            name: 'Savings',
            data: [-272574.98,1808427.58,3889430.15]
       }]
    });
});